# 13 — Lecciones de producción y recetas probadas (léelo antes de la fase 5 y en cada sesión de cambios)

Todo lo de este documento salió de una tienda real construida de principio a
fin y retocada durante horas con el usuario delante. Son errores que YA
cometimos (no los repitas) y recetas que YA funcionan (úsalas tal cual,
adaptando prefijo, colores y tipografías a la ficha de estilo de cada marca).

Índice: 1 Cómo se trabaja con el usuario en la sesión de cambios · 2 Maqueta
del héroe (la que más iteraciones costó) · 3 Titulares por palabras sin
recortar glifos · 4 Transiciones entre bloques (catálogo de costuras
diseñadas) · 5 Animaciones "sutiles pero top" · 6 Lookbook: paralaje de
ventana + flechas suaves · 7 Scroll suave (Lenis) · 8 Página de producto:
detalles que el usuario pidió · 9 Trampas de CSS/Liquid/Shopify nuevas ·
10 Trampas de herramientas (PowerShell, capturas, navegador) · 11 Fotos IA:
lo aprendido · 12 Admin API: lo aprendido · 13 Estado y memoria.

---

## 1. Cómo se trabaja con el usuario en la sesión de cambios

Cuando la tienda ya existe, el usuario manda **muchos mensajes cortos**, a
menudo con **capturas marcadas en rojo** y a veces mientras tú todavía
estás en otra cosa. Reglas que funcionaron:

- **Una captura marcada vale más que un párrafo.** Lee la marca roja: un
  círculo = "esto"; una flecha = "muévelo aquí"; un tachado = "quítalo".
  Describe en una frase lo que has entendido y aplícalo. No preguntes si
  puedes deducirlo.
- **Aplica primero, ofrece alternativas después.** Ante una decisión de
  gusto (un copy, una frase, un efecto), propón 2-3 opciones en una lista
  corta, **deja puesta la recomendada** y di "si prefieres otra, dímelo y la
  cambio". El usuario contesta con una palabra. Nunca bloquees esperando.
- **Cada cambio, un ciclo completo**: editar → `push --only` de lo tocado →
  verificar (captura o medición) → anotar en `ESTADO.md` → responder en 3-6
  líneas: qué cambió, dónde, cómo lo edita él si quiere. Sin jerga.
- **Si te corrige la interpretación** ("lo dije al revés"), no te
  justifiques: aplica y confirma.
- **Mensajes que llegan mientras trabajas**: encadénalos en la misma tanda
  (edita todo, un solo push, una sola verificación) y responde a todos en un
  mensaje con un bloque por petición.
- **Cierre de cada respuesta**: recuerda en una línea qué falta de su lado
  (publicar, menú, políticas) hasta que esté hecho. Sin insistir dos veces
  por mensaje.
- **Cuando diga "publica"**: `shopify theme publish --theme <ID> --force`,
  comprueba en la URL pública que el tema activo es el tuyo (sin
  `preview_theme_id`), y a partir de ahí todos los push llevan
  `--allow-live` y le avisas de que los cambios son visibles al instante.

## 2. Maqueta del héroe (receta definitiva)

Lo que el usuario acabó queriendo (y suele querer): titular ENORME en dos
líneas (display + palabra en cursiva), etiqueta encima, subtítulo de UNA
línea justo debajo, botones debajo, **todo el pack centrado en vertical
bajo la cabecera y justificado a la izquierda con el margen lateral**;
etiquetas laterales y "scroll" ancladas abajo a la derecha.

Estructura que lo consigue sin sorpresas (el contenido va ABSOLUTO dentro
del héroe, así su altura es exactamente la del héroe):

```css
.mt-hero { position: relative; min-height: 100svh; overflow: hidden; }
.mt-hero__content { position: absolute; inset: 0; z-index: 2; display: flex; flex-direction: column;
  justify-content: center; padding-top: var(--mt-header-h); padding-bottom: 6vh; }
/* OJO: el contenedor NO puede llevar margin: 0 auto dentro de un flex-column, o se encoge y se centra */
.mt-hero__content .mt-container { margin: 0; width: 100%; max-width: none; align-self: stretch; }
.mt-hero__grid { display: grid; grid-template-columns: 1fr; }
.mt-hero__main { justify-self: start; }
.mt-hero__aside { position: absolute; right: var(--mt-gutter); bottom: 48px; text-align: right; }
.mt-hero__title { font-size: clamp(56px, 13vw, 300px); line-height: .86; }
.mt-section h1.mt-hero__title { margin-bottom: .16em; }   /* aire para la cola de la cursiva: en EM del propio titular */
.mt-hero__sub { white-space: nowrap; font-size: min(14px, .95vw); }  /* una línea que encoge con la ventana */
.mt-hero__title .mt-word:has(em) { display: block; }       /* la palabra en cursiva SIEMPRE en su propia línea */
@media (max-width: 749px) {
  .mt-hero__sub { white-space: normal; font-size: 15px; }
  .mt-section h1.mt-hero__title { margin-bottom: .34em; }
}
```

Lecciones concretas:
- `calc(var(--tamaño-en-clamp) * 0.3)` NO resolvió como margen en Chrome
  (computed 0). Para separar algo del titular usa **em** en el propio
  titular, nunca variables con clamp dentro de calc.
- `.mt-section h1 { margin: 0 }` (tu reset) tiene más especificidad que
  `.mt-hero__title` → tus márgenes "no aplican". Escribe el override como
  `.mt-section h1.mt-hero__title` o sube la especificidad.
- Con un solo `1fr` el titular puede caber en UNA línea en pantallas
  anchas: fuerza la cursiva a bloque (`:has(em)`), no confíes en el ancho.
- El subtítulo se "corta" en dos líneas si limitas `max-width: 46ch`:
  quítalo y usa `nowrap` + tamaño en `min(px, vw)`.
- En móvil la foto vertical del héroe se genera aparte (contrato del
  banner): modelo entero entre el 30 % y el 85 % de la altura, cielo libre
  arriba para el titular.
- Textura opcional sobre la foto (grano fino SVG `feTurbulence` o trama de
  puntos) con `mix-blend-mode: overlay` y opacidad 8-12 %: gusta y es
  barata. Exponla como ajuste (none/grain/dots + intensidad).

## 3. Titulares por palabras sin recortar glifos

El reveal por palabras (`.mt-word { display:inline-block; overflow:hidden }`)
recorta la parte alta de la S/Ó y la cola de la y/g de la cursiva cuando la
interlínea es < 1. Receta:

```css
.mt-words .mt-word { display: inline-block; overflow: hidden; vertical-align: bottom;
  padding: .12em .06em .24em 0; margin: -.12em -.06em -.24em 0; }  /* colchón arriba/abajo/derecha, compensado */
.mt-words .mt-word > span { display: inline-block; transform: translateY(110%); transition: transform 1.1s var(--mt-ease-out); }
.mt-words.mt-visible .mt-word > span { transform: none; }
.mt-display em { line-height: .78; }
.mt-words .mt-word:has(em) { margin-top: -.12em; }   /* menos aire antes de la línea en cursiva */
```

El JS que envuelve palabras debe respetar `<em>` como una sola "palabra"
(no partir "century." en dos).

## 4. Transiciones entre bloques — catálogo de costuras diseñadas

El usuario pidió explícitamente "bloques grandes y transiciones muy
trabajadas, nada de módulos pegados a secas". Estas cinco costuras
funcionaron y se pueden combinar (elige DISTINTAS para cada tienda):

| Costura | Cómo | Dónde encaja |
|---|---|---|
| **Fundido al color del siguiente** | Degradado en la parte baja del bloque con foto hacia el `color_fondo` del bloque siguiente (ajuste `fundido` en px y color) | héroe → banda/tira; two-up → bloque claro; franja de foto → footer |
| **Solape de foto** | El bloque siguiente empieza con `background: linear-gradient(<color anterior> 0 Npx, <color propio> Npx)` y su foto/tarjeta arranca dentro de esa franja | tira negra → producto (la foto "muerde" el negro) |
| **Sección partida clara/oscura** | Una sola sección con dos bandas: la línea 1 del titular en la banda clara y la línea 2 en la oscura | bloque de historia ("empezaron / llegaron") |
| **Foto que sube sobre el bloque anterior** | `margin-top: -N px` en el envoltorio + `background: linear-gradient(transparent 0 Npx, color Npx)` + `z-index: 2` | lookbook sobre un bloque de fotos (ojo: no sirve si el título va arriba; entonces usa fundido) |
| **Línea editorial** | 1px del color de tinta al 15-25 % con dos etiquetas mono en los extremos, que se dibuja al entrar (`scaleX 0→1`) | entre dos bloques del mismo color |
| **Banda de sellos/marquesina pegada** | banda del color del bloque anterior, sin padding, con `border-top/bottom` sutil | héroe → resto |

Regla: en `ESTADO.md` anota cada costura y su tipo. En móvil revisa las
mismas costuras: los bloques apilados cambian (ver §5, two-up).

## 5. Animaciones "sutiles pero top" (todas probadas)

Todas: solo `transform`/`opacity`/`filter` leve, `prefers-reduced-motion`
las desactiva, diales en el schema.

1. **Entrada de dos fotos que se asientan** (two-up): panel A
   `translateX(-5%) scale(1.06)` → none; panel B igual desde la derecha con
   0.08 s de retraso; 1.8 s `ease-out`; disparado por `[data-mt-reveal]` en
   el contenedor (el observer añade `.mt-visible` sin estilos base).
2. **Línea que se dibuja en la unión**: `::before` de 1px, `scaleY(0→1)`
   desde el centro, 1.6 s con 0.5 s de retraso.
3. **Palabras que enfocan**: en el titular del two-up, cada `.mt-word > span`
   arranca con `filter: blur(6px); opacity: 0` (no más de 6-8px: blur grande
   en texto de 160px cuesta GPU y rompe las capturas) y escalona 0.45→0.95 s.
4. **Máquina de escribir en la palabra en cursiva**: la línea 1 fija
   ("WORK IS THE") y la cursiva de la línea 2 se escribe/borra/reescribe
   con cursor parpadeante (`uniform.` → `goal.` → `reward.`…). Palabras en
   un `textarea` del schema (una por línea), pausa en segundos. Solo corre
   cuando el bloque está en pantalla (IntersectionObserver) y tras el
   reveal. Fija `min-height` a la línea para que no salte al borrar.
   NO uses hover para cambiar fotos con fundidos: rompe la integración
   entre bloques (el usuario lo rechazó).
5. **Paralaje de ventana** (ver §6).
6. **Reveals por palabras** (§3) en todos los titulares display; reveals
   con `translateY(28px)` + retrasos escalonados (`data-delay` 1-8) en el
   resto.
7. **Marquesina** con contenido duplicado hasta cubrir 2× el ancho; pausa al
   hover; separador editable.
8. **Foto incrustada en el titular de cierre** ("SEE YOU [foto] AT THE
   TOP."): la foto NO debe flotar donde caiga la línea. Receta: dos líneas
   fijas y la foto abre (o cierra) la segunda línea, con rotación de -2.5°,
   sombra suave y `scale(1.04)` al hover del titular; oculta en móvil.

## 6. Lookbook: paralaje de ventana + flechas suaves

Lo que el usuario quería: "ver la foto a través de una ventana; al hacer
scroll, la foto de dentro se mueve a otro ritmo que el marco".

```liquid
<div class="mt-look__media mt-look__media--arch">
  <div class="mt-look__par" data-mt-parallax="{{ velocidad }}"><img ...></div>
</div>
```

```css
.mt-look__par { position: absolute; inset: 0; will-change: transform; }
.mt-look--parallax .mt-look__par { inset: -26% 0; }     /* la foto es un 52 % más alta que la ventana */
.mt-look__par img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; object-position: center 30%; }
```

JS (dentro del loop común de paralaje): `y = -(centroDelPadreRespectoAlViewport) * velocidad`,
**limitado** a `±(alto del hijo − alto del padre)/2` para que nunca asome un
hueco. Velocidades alternas por foto (×1 / ×1.5) para que no se muevan
todas igual. Ajuste `parallax` 0-40 (default 22). Con 12-14 % de exceso el
efecto "no se ve": sube a 26 %.

**Flechas del lookbook sin "teletransporte"**: el `scroll-snap-type: x
mandatory` re-imanta al terminar la animación si el destino no coincide
con un punto de snap. Receta: `scroll-padding-inline-start: var(--mt-gutter)`
en la pista (así los puntos de snap son múltiplos exactos del paso), paso =
`items[1].offsetLeft − items[0].offsetLeft`, destino = múltiplo del paso más
cercano, animación propia con rAF y `easeInOutCubic` (~750 ms) mientras la
pista lleva la clase que desactiva el snap; al terminar, la quita. Y quita
el anillo de foco de Dawn en el botón (`:focus { outline: 0; box-shadow:
none }`, deja `:focus-visible` para teclado).

## 7. Scroll suave (Lenis)

El usuario lo pidió por su nombre ("la librería que hace el scroll suave").
Se incluye **como asset del tema** (`assets/mt-lenis.js`, ~13 KB, versión
1.1.x descargada de unpkg `lenis@1.1.18/dist/lenis.min.js`, expone
`globalThis.Lenis`), cargado con `defer` desde `layout/theme.liquid` ANTES
que tus scripts y **nunca en el editor** (`{% unless request.design_mode %}`).
Init en tu JS: `new Lenis({ lerp: 0.09, smoothWheel: true })` + loop `raf`;
anclas internas (`/#club`) con `lenis.scrollTo(el, { offset: -80 })`;
desactivado con `prefers-reduced-motion`. Tu paralaje sigue funcionando
(Lenis desplaza la ventana de verdad y dispara `scroll`). CSS:
`html.mt-lenis { scroll-behavior: auto !important }`.

## 8. Página de producto: detalles que el usuario pidió

- **Aire entre tallas y botón**: `{% form %}` genera un `<form>` que no
  hereda el `gap` del contenedor flex → dale `.mt-form { display:flex;
  flex-direction:column; gap:24px }`.
- **Opciones de un solo valor ocultas** (color "White" único): un
  `<fieldset hidden>` NO se oculta si tu CSS le pone `display:flex` →
  añade `.mt-opcion[hidden] { display:none !important }`.
- **Descripción estructurada**: guarda en el producto HTML con párrafo +
  `<p class="mt-desc-label">Details</p>` + `<ul>`; y estiliza `.mt-buy__desc
  p/ul/li` (guiones "—" con `::before`, etiqueta en mono pequeña). Sin eso,
  tu reset de `ul` deja todo en bloque seguido y el usuario lo nota.
- **Plazos**: no prometas "3-7 días" para POD; pregunta o usa "7–14
  business days". Aparece en la nota bajo el botón y en el acordeón de
  envíos.
- **Precio**: el usuario puede cambiar de idea ("ponlo a 39.95"): se hace
  con `productVariantsBulkUpdate` para TODAS las variantes en una llamada.
- El submit del formulario sin el `<product-form>` de Dawn lleva a la
  página del carrito (tematizada) en vez de abrir el cajón. Es aceptable;
  si el usuario quiere cajón, envuelve el form en `<product-form>` con
  `.loading__spinner` y carga `product-form.js` de Dawn.

## 9. Trampas de CSS / Liquid / Shopify nuevas

1. **Especificidad de tus resets**: `.mt-section h1/p/ul { margin:0 }` gana
   a `.mt-clase`. Escribe los overrides como `.mt-section .mt-clase` o
   `h1.mt-clase`.
2. **`margin: 0 auto` en un hijo de flex-column** lo encoge a su contenido
   y lo centra: el bloque "se centra solo". `margin:0; width:100%`.
3. **`calc(var(--x) * n)`** con `--x` = `clamp(...)`: no fiable → em.
4. **`[hidden]` vs `display:flex`** (ver §8).
5. **`background-attachment: fixed`** en el `body.gradient` de Dawn: quítalo
   (`scroll !important`) — rendimiento y capturas.
6. **Validación del schema**: `name` ≤ 25 caracteres (¡los guiones largos
   cuentan!), `label` ≤ 70, `header.content` ≤ 50, `range.default` en un
   paso exacto (5.4 con step .5 falla; 62 con step 5 falla), `select.default`
   debe existir en `options`, `url` sin `default`. Un solo fallo y el push
   entero "sube con errores": léelos siempre.
7. **Bloques en `index.json` que no están en `block_order`**: bórralos del
   objeto también.
8. **`{{ 'x.css' | asset_url | stylesheet_tag }}` repetido en cada sección**
   es correcto; el JS con `defer` + guard también.
9. **Hover en bloques con fundidos**: prohibido cambiar la opacidad del
   degradado al hover (rompe la costura). Los hovers van en tarjetas y
   botones, no en secciones-transición.
10. **Botón píldora dentro de un bloque oscuro**: `.mt-section a { color:
    inherit }` pisa el color del botón → `.mt-section .mt-btn--pill { color:
    var(--mt-tinta) }` explícito.

## 10. Trampas de herramientas (PowerShell, capturas, navegador)

- **Nunca metas backticks ni `$` en `bash -c`/heredocs sin comillas ni
  dentro de `node -e "..."`**: bash los ejecuta (se cargó un `--allow-live`
  y ejecutó una línea de la licencia de Node). Para cualquier edición con
  regex o texto largo: **escribe un `.js` en el scratchpad con la
  herramienta Write y ejecútalo con `node archivo.js`**. Los heredocs con
  `<<'EOF'` (comillas) sí son seguros.
- **PowerShell y `--variables '{"n":50}'`**: rompe las comillas. Siempre
  `--variable-file` con un `.json` escrito con `Set-Content -Encoding ascii`
  o desde bash.
- **Un `.tmp-*.json` con guiones largos** ("—") se sube bien en UTF-8 aunque
  PowerShell lo muestre como "â€”": verifica leyendo el resultado con bash.
- **Capturas del navegador integrado**: 1) con emulación 1920×1080 + scroll
  salen VACÍAS (captura la zona equivocada): revisa cada bloque **subiéndolo
  arriba** con un helper en consola (`hsShow`: oculta las demás secciones,
  `margin-top` negativo en `#MainContent`, fuerza `.mt-visible`, pone
  `loading=eager`); 2) las secciones con `filter: blur` grande hacen que la
  captura "no termine de renderizar": baja el blur; 3) **el panel tiene
  `prefers-reduced-motion: reduce` activado**: paralaje, Lenis, máquina de
  escribir y blur NO se ven. Para probarlos, en consola parchea
  `window.matchMedia` para reduced-motion, resetea `window.__mtInit`, vuelve
  a inyectar tu script y **mide** (`getBoundingClientRect`, `style.transform`)
  en vez de mirar; 4) la extensión de Chrome del usuario puede no estar
  conectada: no dependas de ella.
- **Verifica con números, no solo con ojos**: `getBoundingClientRect()` de
  título/subtítulo/botones para confirmar centrado, márgenes y que la cola
  de la cursiva no pisa el subtítulo (`em.bottom < sub.top`).
- **`shopify theme push --only a --only b`** para iterar en segundos; el
  push completo solo cuando cambian muchas cosas.
- **`shopify theme publish --force`** evita el prompt interactivo.

## 11. Fotos IA: lo aprendido

- **Presupuesto mínimo de píxeles**: 655 360. `1024x512` falla; usa
  `1536x768` (2:1), `768x1024`/`1024x1280` (4:5), `1024x1360` (3:4; 1365 no
  es múltiplo de 16), `2048x1152`, `1152x2048`.
- **Moderación con falsos positivos** al pedir "reproduce este logo en
  blanco": no insistas. Un logo de tinta negra + un color se **recolorea en
  local** (`scripts/recolorear-logo.ps1`: píxeles oscuros → color claro,
  el acento se conserva). Sale exacto y gratis. Y si el usuario tiene una
  versión blanca propia, la suya manda.
- **El usuario elige entre borradores**: genera 3 borradores `low` del
  héroe, quédate con el que cumple el contrato, pero **guarda los otros**:
  el usuario puede preferir otro ("pon el 1"). Entonces regenera EL SUYO en
  `high` con la corrección del contrato (modelo entero, aire) y su móvil.
- **El usuario puede reescalar** (Upscayl) y darte un PNG de 4096 px:
  optimiza a 2880 px JPEG 88 (~500 KB) y actualiza `width/height` del
  `<img>`.
- **Primer plano del logo del pecho** con arrugas suaves: refs = diseño
  frontal + mockup frontal + tu foto de detalle existente (para que copie
  el tipo de plano); `1024x1280`, low ×2 → medium. Encaja en el acordeón de
  "Care"/"Print".
- Escenas nuevas de lookbook: 2 borradores `low` (768×1024) → 1 final
  `medium` (1024×1360) usando el borrador como primera referencia. Salieron
  fieles al estampado a la primera con el paquete de referencias completo.
- Gasto real de una tienda completa con 7 piezas generadas: ≈ 3 $.

## 12. Admin API: lo aprendido

- `collectionCreate` con `products` **no publica la colección en el canal
  Tienda online** (hace falta `write_publications`, que no pedimos). En la
  web, `/collections/all` cae en la colección automática con la plantilla
  por defecto de Dawn → **sobrescribe también `templates/collection.json`**
  con tus secciones y dile al usuario dónde activar el canal (2 clics).
- Borrar fotos del proveedor: `productDeleteMedia` con los `MediaImage` ids
  (consulta `product.media`, no `images`). El usuario lo pidió
  explícitamente ("no uses las fotos de Shopify"): hazlo por defecto cuando
  hay fotos propias mejores, avisando.
- El alt de las fotos en inglés, con nombre de producto y vista.
- `productVariantsBulkUpdate` para precios: una llamada, todas las
  variantes.
- Los tokens de `store auth` caducan a las ~24 h: en sesiones de cambios
  empieza por comprobar con una consulta mínima.

## 13. Estado y memoria

- `ESTADO.md` crece con una línea por cambio en la sesión de cambios
  (fecha, qué, dónde). Al publicar: anota el ID, que ahora los push van con
  `--allow-live`, y que el tema anterior sigue guardado.
- Guarda en la memoria del proyecto (auto-memory) dos notas: la ficha
  técnica de la tienda (dominio, IDs, carpeta) y las preferencias del usuario
  (idioma, "bloques grandes y transiciones", fotos propias, copys). Así la
  próxima sesión arranca sin preguntas.
