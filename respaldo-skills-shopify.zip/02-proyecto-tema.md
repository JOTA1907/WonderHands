# Fase 2 — Crear el proyecto y descargar el tema base (sin Git)

Objetivo: una carpeta local con una copia de **Dawn** (tema oficial y gratuito
de Shopify) sobre la que construimos todo lo propio.

## Por qué Dawn

- Gratuito, rápido, accesible, compatible con el editor visual, y trae
  resueltos carrito, búsqueda, colecciones, cuenta de cliente, filtros de
  colección, selector de variantes... cosas que NO queremos reconstruir.
- Estrategia: **no tocamos sus secciones originales** (salvo header y
  footer); añadimos secciones con prefijo propio y montamos portada,
  colección y producto con ellas.

## Crear la carpeta del proyecto

Ruta sin espacios, sin acentos, fuera de OneDrive:

- Windows: `C:\tiendas\<nombre-corto>` (p. ej. `C:\tiendas\hstlrs`)
- Mac: `~/tiendas/<nombre-corto>`

Dentro, además de los archivos del tema, crearás estas carpetas de trabajo
(NO se suben a Shopify: el push solo envía las carpetas del tema):

```
<proyecto>/
  material/            copia optimizada del material del usuario, clasificado (fase 3)
    referencias/       capturas de tiendas (solo para ti)
    prenda-<handle>/   mockups planos, naturales, detalle de cada prenda
    modelos/           fotos de modelo/lifestyle del usuario
    disenos/           diseños/estampados/logo (transparentes)
    concepto/          fotos de referencia de concepto
  fotos-catalogo/      fotos descargadas de los productos existentes (fase 1)
  fotos-generadas/     borradores y anclas de la IA (fase 6)
  clave-openai.txt     la clave, si la dio (nunca en assets/ ni en ESTADO.md)
  ESTADO.md
```

## Descargar Dawn — método A: ZIP de GitHub (preferido, sin Git)

Windows (PowerShell):

```powershell
Invoke-WebRequest -Uri "https://github.com/Shopify/dawn/archive/refs/heads/main.zip" -OutFile "$env:TEMP\dawn.zip"
Expand-Archive -Path "$env:TEMP\dawn.zip" -DestinationPath "$env:TEMP\dawn-extract" -Force
Copy-Item "$env:TEMP\dawn-extract\dawn-main\*" -Destination "C:\tiendas\<nombre>" -Recurse -Force
```

Mac:

```bash
curl -fsSL -o /tmp/dawn.zip "https://github.com/Shopify/dawn/archive/refs/heads/main.zip"
unzip -q /tmp/dawn.zip -d /tmp/dawn-extract
cp -R /tmp/dawn-extract/dawn-main/* ~/tiendas/<nombre>/
```

## Método B: `shopify theme init <carpeta>` (puede necesitar Git)

## Método C: bajar el tema actual de la tienda

```
shopify theme pull --store NOMBRE.myshopify.com --path <carpeta>
```

Puede ser "Horizon" u otro tema de Shopify: la estructura es la misma y el
enfoque de secciones propias funciona igual.

## Verificar

La carpeta debe contener `assets/`, `config/`, `layout/`, `locales/`,
`sections/`, `snippets/`, `templates/`. Si falta alguna, borra y reintenta.

## Crear ESTADO.md

```markdown
# Estado del proyecto — <Marca>

- Tienda: <nombre>.myshopify.com
- Carpeta: <ruta>
- Prefijo de secciones: <xx->
- Tema base: Dawn (descargado <fecha>) · Tema de trabajo: <ID> (<nombre>)
- Entorno: Node <ver>, Shopify CLI <ver> — OK
- Material del usuario: <ruta(s) original(es)> → copiado en material/
- Clave de imágenes: sí/no (archivo clave-openai.txt)
- Última publicación: (pendiente)

## Fases completadas
- [x] 0 Entorno  - [x] 1 Conexión  - [x] 2 Proyecto
- [ ] 3 Lectura de referencias  - [ ] 4 Brief  - [ ] 5 Construcción
- [ ] 6 Fotos IA  - [ ] 7 Catálogo y páginas  - [ ] 8 Publicación

## Catálogo leído (fase 1)
| Producto | id | handle | estado | opciones | variantes | precio | fotos | colección | diseño de la carpeta |
|---|---|---|---|---|---|---|---|---|---|

## Inventario del material (fase 3)
(tabla: archivo → categoría decidida → uso previsto)

## Ficha de estilo (fase 3)
(se rellena con la plantilla de la fase 3)

## Concepto y brief (fase 4)
## Composición de la portada (fase 4) — arquetipos por número
## Guion fotográfico (fase 6)
## Secciones creadas (fase 5)
## Costuras (fase 5)
## Pendientes del lado del usuario
```

## Primera subida (recomendada)

```
shopify theme push --store NOMBRE.myshopify.com --unpublished --theme "<Marca> (Claude)" --path <carpeta>
```

Valida la conexión de extremo a extremo antes de invertir horas. Guarda el
ID del tema en `ESTADO.md`. Si falla, resuelve con
`references/09-solucion-problemas.md` antes de seguir.

## Cierre

1. "✅ Ya tengo la base de tu tienda preparada. Ahora voy a estudiar tus
   imágenes y tus referencias."
2. `ESTADO.md` actualizado.
3. Pasa a `references/03-lectura-de-referencias.md`.
