# Solución de problemas — consulta ante CUALQUIER error

Filosofía: el usuario nunca ve un error en crudo. Tú diagnosticas con esta
guía, arreglas, y solo si necesitas algo de él (una contraseña, un clic), se
lo pides masticado. Si un error no está aquí, lee el mensaje con calma: los
errores del Shopify CLI suelen decir archivo y causa.

## Comandos que "no existen"

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| `node`/`npm`/`shopify` no se reconoce (Windows) | PATH de la sesión sin refrescar tras instalar | `$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")` y reintentar. Si persiste, probar ruta absoluta (`C:\Program Files\nodejs\node.exe`); si la absoluta funciona, seguir con PATH recargado por comando |
| Igual pero en Mac | PATH de zshrc no cargado en la sesión | `export PATH=~/.npm-global/bin:/usr/local/bin:$PATH` y reintentar |
| `shopify` existe pero PowerShell se niega a ejecutarlo (ExecutionPolicy) | Política de scripts | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force` |
| `npm install -g` falla con EACCES (Mac) | Permisos de /usr/local | Prefix propio: ver fase 0, sección Mac. NO usar sudo npm |
| `npm install -g` falla con EEXIST/EPERM (Windows) | Restos de instalación anterior o antivirus | `--force`; si persiste, esperar 1 min (antivirus) y reintentar |
| winget no existe | Windows antiguo o sin App Installer | Método B de la fase 0 (MSI silencioso) |
| Todo comando de red falla | Proxy corporativo, VPN, cortafuegos | Preguntar por VPN/red de empresa; probar con otra red (móvil) |

## Login y conexión

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| El login se abre pero el comando muere antes de que el usuario termine | Timeout corto | Relanzar con timeout de 3-5 min y avisar al usuario de que tiene tiempo |
| Bucle de login infinito | Sesión corrupta | `shopify auth logout`, reintentar |
| Autenticado pero "no tienes permisos en esta tienda" | Cuenta equivocada (tiene varias) | `shopify auth logout` y login con la cuenta dueña de la tienda |
| "Store not found" | Dominio mal | Pedir la URL del panel completa y extraer el nombre |
| La tienda pública pide contraseña | Protección de tienda nueva (no es un error) | Contraseña en panel: Tienda online → Preferencias |

## Datos del producto (Admin API: store auth / store execute)

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| `store auth`/`store execute` "no existe" o desconocido | Shopify CLI antiguo (<3.93) | `npm install -g @shopify/cli@latest` (fase 0) y reintentar |
| `store execute` responde no autorizado / 401 | Token online caducado (~24 h) o falta scope | Re-ejecutar `shopify store auth --store ... --scopes ...`; los scopes ya dados se conservan (≥3.93.1) |
| Una orden de cambio "no hace nada" | Faltó `--allow-mutations` o hay `userErrors` | Añadir `--allow-mutations`; leer `userErrors`/`mediaUserErrors`, corregir variables y reintentar |
| `Unknown argument "product"` / `required argument "input"` | Versión de API antigua en la tienda | Usar la forma `input:` o fijar `--version` reciente (ver `10-admin-api.md`, "Si una orden falla por versión") |
| El JSON en línea se rompe (Windows) | PowerShell 5.1 maquea comillas | Usar `--query-file` y `--variable-file` con archivos, no `--query`/`--variables` en línea |
| La foto subida no aparece en la galería | Media se procesa en segundo plano | Esperar unos segundos; verificar `status` con una nueva lectura del producto |
| El usuario no es dueño / rechaza permisos | Sin escritura | Plan B: pegar título/descripción y asignar plantilla a mano (fase 7) |

## Fotos IA (generación y banner)

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| El banner sale poco panorámico por mucho que lo pida el prompt | El aspect ratio NO se controla por prompt sino con el parámetro `size`, y no se fijó al ratio del banner | Contrato del banner (fase 6): pedir el `size` exacto del hueco (p. ej. `2048x1152` para 16:9 — gpt-image-2 acepta lados múltiplos de 16 hasta ratio 3:1) |
| El producto del banner sale cortado por arriba/abajo en la web | La imagen se generó con el producto llenando el lienzo (o en un lienzo que no era el del hueco) y el `cover` del CSS lo decapita | Regenerar al ratio exacto con la cláusula 2 del contrato (producto en la banda central ~70%, aire arriba/abajo); verificar en 16:9 Y móvil (fase 8) |
| El banner se ve bien en PC y mal en móvil (o al revés) | Una sola imagen para los dos formatos | Cláusula 4 del contrato: imagen vertical propia para móvil + patrón `<picture>` (fase 5, 6b) |
| Los pasos 1-2-3 (o cualquier serie) parecen fotos aleatorias | Prompts genéricos compartidos y generación en paralelo | Guion fotográfico + series encadenadas (fase 6): un prompt individual por foto; cada paso usa la foto del anterior como referencia |
| Todas las fotos de la tienda parecen de sesiones distintas | Sin fotos ancla de referencia común y/o sin vocabulario de set | Generar primero las fotos ancla y pasarlas como `--ref` en TODAS las llamadas + definir luz/fondo en 1-2 frases del guion y pegarlas en todos los prompts (fase 6) |
| El producto cambia de forma/color entre fotos | Llamadas sin las anclas como referencia (el modelo se lo inventa) | Fotos ancla (fase 6): 2-3 ángulos aprobados del producto van de referencia en cada llamada |
| Una foto está bien salvo un detalle (logo deformado, objeto raro) | Regenerarla entera es lotería | Retoque con máscara (fase 6): PNG con canal alfa sobre la zona + `--mascara`; si no converge en 2 intentos, regenerar |
| `401` / `429` / `insufficient_quota` al generar | Clave mal / ritmo / sin créditos | Tabla de errores de la fase 6 |
| `moderation_blocked` con `safety_violations=[sexual]` en una foto inocente | Falso positivo del clasificador con persona + producto en boca/mano (boquillas, cosmética...) | Escalera de la fase 6: reformular la acción → `--moderacion low` → cambiar la escena (sin persona); las llamadas bloqueadas no se cobran |
| El modelo pinta un damero o un fondo raro | Se pidió fondo transparente (no existe en gpt-image-2) | Pedir el color de fondo EXACTO de la sección (fase 6, prompts) |

## Push / subida

Primera regla: lee el bloque de error de la salida — dice el archivo. Tabla de
validaciones frecuentes en `08-publicacion.md`. Además:

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| Push "succeeded with errors" | Algunos archivos subieron, los del error no | Corregir y re-push; no informar éxito hasta push limpio |
| Push interactivo se queda esperando | Falta `--theme` y el CLI pregunta | Añadir `--theme <ID>` (sale de `shopify theme list`) |
| "You can't push to a live theme" | Tema de trabajo = tema publicado | Añadir `--allow-live` SOLO si el usuario sabe que va en vivo |
| 401/403 a mitad de push | Sesión caducada | Relanzar (re-login automático) |
| Push lentísimo o cuelga | Muchos assets pesados / antivirus / OneDrive | Comprobar que el proyecto NO está en OneDrive; usar `--only` para subir lo tocado |
| Assets que no se ven tras subir | Caché del navegador | Recargar con Ctrl+F5 / Cmd+Shift+R; verificar en ventana privada |

## Visual (la web "se ve mal")

| Síntoma | Causa típica | Dónde está documentado |
|---|---|---|
| Franja del color de la página entre dos bloques | Fondo pintado en el elemento interno en vez del envoltorio, o héroe cuya imagen no cubre el 100% con fallback blanco | Fase 5, sección 5 (regla de oro) y trampas nº 6; checklist de costuras (fase 5.7) |
| El usuario añade "Espacio superior" y crece de OTRO color | Mismo origen: el fondo no está en el envoltorio que lleva el padding | Fase 5, sección 5.1 y trampa nº 7 |
| Bloque "asfixiado": el texto arranca pegado al borde del bloque | Paddings por defecto a 0 | Fase 5, sección 5.2 (ritmo vertical) |
| Hueco/franja blanca que el usuario no puede quitar con los ajustes | Padding en el elemento interno, o margen del header de Dawn | Fase 5: sección 5.1 y trampa nº 4 |
| Sombras/zoom de tarjetas cortadas | `overflow: hidden` en algún ancestro | Fase 5, trampa nº 2 (`overflow-x: clip` + `overflow-y: visible`) |
| Un elemento con z-index alto no se ve | Contexto de apilamiento por clip-path/transform/filter | Fase 5, trampa nº 3 (pseudo-elemento del que ya está encima) |
| Saltos de línea del editor no aparecen | Falta `newline_to_br` | Fase 5, trampa nº 9 |
| Scroll horizontal en móvil | Decorativos absolutos sin recortar | Fase 5, trampa nº 11 |
| Cambios de ajustes del editor que "no hacen nada" | El CSS pisa el valor del `{% style %}` con `!important`, o el ajuste no está conectado | Conectar el ajuste en el bloque `{% style %}`; evitar `!important` en propiedades expuestas como ajustes |
| La sección no aparece para añadir en el editor | Falta `presets` en el schema | Fase 5, plantilla canónica |
| Bloques que nunca aparecen (invisibles para siempre) | Reveal cuyo IntersectionObserver no se dispara o clase inicial `opacity: 0` sin JS cargado | Revisar `mt-scripts.js` (fase 5.9); fallback: sin JS, los elementos deben ser visibles |

## Página de producto

| Síntoma | Causa típica | Arreglo |
|---|---|---|
| "Añadir al carrito" no hace nada | Falta `{% form 'product' %}` o el `input[name=id]` no tiene id de variante válido | Receta de la fase 7, paso 1.2 |
| Precio no cambia al cambiar variante | El JS no actualiza precio + input id a la vez | Fase 7, paso 1.3 |
| Aparece un selector de variantes vacío | No se comprueba `product.has_only_default_variant` | Fase 7, paso 1.3 |
| La página sale sin datos / producto de ejemplo | El producto no existe o está en borrador, o el template no está asignado | Fase 7, pasos 0 y 3 |
| El usuario no ve la plantilla "mt" en el desplegable | El desplegable lista plantillas del tema PUBLICADO y el vuestro es de trabajo | Normal: previsualizar con `?preview_theme_id=<ID>`; asignar al publicar |
| Carrito/búsqueda con colores "de otra web" | `settings_data.json` sin tematizar | Fase 5, sección "ropa global del tema" |

## Entorno roto a mitad de sesión

- **Se cerró la terminal / Claude Code se reinició**: ejecuta el diagnóstico
  (`scripts/`), lee `ESTADO.md` del proyecto y continúa donde quedó. Para
  encontrar el proyecto: busca `ESTADO.md` bajo `C:\tiendas\` (Windows) o
  `~/tiendas/` (Mac).
- **El usuario borró/movió la carpeta**: re-descarga Dawn (fase 2) y luego
  `shopify theme pull --theme <ID>` para recuperar TODO lo construido desde
  Shopify (por eso publicamos siempre: Shopify es nuestra copia de seguridad).
- **Conflicto: alguien editó desde el editor de Shopify Y nosotros en local**:
  los push machacan lo del editor (los json de settings). Si el usuario ha
  estado retocando desde Shopify, haz `shopify theme pull --theme <ID> --only
  config --only templates` ANTES de tu siguiente tanda de cambios para traerte
  sus retoques.

## Sesión de cambios y herramientas (nuevo)

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| Un comando en línea ejecutó texto raro / borró una línea | Backticks o `# Solución de problemas — consulta ante CUALQUIER error

Filosofía: el usuario nunca ve un error en crudo. Tú diagnosticas con esta
guía, arreglas, y solo si necesitas algo de él (una contraseña, un clic), se
lo pides masticado. Si un error no está aquí, lee el mensaje con calma: los
errores del Shopify CLI suelen decir archivo y causa.

## Comandos que "no existen"

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| `node`/`npm`/`shopify` no se reconoce (Windows) | PATH de la sesión sin refrescar tras instalar | `$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")` y reintentar. Si persiste, probar ruta absoluta (`C:\Program Files\nodejs\node.exe`); si la absoluta funciona, seguir con PATH recargado por comando |
| Igual pero en Mac | PATH de zshrc no cargado en la sesión | `export PATH=~/.npm-global/bin:/usr/local/bin:$PATH` y reintentar |
| `shopify` existe pero PowerShell se niega a ejecutarlo (ExecutionPolicy) | Política de scripts | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force` |
| `npm install -g` falla con EACCES (Mac) | Permisos de /usr/local | Prefix propio: ver fase 0, sección Mac. NO usar sudo npm |
| `npm install -g` falla con EEXIST/EPERM (Windows) | Restos de instalación anterior o antivirus | `--force`; si persiste, esperar 1 min (antivirus) y reintentar |
| winget no existe | Windows antiguo o sin App Installer | Método B de la fase 0 (MSI silencioso) |
| Todo comando de red falla | Proxy corporativo, VPN, cortafuegos | Preguntar por VPN/red de empresa; probar con otra red (móvil) |

## Login y conexión

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| El login se abre pero el comando muere antes de que el usuario termine | Timeout corto | Relanzar con timeout de 3-5 min y avisar al usuario de que tiene tiempo |
| Bucle de login infinito | Sesión corrupta | `shopify auth logout`, reintentar |
| Autenticado pero "no tienes permisos en esta tienda" | Cuenta equivocada (tiene varias) | `shopify auth logout` y login con la cuenta dueña de la tienda |
| "Store not found" | Dominio mal | Pedir la URL del panel completa y extraer el nombre |
| La tienda pública pide contraseña | Protección de tienda nueva (no es un error) | Contraseña en panel: Tienda online → Preferencias |

## Datos del producto (Admin API: store auth / store execute)

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| `store auth`/`store execute` "no existe" o desconocido | Shopify CLI antiguo (<3.93) | `npm install -g @shopify/cli@latest` (fase 0) y reintentar |
| `store execute` responde no autorizado / 401 | Token online caducado (~24 h) o falta scope | Re-ejecutar `shopify store auth --store ... --scopes ...`; los scopes ya dados se conservan (≥3.93.1) |
| Una orden de cambio "no hace nada" | Faltó `--allow-mutations` o hay `userErrors` | Añadir `--allow-mutations`; leer `userErrors`/`mediaUserErrors`, corregir variables y reintentar |
| `Unknown argument "product"` / `required argument "input"` | Versión de API antigua en la tienda | Usar la forma `input:` o fijar `--version` reciente (ver `10-admin-api.md`, "Si una orden falla por versión") |
| El JSON en línea se rompe (Windows) | PowerShell 5.1 maquea comillas | Usar `--query-file` y `--variable-file` con archivos, no `--query`/`--variables` en línea |
| La foto subida no aparece en la galería | Media se procesa en segundo plano | Esperar unos segundos; verificar `status` con una nueva lectura del producto |
| El usuario no es dueño / rechaza permisos | Sin escritura | Plan B: pegar título/descripción y asignar plantilla a mano (fase 7) |

## Fotos IA (generación y banner)

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| El banner sale poco panorámico por mucho que lo pida el prompt | El aspect ratio NO se controla por prompt sino con el parámetro `size`, y no se fijó al ratio del banner | Contrato del banner (fase 6): pedir el `size` exacto del hueco (p. ej. `2048x1152` para 16:9 — gpt-image-2 acepta lados múltiplos de 16 hasta ratio 3:1) |
| El producto del banner sale cortado por arriba/abajo en la web | La imagen se generó con el producto llenando el lienzo (o en un lienzo que no era el del hueco) y el `cover` del CSS lo decapita | Regenerar al ratio exacto con la cláusula 2 del contrato (producto en la banda central ~70%, aire arriba/abajo); verificar en 16:9 Y móvil (fase 8) |
| El banner se ve bien en PC y mal en móvil (o al revés) | Una sola imagen para los dos formatos | Cláusula 4 del contrato: imagen vertical propia para móvil + patrón `<picture>` (fase 5, 6b) |
| Los pasos 1-2-3 (o cualquier serie) parecen fotos aleatorias | Prompts genéricos compartidos y generación en paralelo | Guion fotográfico + series encadenadas (fase 6): un prompt individual por foto; cada paso usa la foto del anterior como referencia |
| Todas las fotos de la tienda parecen de sesiones distintas | Sin fotos ancla de referencia común y/o sin vocabulario de set | Generar primero las fotos ancla y pasarlas como `--ref` en TODAS las llamadas + definir luz/fondo en 1-2 frases del guion y pegarlas en todos los prompts (fase 6) |
| El producto cambia de forma/color entre fotos | Llamadas sin las anclas como referencia (el modelo se lo inventa) | Fotos ancla (fase 6): 2-3 ángulos aprobados del producto van de referencia en cada llamada |
| Una foto está bien salvo un detalle (logo deformado, objeto raro) | Regenerarla entera es lotería | Retoque con máscara (fase 6): PNG con canal alfa sobre la zona + `--mascara`; si no converge en 2 intentos, regenerar |
| `401` / `429` / `insufficient_quota` al generar | Clave mal / ritmo / sin créditos | Tabla de errores de la fase 6 |
| `moderation_blocked` con `safety_violations=[sexual]` en una foto inocente | Falso positivo del clasificador con persona + producto en boca/mano (boquillas, cosmética...) | Escalera de la fase 6: reformular la acción → `--moderacion low` → cambiar la escena (sin persona); las llamadas bloqueadas no se cobran |
| El modelo pinta un damero o un fondo raro | Se pidió fondo transparente (no existe en gpt-image-2) | Pedir el color de fondo EXACTO de la sección (fase 6, prompts) |

## Push / subida

Primera regla: lee el bloque de error de la salida — dice el archivo. Tabla de
validaciones frecuentes en `08-publicacion.md`. Además:

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| Push "succeeded with errors" | Algunos archivos subieron, los del error no | Corregir y re-push; no informar éxito hasta push limpio |
| Push interactivo se queda esperando | Falta `--theme` y el CLI pregunta | Añadir `--theme <ID>` (sale de `shopify theme list`) |
| "You can't push to a live theme" | Tema de trabajo = tema publicado | Añadir `--allow-live` SOLO si el usuario sabe que va en vivo |
| 401/403 a mitad de push | Sesión caducada | Relanzar (re-login automático) |
| Push lentísimo o cuelga | Muchos assets pesados / antivirus / OneDrive | Comprobar que el proyecto NO está en OneDrive; usar `--only` para subir lo tocado |
| Assets que no se ven tras subir | Caché del navegador | Recargar con Ctrl+F5 / Cmd+Shift+R; verificar en ventana privada |

## Visual (la web "se ve mal")

| Síntoma | Causa típica | Dónde está documentado |
|---|---|---|
| Franja del color de la página entre dos bloques | Fondo pintado en el elemento interno en vez del envoltorio, o héroe cuya imagen no cubre el 100% con fallback blanco | Fase 5, sección 5 (regla de oro) y trampas nº 6; checklist de costuras (fase 5.7) |
| El usuario añade "Espacio superior" y crece de OTRO color | Mismo origen: el fondo no está en el envoltorio que lleva el padding | Fase 5, sección 5.1 y trampa nº 7 |
| Bloque "asfixiado": el texto arranca pegado al borde del bloque | Paddings por defecto a 0 | Fase 5, sección 5.2 (ritmo vertical) |
| Hueco/franja blanca que el usuario no puede quitar con los ajustes | Padding en el elemento interno, o margen del header de Dawn | Fase 5: sección 5.1 y trampa nº 4 |
| Sombras/zoom de tarjetas cortadas | `overflow: hidden` en algún ancestro | Fase 5, trampa nº 2 (`overflow-x: clip` + `overflow-y: visible`) |
| Un elemento con z-index alto no se ve | Contexto de apilamiento por clip-path/transform/filter | Fase 5, trampa nº 3 (pseudo-elemento del que ya está encima) |
| Saltos de línea del editor no aparecen | Falta `newline_to_br` | Fase 5, trampa nº 9 |
| Scroll horizontal en móvil | Decorativos absolutos sin recortar | Fase 5, trampa nº 11 |
| Cambios de ajustes del editor que "no hacen nada" | El CSS pisa el valor del `{% style %}` con `!important`, o el ajuste no está conectado | Conectar el ajuste en el bloque `{% style %}`; evitar `!important` en propiedades expuestas como ajustes |
| La sección no aparece para añadir en el editor | Falta `presets` en el schema | Fase 5, plantilla canónica |
| Bloques que nunca aparecen (invisibles para siempre) | Reveal cuyo IntersectionObserver no se dispara o clase inicial `opacity: 0` sin JS cargado | Revisar `mt-scripts.js` (fase 5.9); fallback: sin JS, los elementos deben ser visibles |

## Página de producto

| Síntoma | Causa típica | Arreglo |
|---|---|---|
| "Añadir al carrito" no hace nada | Falta `{% form 'product' %}` o el `input[name=id]` no tiene id de variante válido | Receta de la fase 7, paso 1.2 |
| Precio no cambia al cambiar variante | El JS no actualiza precio + input id a la vez | Fase 7, paso 1.3 |
| Aparece un selector de variantes vacío | No se comprueba `product.has_only_default_variant` | Fase 7, paso 1.3 |
| La página sale sin datos / producto de ejemplo | El producto no existe o está en borrador, o el template no está asignado | Fase 7, pasos 0 y 3 |
| El usuario no ve la plantilla "mt" en el desplegable | El desplegable lista plantillas del tema PUBLICADO y el vuestro es de trabajo | Normal: previsualizar con `?preview_theme_id=<ID>`; asignar al publicar |
| Carrito/búsqueda con colores "de otra web" | `settings_data.json` sin tematizar | Fase 5, sección "ropa global del tema" |

## Entorno roto a mitad de sesión

- **Se cerró la terminal / Claude Code se reinició**: ejecuta el diagnóstico
  (`scripts/`), lee `ESTADO.md` del proyecto y continúa donde quedó. Para
  encontrar el proyecto: busca `ESTADO.md` bajo `C:\tiendas\` (Windows) o
  `~/tiendas/` (Mac).
- **El usuario borró/movió la carpeta**: re-descarga Dawn (fase 2) y luego
  `shopify theme pull --theme <ID>` para recuperar TODO lo construido desde
  Shopify (por eso publicamos siempre: Shopify es nuestra copia de seguridad).
- **Conflicto: alguien editó desde el editor de Shopify Y nosotros en local**:
  los push machacan lo del editor (los json de settings). Si el usuario ha
  estado retocando desde Shopify, haz `shopify theme pull --theme <ID> --only
  config --only templates` ANTES de tu siguiente tanda de cambios para traerte
  sus retoques.

 dentro de `bash -c`, heredoc sin comillas o `node -e` | Escribe un `.js` en el scratchpad y ejecútalo; heredocs solo con `<<'EOF'` |
| Push "con errores" por `name`/`label`/`header` demasiado largos o `default` fuera de paso | Límites del schema (25/70/50; range/select) | Acorta y ajusta; vuelve a subir |
| "El paralaje no se ve" / "el scroll suave no va" en el panel de pruebas | `prefers-reduced-motion` activado en el panel | Mide con JS tras parchear `matchMedia`; en el navegador del usuario funciona |
| Capturas vacías al hacer scroll con emulación | Limitación del panel | Helper `hsShow` + tamaño natural del panel |
| Flechas de carrusel que saltan al terminar | snap re-imanta a puntos que no coinciden con el destino | `scroll-padding-inline-start` + destinos múltiplos del paso + animación propia (13 §6) |
| Margen del titular "no aplica" | Tu reset `.mt-section h1 { margin:0 }` tiene más especificidad | `.mt-section h1.mt-clase { ... }` |
| El bloque de texto del héroe se centra solo en horizontal | `margin: 0 auto` en hijo de flex-column | `margin:0; width:100%` |
| `/collections/all` muestra la plantilla vieja de Dawn | Colección creada por API no publicada en el canal | Sobrescribe `templates/collection.json` + 2 clics del usuario |
| La IA bloquea el logo por moderación | Falso positivo con palabras/marcas | `recolorear-logo.ps1` en local |
| `Invalid size` al generar | Menos de 655 360 píxeles | Usa tamaños de la lista (13 §11) |

## Cuándo rendirse y escalar al usuario

Casi nunca. Pero si tras 2-3 intentos con métodos distintos algo sigue
fallando (p. ej. una red corporativa que bloquea npm), explica el bloqueo en
una frase sin tecnicismos, da el plan B manual más corto posible, y deja
constancia en `ESTADO.md` de qué pasó y qué falta.

## Material del usuario y referencias (fase 3)

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| El script de inventario no encuentra la carpeta | Ruta con espacios/acentos sin comillas, o unidad de red no montada (`S:` vs `C:`) | Entrecomilla la ruta; si la unidad no existe, pide al usuario que arrastre la carpeta a la ventana o busca el mismo nombre en `C:\Users\<usuario>\` (Escritorio, Descargas, Documentos) |
| Muchas imágenes en `sin-clasificar` | Nombres genéricos (IMG_1234) | Míralas (regla de oro 2) y clasifica a mano; enséñale al usuario en el mensaje 2 lo que decidiste |
| Una "captura de tienda" es en realidad un mockup de Dribbble con marcos de móvil | Referencia de diseño, no captura real | Lee la web DENTRO de las pantallas; ignora los marcos |
| Las referencias se contradicen (una crema, otra negra) | Normal | Método de mezcla de la fase 3.5: lo común es el ADN, el concepto desempata, las fotos del usuario deciden |
| El diseño PNG se ve negro sobre negro en el footer | Tinta negra sobre fondo oscuro | Versión clara (fase 6, "logo en claro") o `filter: invert(1)` solo si es monocromo puro |
| Los mockups del usuario tienen fondo gris y las tarjetas hueso: se ven cuadrados grises | Fondo del mockup ≠ fondo de tarjeta | Ajuste `color_fondo_tarjeta` = color del mockup, o `object-fit: contain`, o mockup regenerado con el fondo de la tienda (fase 6) |
| Las fotos pesan 2-6 MB y el push tarda una eternidad | PNG sin optimizar en `assets/` | `scripts/optimizar-imagen.*` (regla de oro 16); nunca PNG salvo transparencia |
| `optimizar-imagen.ps1` falla con "Add-Type" o GDI+ | PowerShell sin System.Drawing (raro) o imagen corrupta/WebP animado | Prueba con `-ExecutionPolicy Bypass`; convierte esa imagen con el navegador (abrir → guardar como) o pide al usuario otra copia |
| WebP con transparencia sale con fondo blanco | System.Drawing no lee WebP con alfa en todas las versiones | Pide/usa el PNG original; o deja el WebP tal cual si solo es referencia |

## Fotos IA de moda (fase 6)

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| El estampado sale con letras cambiadas ("HUSTLERS", "FOUNDER CLUB") | Falta el archivo del diseño como `--ref` y/o el párrafo de fidelidad con los textos entre comillas | Paquete de referencias completo + párrafo de fidelidad; revisa letra a letra; retoque con máscara si solo falla el estampado |
| Las fotos del estampado (los fundadores) aparecen distintas o de color | Referencia del diseño a baja resolución o sin el mockup | Diseño optimizado a 1200-1600px (no 300px) + mockup plano de esa vista + "fotografías en blanco y negro exactamente como en la referencia" |
| La IA pinta botones, menús o textos de otra web en la escena | Se pasó una captura de tienda como referencia | Nunca capturas a la IA; describe el encuadre con palabras |
| `moderation_blocked` con un prompt de modelo normal | Falso positivo (persona + prenda) o mención a persona real | Reformula sin adjetivos corporales, `--moderacion low`, sin nombres de personas reales; escena sin persona como último recurso |
| El modelo generado se parece a un famoso | Prompt con nombre o descripción demasiado específica | Describe edad/estilo genérico; nunca "como X" |
| Las fotos generadas no casan con las reales del usuario (otro grading) | Anclas de estilo mal elegidas (día vs. noche) | Rota las 2-4 fotos de modelo del usuario más parecidas a la escena; añade el vocabulario de luz de la ficha al prompt |
| El banner generado está bien pero la cabeza del modelo se corta en la web | Zona segura no respetada o posición focal "centro" | Regenera con "aire por encima de la cabeza"; posición focal "arriba"; en fotos reales, `recortar-banner` con `-CentroY 0.25-0.35` |
| Sale un logotipo de coche/marca de terceros muy visible | Prompt con marcas | "coche deportivo negro sin logotipos visibles"; máscara sobre el logo si el resto es bueno |

## Catálogo con varias prendas y apps POD (fase 7)

| Síntoma | Diagnóstico | Arreglo |
|---|---|---|
| Al actualizar `tags` desaparecen las etiquetas anteriores | `productUpdate` reemplaza la lista | Lee las existentes y envía la lista completa |
| Renombré "Size" a "Talla" y la app POD dejó de sincronizar | Las apps mapean por nombre de opción | No renombres opciones de productos creados por apps; traduce la etiqueta en la sección (`etiqueta_talla`) |
| Las fotos subidas aparecen al final, después de las del proveedor | `productCreateMedia` añade al final | Reordena con `productReorderMedia` o elimina las del proveedor con permiso del usuario |
| La colección aparece vacía en la portada | Handle equivocado en `settings.collection` o colección automática sin coincidencias | Copia el handle exacto de `leer-colecciones`; revisa la regla (`ruleSet`) o usa colección manual |
| El bloque de colección muestra el producto de ejemplo de Dawn | Tienda sin productos: `collections['all']` vacío y el editor pinta placeholders | Normal en el editor; en la web real no se ve nada roto si el fallback está bien (fase 5, trampa 13) |
| El producto está en DRAFT y la web muestra 404 | Producto no activo | `status: ACTIVE` con `actualizar-producto` (avisando al usuario) |
| Las variantes vienen con precio 0 tras `productCreate` | Comportamiento esperado | `variantes-actualizar-precio.graphql` para todas |
| `productOptions` desconocido en `productCreate` | Versión de API antigua | Ver "Si una orden falla por versión" en `10-admin-api.md` |
