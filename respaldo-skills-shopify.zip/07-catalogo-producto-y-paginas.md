# Fase 7 — Catálogo (productos y colecciones), página de producto de prenda, colección, header, footer y legales

Regla central: **la tienda de ropa se entrega con colección + producto +
tallas, todo asignado automáticamente** con la Admin API
(`references/10-admin-api.md`). El usuario no va al panel a asignar
plantillas, pegar textos ni subir fotos: lo haces tú.

## 1. Catálogo: dejar productos y colecciones como deben estar

### 1.1 Productos existentes (AutoDS o creados a mano)

Por cada producto leído en la fase 1:

1. **Título y descripción**: redacta tú el título vendedor y la descripción
   en HTML simple (intro con el concepto, tejido/gramaje si lo sabes por el
   usuario, corte, cuidados, "diseñado en X, impreso bajo demanda" si aplica)
   y guárdalos con `actualizar-producto.graphql` (`title`, `descriptionHtml`).
   Si la descripción actual es del proveedor (genérica), sustitúyela; si el
   usuario escribió la suya, respétala y solo mejora el formato.
2. **Fotos**: sube las del usuario (mockup frontal, trasera, natural,
   detalle, 1-3 de modelo) a la galería del producto (`10`, apartado 5) en
   este orden: la que mejor enseñe el diseño protagonista primero (en
   streetwear suele ser la TRASERA), luego frontal, modelo, detalle. La
   primera es la de la tarjeta; la segunda, la del hover. Si el proveedor
   dejó mockups genéricos y hay fotos mejores, puedes dejar los del
   proveedor al final o eliminarlos (`productDeleteMedia`, solo si el
   usuario lo aprueba: los POD a veces los regeneran).
3. **Opciones**: comprueba que la opción de talla existe y con qué nombre
   ("Size"/"Talla"). Si el usuario quiere la tienda en español y la opción
   se llama "Size", NO la renombres en apps POD (rompe el mapeo del
   proveedor): traduce la ETIQUETA en la sección de producto (ajuste
   `etiqueta_talla`).
4. **Estado**: si está en DRAFT y el usuario quiere vender, `status: ACTIVE`
   con `actualizar-producto` (avísale).
5. **Plantilla**: `templateSuffix: "<prefijo>"` (ver 3).
6. **Etiquetas** (`tags`): añade `nuevo`/`drop-01` si la tarjeta muestra
   badges por etiqueta (fase 5, 11.2). Cuidado: `productUpdate` con `tags`
   REEMPLAZA las etiquetas; lee las existentes y envía la lista completa.
7. **Precio**: si el usuario dijo un precio distinto,
   `variantes-actualizar-precio.graphql` para TODAS las variantes.

### 1.2 Sin productos

- Con una app POD: mejor que el producto lo cree la app. Deja la tienda
  lista y anota el pendiente. Cuando exista, repite 1.1.
- Sin app y con datos del usuario (nombre, precio, tallas, fotos): créalo con
  `crear-producto.graphql` (opciones y variantes, ver `10`, apartado 6),
  sube fotos y asigna plantilla. Inventario: si no gestiona stock, deja
  `inventoryPolicy: CONTINUE` o el seguimiento desactivado.

### 1.3 Colecciones

- Crea la colección principal ("Todo"/"All"/"Shop", en el idioma de la
  tienda) con `crear-coleccion.graphql` + `anadir-productos-a-coleccion`
  (o hazla automática por condición `tag`/`vendor` si prefieres que crezca
  sola — `ruleSet` en el `CollectionInput`).
- Colecciones por drop o tipo si el concepto lo pide ("Drop 01", "Tees",
  "Hoodies"). Imagen de colección: una foto del usuario o generada
  (`collectionUpdate` con `image`), la usará el bloque "comprar por
  categoría".
- `templateSuffix` de la colección = tu plantilla (ver 3).
- Guarda los handles en `ESTADO.md`: son los valores por defecto de los
  ajustes `collection` de las secciones.

## 2. Página de producto de prenda — receta completa (donde más se falla)

### Cómo funciona

- Template `templates/product.<prefijo>.json` (alternativo; el de Dawn sigue
  intacto). Sufijo = lo que va entre `product.` y `.json`.
- Los datos (título, precio, fotos, variantes, stock) vienen del catálogo
  vía el objeto `product`. Tú construyes el escaparate.

### Paso 1 — La sección `mt-producto.liquid`

Bloques funcionales, todos editables:

1. **Galería**: fotos del producto (`product.media`), layout según la ficha
   (miniaturas verticales a la izquierda + grande; o grid de dos columnas
   estilo editorial; o carrusel en móvil con scroll-snap). Zoom al hover o
   clic opcional. Usa `product.media`, no image_pickers: así sigue al
   catálogo.
2. **Columna de compra** (sticky en escritorio si la ficha lo pide):
   etiqueta pequeña editable ("DROP 01 · XXI CENTURY"), título
   (`product.title`), precio dinámico
   (`product.selected_or_first_available_variant.price | money`, con tachado
   si hay `compare_at_price`), frase corta de material (metafield
   `custom.material` o ajuste), y el formulario:

   ```liquid
   {% form 'product', product, id: 'mt-form', class: 'mt-form' %}
     <input type="hidden" name="id" value="{{ product.selected_or_first_available_variant.id }}">
     <!-- selector de talla (paso 1.3) -->
     <button type="submit" name="add" class="mt-btn mt-btn--principal"
       {% if product.selected_or_first_available_variant.available == false %}disabled{% endif %}>
       {{ section.settings.boton_texto }}
     </button>
   {% endform %}
   ```

3. **Selector de talla (y color si existe)** — el fallo nº 1:

   ```liquid
   {%- unless product.has_only_default_variant -%}
     {%- for option in product.options_with_values -%}
       <fieldset class="mt-opcion" data-opcion="{{ forloop.index0 }}">
         <legend class="mt-etiqueta">
           {%- if option.name == 'Size' -%}{{ section.settings.etiqueta_talla }}{%- else -%}{{ option.name }}{%- endif -%}
           {%- if option.name == 'Size' or option.name == 'Talla' -%}
             <button type="button" class="mt-link" data-abrir-tallas>{{ section.settings.texto_guia }}</button>
           {%- endif -%}
         </legend>
         {%- for value in option.values -%}
           <label class="mt-talla">
             <input type="radio" name="opcion-{{ forloop.parentloop.index0 }}" value="{{ value | escape }}"
               {% if option.selected_value == value %}checked{% endif %}>
             <span>{{ value }}</span>
           </label>
         {%- endfor -%}
       </fieldset>
     {%- endfor -%}
     <script type="application/json" data-variantes>{{ product.variants | json }}</script>
   {%- endunless -%}
   ```

   JS (en `mt-scripts.js`, idempotente): al cambiar cualquier radio, compone
   las opciones seleccionadas, busca en `data-variantes` la variante cuyo
   `options` coincida, y actualiza `input[name=id]`, el precio (`price` en
   céntimos → formatea con `Shopify.formatMoney` si existe o con
   `Intl.NumberFormat` y `Shopify.currency`), el estado del botón
   (`available`), y marca como agotadas (clase `mt-talla--agotada`, tachada)
   las tallas sin stock para la combinación actual. Prueba mentalmente los
   dos caminos: con variantes y con variante única (sin selector, sin script).
4. **Confianza**: fila de 3-4 garantías editables con iconos SVG inline
   (envío, cambios 30 días, pago seguro, impreso bajo demanda).
5. **Acordeones editables**: "Tejido y corte", "Guía de tallas" (tabla del
   patrón 11.4 de la fase 5, también accesible desde el enlace del selector),
   "Cuidados", "Envíos y devoluciones". Textos en el schema; respaldo con
   `product.description`.
6. **Historia del diseño** (corta): 2-3 frases + enlace al bloque largo de la
   portada, o el bloque completo si el producto es único.
7. **Completa el look / relacionados**: `product_list` (elegidos a mano) o
   los productos de la misma colección (`collections[handle].products`
   excluyendo el actual). Reutiliza el snippet de tarjeta.
8. **Botón sticky en móvil**: barra inferior fija con precio + "Añadir" que
   aparece al hacer scroll más allá del botón principal (dispara el submit
   del mismo formulario).
9. Reutiliza secciones narrativas de la portada (lookbook, reseñas, FAQ)
   añadiéndolas al template.

### Paso 2 — El template

```json
{
  "sections": {
    "principal": { "type": "mt-producto", "settings": {} },
    "lookbook":  { "type": "mt-lookbook", "settings": {} },
    "relacionados": { "type": "mt-coleccion", "settings": { "collection": "todo", "max_productos": 4 } }
  },
  "order": ["principal", "lookbook", "relacionados"]
}
```

### Paso 3 — Asignar la plantilla a TODOS los productos (automático)

`actualizar-producto.graphql` con `templateSuffix: "<prefijo>"` por cada
producto (`10`, apartado 4). Revisa `userErrors`. Se puede asignar aunque el
tema aún no esté publicado. Plan B sin permisos: 3 clics en el panel por
producto (Productos → producto → Plantilla de tema → elegir → Guardar), con
la nota de que el desplegable lista plantillas del tema PUBLICADO.

### Checklist de la página de producto

- [ ] Precio real y dinámico; cambia con la talla si hay precios distintos
- [ ] "Añadir al carrito" añade la TALLA elegida (compruébalo en la
      previsualización abriendo el carrito) y el cajón de Dawn se abre
- [ ] Tallas agotadas se ven claramente; producto agotado → botón
      deshabilitado con texto claro
- [ ] Variante única → sin selector vacío, sin errores de JS
- [ ] Galería funciona con 1 foto y con 10; miniaturas accesibles
- [ ] Guía de tallas abre y cierra con ratón y teclado; tabla editable
- [ ] Móvil: galería en carrusel, columna de compra debajo, botón sticky
- [ ] Todo editable; plantilla asignada a todos los productos

### Lo aprendido en producción (detalle en `13` §8)

- `.mt-form { display:flex; flex-direction:column; gap:24px }`: el
  `<form>` no hereda el gap y el botón sale pegado a las tallas.
- Opciones de un solo valor (color único) ocultas con `[hidden]` +
  `display:none !important`.
- Descripción del producto guardada como HTML estructurado (párrafo +
  etiqueta "Details" + lista) y estilizada (guiones, aire). El reset de
  `ul` deja todo en bloque si no lo haces.
- Plazos de POD: "7–14 business days" salvo que el usuario diga otra cosa.
- Fotos del proveedor: elimínalas (`producto-eliminar-media.graphql`)
  cuando el usuario lo pide o cuando las suyas son claramente mejores;
  avísale.
- Cambios de precio: `variantes-actualizar-precio` a todas las variantes.

## 3. Plantilla de colección (`templates/collection.<prefijo>.json`)

Sección `mt-coleccion-cabecera` (título de la colección, descripción
editable con respaldo `collection.description`, imagen de la colección o
banner bajo contrato, nº de prendas "06 PIEZAS") + sección
`mt-coleccion-grid` (grid con el snippet de tarjeta, columnas editables,
orden por defecto, filtro por talla opcional usando los filtros nativos de
Dawn `collection.filters` si el catálogo es grande). Asigna
`templateSuffix` a cada colección (`actualizar-coleccion.graphql`). El
enlace "ver toda la colección" de la portada apunta a `collection.url`.

**Importante:** la colección creada por Admin API NO queda publicada en el
canal Tienda online (haría falta `write_publications`). `/collections/all`
cae en la colección automática de Shopify con la plantilla por defecto →
**sobrescribe también `templates/collection.json`** con tus secciones y
dile al usuario en 2 clics dónde activar el canal (Productos → Colecciones →
la tuya → Canales de venta → Tienda online).

## 4. Header (cabecera)

Personaliza `sections/header.liquid` de Dawn (excepción a "no tocar Dawn")
según la ficha:

- **Logo por sección**: `image_picker` `logo` + `range` `logo_width`; usa
  `assign active_logo = section.settings.logo | default: settings.logo` en
  todas las ramas donde Dawn pinta el logo. Si la ficha dice "logo grande
  centrado" o "logo izquierda y menú en mayúsculas", ajusta
  `logo_position` y el CSS.
- **Transparente sobre el héroe** si la ficha lo pide: clase en `body` cuando
  el template es `index` y el primer bloque es el héroe; el header pasa a
  fondo sólido al hacer scroll (JS con `IntersectionObserver` sobre un
  centinela). Expón el ajuste `transparente_en_portada` (checkbox).
- **Barra de anuncio**: la de Dawn (`announcement-bar`) o tu marquesina
  (fase 5, 11.6) si la ficha tiene marquesina arriba.
- **Iconos**: contador de bolsa "BAG 00" tipográfico si la ficha lo tiene
  (`cart.item_count` formateado con dos dígitos).
- Menú: se gestiona en Contenido → Menús. Crea tú las páginas/colecciones y
  dile en 2 pasos qué marcar, o deja el menú con "Tienda / Lookbook / Sobre
  la marca / Contacto" si puedes editarlo (los menús no se editan por
  Admin API con estos permisos: son 2 clics del usuario, díselo al final).

## 5. Footer (pie)

Reescribe `sections/footer.liquid` como sección propia según la ficha:
logo gigante o columna de marca, 2-3 columnas de enlaces (pares texto+url,
sin `default` en `url`), newsletter SOLO si el usuario lo pide (usa
`{% form 'customer' %}` de Dawn para que funcione de verdad), iconos de pago
(`shop.enabled_payment_types`), copyright dinámico, legales a
`/policies/...`, frase de cierre editable ("WE MAKE ATTITUDE." estilo de la
ficha), selectores de país/idioma opcionales.

## 6. Páginas legales, guía de tallas global y otras páginas

- Políticas nativas: `/policies/privacy-policy`, `/policies/terms-of-service`,
  `/policies/refund-policy`, `/policies/shipping-policy` (Configuración →
  Políticas → "Crear a partir de plantilla", 3 pasos para el usuario).
- Cookies y aviso legal: redáctalos tú (base, no asesoría legal) y créalos
  como páginas o dáselos para pegar.
- **Guía de tallas como página** (`templates/page.tallas.json` con la
  sección de tabla) enlazada desde el footer y desde el producto, útil
  cuando hay varias prendas con tablas distintas (una tabla por bloque).
- **Sobre la marca / Manifiesto**: `templates/page.sobre.json` con el bloque
  de historia del diseño + lookbook. En marcas con concepto, esta página
  vende.
- Contacto: `contact-form` de Dawn o sección propia.
- Ropa POD: página "Cómo se fabrica" (impresión bajo demanda, tiempos) si
  el usuario lo quiere; evita prometer plazos que no controla.

## 7. Favicon y pestaña

Cuadrado del logo/monograma (del diseño frontal recortado o generado en
fase 6 a `1024x1024` con el fondo de la ficha) → `assets/mt-favicon.png`
(≤512px) → `<link rel="icon">` en `layout/theme.liquid` antes del favicon
condicional de Dawn. Título y descripción de la home: redáctalos y dile
dónde pegarlos (Tienda online → Preferencias) en 2 pasos.

## Cierre de la fase

`ESTADO.md`: productos actualizados (qué se escribió, qué fotos se
subieron, plantilla asignada), colecciones (handles, plantilla), páginas
creadas, pendientes del lado del usuario (menú, políticas, contraseña de
tienda, activar productos). Pasa a `references/08-publicacion.md`.
