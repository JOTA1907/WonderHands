# 🔌 Admin API — leer y escribir productos, colecciones, fotos y plantillas

Cómo leemos el catálogo del usuario y cómo escribimos en él (títulos,
descripciones, fotos, plantillas, colecciones, precios), todo con el Shopify
CLI ya instalado. Léela entera antes de tocar datos.

> Tono: al usuario nunca "Admin API", "GraphQL", "mutación" ni "token". Para
> él es "leer tus productos" y "guardar los cambios en tu tienda".

## Las dos órdenes

```
shopify store auth    --store NOMBRE.myshopify.com --scopes read_products,write_products,read_files,write_files
shopify store execute --store NOMBRE.myshopify.com --query-file <archivo.graphql> [--variables '<json>' | --variable-file <ruta.json>] [--allow-mutations] [--json] [--output-file <ruta>]
```

- `store auth`: un clic en el navegador; guarda un token con los permisos
  pedidos (`read/write_products` cubren productos Y colecciones;
  `read/write_files` para subir fotos). Desde CLI 3.93.1 los permisos ya
  concedidos se conservan al re-autorizar.
- `store execute`: ejecuta una consulta u orden con ese token.

### Reglas imprescindibles

1. Los CAMBIOS exigen `--allow-mutations`.
2. **Revisa SIEMPRE `userErrors`** (o `mediaUserErrors`): la orden puede
   "terminar bien" sin hacer nada.
3. `--json` para parsear; en Windows, `--output-file` para salidas largas
   (los productos con 50 imágenes rompen la pantalla de PowerShell).
4. Token online, caduca a las ~24 h: ante 401, repite `store auth`.
5. Windows: usa `--query-file` y `--variable-file` (archivos), nunca JSON en
   línea con comillas.
6. Versión de API: la última estable por defecto. Si una orden falla con
   `Unknown argument "product"`, ver "Si falla por versión".
7. **Los archivos GraphQL viven en la skill** (`<ruta-skill>/scripts/gql/`);
   los de variables (`.tmp-*.json`) los escribes tú en el proyecto y los
   borras al terminar.

## 1) Leer productos y colecciones (sondeo, fase 1)

```
shopify store execute --store NOMBRE.myshopify.com \
  --query-file <ruta-skill>/scripts/gql/leer-productos.graphql \
  --variables '{"n": 50}' --json --output-file <proyecto>/.tmp-productos.json

shopify store execute --store NOMBRE.myshopify.com \
  --query-file <ruta-skill>/scripts/gql/leer-colecciones.graphql \
  --variables '{"n": 20}' --json --output-file <proyecto>/.tmp-colecciones.json
```

De cada producto guarda en `ESTADO.md`: `id`, `handle`, `title`, `status`,
`options` (nombres y valores: aquí ves si la talla se llama "Size" o
"Talla"), nº de variantes y precios, `images` (URLs), `tags`,
`templateSuffix`, colecciones. De cada colección: `id`, `handle`, `title`,
nº de productos, `templateSuffix`.

## 2) Descargar las fotos de los productos

```
node <ruta-skill>/scripts/descargar-imagenes.mjs \
  --carpeta <proyecto>/fotos-catalogo/<handle> \
  --url "https://cdn.shopify.com/.../1.jpg" --url "https://cdn.shopify.com/.../2.jpg"
```

(O `--lista archivo.txt` con una URL por línea.) Míralas y compáralas con las
del usuario (fase 3).

## 3) Escribir título, descripción, estado, etiquetas y plantilla de un producto

`scripts/gql/actualizar-producto.graphql` (`productUpdate(product: ...)`):

```
shopify store execute --store NOMBRE.myshopify.com \
  --query-file <ruta-skill>/scripts/gql/actualizar-producto.graphql \
  --variable-file <proyecto>/.tmp-actualizar.json --allow-mutations --json
```

`.tmp-actualizar.json`:

```json
{
  "product": {
    "id": "gid://shopify/Product/1234567890",
    "title": "HSTLRS Founders Club Tee — Blanco",
    "descriptionHtml": "<p>Camiseta oversized de algodón grueso...</p><ul><li>Corte oversized</li><li>Estampado trasero con los cinco fundadores</li></ul>",
    "status": "ACTIVE",
    "tags": ["nuevo", "drop-01", "camiseta"],
    "templateSuffix": "hs"
  }
}
```

- Envía SOLO los campos que quieras cambiar. **`tags` reemplaza la lista
  entera**: incluye las existentes que quieras conservar.
- Repite por cada producto (un `.tmp` por producto o un bucle).
- `status`: ACTIVE / DRAFT / ARCHIVED.
- Plan B sin permisos: textos listos para pegar + 3 clics por producto.

## 4) Asignar la plantilla de producto a TODOS los productos

Mismo archivo, solo `id` + `templateSuffix` (sufijo de
`templates/product.<sufijo>.json`). Se puede hacer con el tema sin publicar;
previsualiza con `?preview_theme_id=<ID>`. Anota en `ESTADO.md` qué productos
quedaron asignados.

## 5) Subir fotos locales a la galería de un producto (tres pasos)

**A — pedir destino de subida** (`staged-uploads-create.graphql`), una
entrada por foto:

```json
{ "input": [
  { "filename": "hs-trasera.jpg", "mimeType": "image/jpeg", "httpMethod": "POST", "resource": "IMAGE" },
  { "filename": "hs-frontal.jpg", "mimeType": "image/jpeg", "httpMethod": "POST", "resource": "IMAGE" }
] }
```

```
shopify store execute --store NOMBRE.myshopify.com \
  --query-file <ruta-skill>/scripts/gql/staged-uploads-create.graphql \
  --variable-file <proyecto>/.tmp-staged.json --allow-mutations --json --output-file <proyecto>/.tmp-staged-out.json
```

**B — subir cada archivo** al destino (no usa Shopify):

```
node <ruta-skill>/scripts/subir-foto.mjs --destino <proyecto>/.tmp-staged-out.json --indice 0 --foto <proyecto>/material/prenda-x/hs-trasera.jpg
node <ruta-skill>/scripts/subir-foto.mjs --destino <proyecto>/.tmp-staged-out.json --indice 1 --foto <proyecto>/material/prenda-x/hs-frontal.jpg
```

Imprime `OK <resourceUrl>` por archivo.

**C — adjuntar al producto** (`producto-crear-media.graphql`). El ORDEN de
la lista `media` es el orden en la galería (la primera será la foto de la
tarjeta; la segunda, la del hover):

```json
{
  "productId": "gid://shopify/Product/1234567890",
  "media": [
    { "originalSource": "<resourceUrl 0>", "mediaContentType": "IMAGE", "alt": "HSTLRS tee — vista trasera con el estampado Founders Club" },
    { "originalSource": "<resourceUrl 1>", "mediaContentType": "IMAGE", "alt": "HSTLRS tee — vista frontal" }
  ]
}
```

Revisa `mediaUserErrors`. Las imágenes se procesan en segundo plano (unos
segundos). Las fotos nuevas se AÑADEN al final de la galería existente: si
quieres que las del usuario vayan primero y las del proveedor después, o
bien eliminas las del proveedor (`productDeleteMedia`, con permiso del
usuario) o reordenas (`productReorderMedia` con la lista de `id` de media en
el orden deseado — consulta la firma actual en shopify.dev si la necesitas).

Sube al producto SOLO lo que deba salir en su galería; lo decorativo
(héroe, lookbook) va en `assets/`.

## 6) Crear un producto (solo sin app POD y con datos del usuario)

`scripts/gql/crear-producto.graphql` (`productCreate(product: ...)`):

```json
{
  "product": {
    "title": "HSTLRS Founders Club Tee",
    "descriptionHtml": "<p>...</p>",
    "vendor": "HSTLRS",
    "productType": "Camiseta",
    "status": "DRAFT",
    "tags": ["nuevo"],
    "templateSuffix": "hs",
    "productOptions": [
      { "name": "Talla", "values": [ { "name": "S" }, { "name": "M" }, { "name": "L" }, { "name": "XL" } ] }
    ]
  }
}
```

Shopify crea una variante por valor de la opción con precio 0. Después fija
los precios con `variantes-actualizar-precio.graphql`:

```json
{
  "productId": "gid://shopify/Product/...",
  "variants": [
    { "id": "gid://shopify/ProductVariant/...", "price": "39.90" },
    { "id": "gid://shopify/ProductVariant/...", "price": "39.90" }
  ]
}
```

(Los `id` de variante vienen en la respuesta de `productCreate`.) Luego
fotos (apartado 5) y `status: ACTIVE` cuando el usuario lo apruebe. Si en
tu versión de API `productOptions` no crea variantes automáticamente, usa
`productVariantsBulkCreate` con `strategy: REMOVE_STANDALONE_VARIANT`
(consulta la firma en shopify.dev).

## 7) Colecciones

**Crear** (`crear-coleccion.graphql`, `collectionCreate(input: ...)`):

```json
{
  "input": {
    "title": "Todo",
    "handle": "todo",
    "descriptionHtml": "<p>Todas las prendas HSTLRS.</p>",
    "templateSuffix": "hs",
    "products": ["gid://shopify/Product/1", "gid://shopify/Product/2"]
  }
}
```

O automática por regla (crece sola con cada producto nuevo):

```json
{
  "input": {
    "title": "Todo",
    "handle": "todo",
    "templateSuffix": "hs",
    "ruleSet": { "appliedDisjunctively": false, "rules": [ { "column": "VENDOR", "relation": "EQUALS", "condition": "HSTLRS" } ] }
  }
}
```

**Actualizar** (`actualizar-coleccion.graphql`): título, descripción,
`templateSuffix`, `image` (`{ "src": "<URL pública>", "altText": "..." }` —
para una foto local, súbela primero como en el apartado 5 y usa el
`resourceUrl`).

**Añadir productos** a una colección manual
(`anadir-productos-a-coleccion.graphql`): `{ "id": "gid://shopify/Collection/...", "productIds": [ ... ] }`.

La colección "Home page"/"Página de inicio" que traen las tiendas nuevas no
la toques; la tuya se llama como decida la ficha.

## 7b) Eliminar fotos del proveedor y leer media

`leer-media-producto.graphql` (`{ "id": "gid://shopify/Product/..." }`)
devuelve los `MediaImage` ids (distintos de los `ProductImage` de
`leer-productos`). `producto-eliminar-media.graphql`:

```json
{ "productId": "gid://shopify/Product/...", "mediaIds": ["gid://shopify/MediaImage/...", "..."] }
```

Revisa `mediaUserErrors`. Hazlo cuando el usuario pida usar SUS fotos o
cuando las del proveedor sean claramente peores (avisando).

## 7c) Publicación en canales

No pedimos `write_publications`: las colecciones creadas por API no se ven
en la tienda hasta que el usuario activa el canal (2 clics). Cubre el hueco
con `templates/collection.json` (fase 7 §3).

## 8) Borra los temporales

Los `.tmp-*.json` contienen IDs, no secretos, pero no aportan nada:
bórralos al terminar. La clave de OpenAI vive solo en `clave-openai.txt`.

## Si una orden falla por versión de la API

Las órdenes usan la forma moderna (`productUpdate(product:)`,
`productCreate(product:)`, `productOptions`). Si el CLI se queja de
argumento desconocido, la tienda está en una versión antigua: reintenta con
`--version` reciente, o usa la forma `input:` (`ProductInput`) sustituyendo
la clave `product` por `input` en las variables.

## Resumen de archivos GraphQL incluidos

| Archivo | Para qué |
|---|---|
| `leer-productos.graphql` | Leer productos (opciones, variantes, fotos, tags, colecciones, plantilla) |
| `leer-colecciones.graphql` | Leer colecciones y sus productos |
| `actualizar-producto.graphql` | Título, descripción, estado, tags, plantilla |
| `variantes-actualizar-precio.graphql` | Precios / precio tachado de varias variantes |
| `crear-producto.graphql` | Crear producto con opción de talla (sin app POD) |
| `crear-coleccion.graphql` | Crear colección manual o automática |
| `actualizar-coleccion.graphql` | Descripción, imagen, plantilla de colección |
| `anadir-productos-a-coleccion.graphql` | Añadir productos a una colección manual |
| `staged-uploads-create.graphql` | Destinos para subir fotos locales |
| `producto-crear-media.graphql` | Adjuntar fotos subidas a la galería |
