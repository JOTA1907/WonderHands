# Fase 1 — Un solo mensaje de arranque + conexión + sondeo del catálogo

Objetivo: con UN mensaje del usuario tener todo lo que necesitas para trabajar
horas sin molestarle: la tienda, el concepto, la carpeta de imágenes y (si
quiere) la clave de imágenes. Después: dos logins (un clic cada uno) y la
lectura de lo que ya haya en la tienda (productos, colecciones).

## El mensaje de arranque (mensaje 1) — pide SOLO lo que falte

Antes de escribir nada, mira qué ha dado ya el usuario (a menudo el primer
mensaje trae el concepto entero y la carpeta ya está en el directorio de
trabajo). **No repitas preguntas cuya respuesta ya tienes.** Si la carpeta
ya está, haz el inventario y la lectura ANTES del mensaje 1 y confirma en
3-5 líneas qué has encontrado (así el usuario ve que has mirado su
material y corrige desde el principio). El mensaje 1 queda entonces en:
lo que falta (normalmente la dirección de la tienda y la clave opcional) +
las 2-3 dudas que bloquean, cada una con tu valor por defecto.

Versión completa (cuando no ha dado nada). Adáptala al tono del usuario,
pero mantén las cuatro piezas y el orden:

> "¡Vamos a montar tu tienda de ropa! Para no tener que interrumpirte luego,
> pásame en un solo mensaje estas cuatro cosas (la última es opcional):
>
> 1. **La dirección de tu tienda de Shopify.** Con el panel de Shopify
>    abierto, copia lo que hay en la barra del navegador (algo como
>    `admin.shopify.com/store/NOMBRE`).
> 2. **El concepto de tu marca, con tus palabras** (puedes dictarlo): qué
>    marca es, qué prendas vendes, a quién, y qué sensación quieres que dé
>    (por ejemplo "streetwear refinado, dinero joven, emprendedores, old
>    money"). Si tienes nombre, eslogan o idioma decidido, dímelo.
> 3. **La carpeta de tu ordenador con tus imágenes.** Vale una carpeta con
>    subcarpetas o varias rutas. Lo ideal es que dentro haya: capturas de
>    tiendas o webs cuyo estilo te gusta (las uso como referencia de diseño),
>    tus fotos de las prendas (mockups, fotos con modelo, detalles) y los
>    archivos del diseño o logo si los tienes. No hace falta que esté
>    ordenado: yo lo clasifico y te digo qué he entendido.
> 4. **(Opcional) Una clave de OpenAI** si quieres que además genere fotos
>    nuevas de campaña (banners, escenas con modelo, detalles) a partir de tu
>    diseño y tus fotos. Cuesta unos 2-3 € en créditos. Si no la tienes o
>    prefieres no usarla, no pasa nada: monto la tienda con tus fotos y dejo
>    los huecos preparados para que subas más cuando quieras.
>
> Con eso me pongo a trabajar y no te molesto hasta tener una propuesta
> visual para enseñarte. Puedes irte a hacer otra cosa."

Si ya sabes de antemano que no tiene clave o que la tendrá después, no
insistas: la fase 6 se puede hacer más tarde en una sesión de cambios.

### Cuando el material es escaso o poco "curado"

La skill debe funcionar igual de bien con 5 archivos sueltos que con 28
clasificados. Regla: **cada carencia tiene una respuesta autónoma y, como
mucho, una pregunta de una línea con valor por defecto** (tabla en
SKILL.md, "Material escaso"). Ejemplos de mensaje 1 en esos casos:

> "He visto tu diseño y 3 fotos de la camiseta. No hay fotos con modelo ni
> tiendas de referencia: no pasa nada. Te propongo generar 6-8 fotos con
> modelo a partir de tu diseño (necesito una clave de OpenAI, unos 3 €) y
> arrancar con la dirección de estilo que mejor casa con tu concepto; en la
> propuesta te enseño 3 direcciones y eliges con una palabra. Solo necesito
> la dirección de tu tienda de Shopify."

> "Solo tengo el diseño en PNG. Con eso monto la tienda entera y genero los
> mockups y las fotos de campaña. Pásame la dirección de tu tienda y, si
> quieres fotos, una clave de OpenAI."

Nunca pidas "más fotos" como condición para empezar: empieza con lo que
hay y deja los huecos editables anotados en pendientes.

### Si contesta a medias

- **Sin carpeta de referencias** (solo fotos de prenda): sigue. La ficha de
  estilo saldrá del concepto + de sus propias fotos de modelo (que ya tienen
  una estética) + del catálogo de "estilos de moda" de la fase 3, sección 6.
  Díselo en el mensaje 2: "no me pasaste tiendas de referencia, así que he
  partido de tus fotos y del concepto; si tienes alguna web que te guste,
  pásamela y ajusto".
- **Sin fotos de prenda** (solo referencias y concepto): construye igualmente
  con huecos editables y, si dio clave, genera fotos a partir del diseño
  (fase 6). Si tampoco hay diseño, avisa de que las fotos de prenda son lo
  único que no puedes inventar bien y pídelas para la siguiente tanda.
- **Sin tienda todavía**: ver abajo.
- **Carpeta con espacios/acentos** (lo normal: "HSTLRS Club", "Diseño
  Frontal.png"): funciona, los scripts la aceptan entre comillas. Tú COPIAS
  lo necesario al proyecto con nombres limpios (fase 3), nunca renombras lo
  suyo.

### ¿Y si no tiene tienda todavía?

Es lo ÚNICO que no puedes hacer tú (requiere registrarse y elegir plan):

> 1. Entra en shopify.com y pulsa "Empezar prueba gratis".
> 2. Sigue los pasos con tu correo. Cuando pregunte qué vas a vender, di
>    "ropa" o cualquier cosa — se cambia luego.
> 3. Cuando veas el panel (menú con "Pedidos", "Productos"...), pégame la
>    dirección de la barra del navegador.

Si usa AutoDS (o cualquier app de print-on-demand):
puede conectarla antes o después, no bloquea nada. Si ya la conectó, los
productos aparecerán en el sondeo con las fotos del proveedor; los mejoraremos
con sus fotos (fase 7).

## Normalizar el dominio

De `admin.shopify.com/store/cebgq0-sc` el dominio es `cebgq0-sc.myshopify.com`.
Acepta cualquier formato y normalízalo tú. Guárdalo en `ESTADO.md`.

## Dos sesiones, un mismo estilo de login

Avisa ANTES:

> "Ahora voy a conectar con tu tienda. Se abrirá tu navegador una o dos veces
> para que des permiso: 1) inicia sesión con tu cuenta de Shopify, 2) pulsa
> el botón de autorizar/conectar, 3) vuelve aquí. Yo espero lo que haga falta."

### Sesión A — tema (construir y subir el diseño)

```
shopify theme list --store NOMBRE.myshopify.com
```

- Timeout generoso (3-5 min) o en segundo plano: espera al login.
- Si el navegador no se abre solo, la salida trae la URL — pásasela.
- Éxito = tabla de temas (guarda los IDs en `ESTADO.md`).

### Sesión B — datos de la tienda (productos, colecciones, fotos)

```
shopify store auth --store NOMBRE.myshopify.com --scopes read_products,write_products,read_files,write_files
```

- `read_products`/`write_products` cubren productos Y colecciones.
- Si rechaza permisos, sigue con planes B (fase 7 + `10-admin-api.md`), pero
  intenta siempre esta sesión primero.

## Sondeo del catálogo (varias prendas, colecciones)

Con la sesión B lista, lee productos y colecciones (detalle en
`references/10-admin-api.md`):

```
shopify store execute --store NOMBRE.myshopify.com \
  --query-file <ruta-skill>/scripts/gql/leer-productos.graphql \
  --variables '{"n": 50}' --json --output-file <proyecto>/.tmp-productos.json

shopify store execute --store NOMBRE.myshopify.com \
  --query-file <ruta-skill>/scripts/gql/leer-colecciones.graphql \
  --variables '{"n": 20}' --json --output-file <proyecto>/.tmp-colecciones.json
```

(En Windows usa `--output-file` y lee el archivo: evita que PowerShell
maquee el JSON largo.)

Interpreta el resultado:

### Caso A — HAY productos

1. Lista todos en `ESTADO.md`: `id`, `handle`, título, estado (ACTIVE/DRAFT),
   opciones (¿tiene Talla? ¿Color?), nº de variantes, precio, nº de fotos,
   colecciones a las que pertenece, y si la descripción parece de proveedor
   (texto genérico de AutoDS: "100% cotton, unisex, size chart...").
2. **Descarga las fotos de cada producto** a
   `<proyecto>/fotos-catalogo/<handle>/` con `scripts/descargar-imagenes.mjs`.
3. **Míralas** y compáralas con las de la carpeta del usuario (fase 3): casi
   siempre las del usuario son mejores (mockups limpios, modelos) y las del
   catálogo son mockups genéricos del proveedor. Anota qué producto se
   corresponde con qué diseño de la carpeta (por el estampado).
4. Detecta la estructura de tallas: la mayoría de POD crean opción "Size"
   con S-XXL y a veces "Color". Guarda los nombres exactos de las opciones:
   los necesitarás para el selector de talla (fase 7).
5. Decide (y propón en el mensaje 2) cuál es la **prenda estrella** (la del
   héroe) si hay varias.

### Caso B — NO hay productos

La tienda está vacía. Construyes todo con huecos y, si el usuario te da los
datos de la prenda (nombre, precio, tallas), puedes crear el producto por
Admin API (`crear-producto.graphql`, ver `10`). Si usa una app POD, es mejor
que el producto lo cree la app (para que gestione el pedido): dile en el
mensaje 2 que cuando esté creado lo asignas a las plantillas y le subes sus
fotos. Anota el pendiente en `ESTADO.md`.

### Colecciones

- Si no hay colecciones o solo "Home page": crearás la colección "Todo" /
  "All" (o el nombre en el idioma de la tienda) y, si el concepto lo pide,
  una por tipo de prenda o por drop ("Drop 01", "Founders"). Se hace en la
  fase 7 con `crear-coleccion.graphql` + `anadir-productos-a-coleccion`.
- Si hay colecciones automáticas del proveedor con nombres feos, no las
  borres: crea las tuyas y úsalas en las secciones; las feas se ocultan
  simplemente no enlazándolas.

## Errores comunes

| Síntoma | Causa probable | Solución |
|---|---|---|
| "Store not found" o 404 | Dominio mal escrito | Pide la URL completa del panel y extrae el nombre tú |
| Login OK pero falla con permisos | Cuenta que no es dueña/staff | `shopify auth logout` y login con la cuenta correcta |
| `store auth` no existe | CLI antiguo (<3.93) | `npm install -g @shopify/cli@latest` (fase 0) y reintenta |
| `store execute` 401 | Token caducado (~24 h) o falta scope | Repite `shopify store auth ...` |
| El JSON de productos sale truncado/roto en pantalla | PowerShell 5.1 con salidas largas | Usa `--output-file` y lee el archivo |
| Productos con `status: DRAFT` | La app POD los crea en borrador | No es error; recuérdale al usuario activarlos (o hazlo tú con `actualizar-producto` y `status: ACTIVE`) |
| "This store requires a password" | Tienda nueva protegida | Contraseña en Tienda online → Preferencias (no es error) |

## Cierre de la fase

1. Confirma: tabla de temas (A) y consulta de productos sin error (B).
2. Mensaje: "✅ Conectado con tu tienda. He visto N prendas y M colecciones."
   (o "veo que aún no hay productos, sin problema"). NO sueltes aún la
   propuesta: es el mensaje 2, tras las fases 2-4.
3. `ESTADO.md`: dominio, fecha de login, productos/colecciones leídos con
   sus IDs, opciones de talla, correspondencia con la carpeta.
4. Pasa a `references/02-proyecto-tema.md` y luego a
   `references/03-lectura-de-referencias.md`.
