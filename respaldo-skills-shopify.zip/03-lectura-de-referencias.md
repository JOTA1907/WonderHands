# Fase 3 — Leer el material del usuario y extraer la ficha de estilo

Esta es la fase que diferencia esta skill de una plantilla. Aquí NO diseñas
todavía: **miras, clasificas y destilas**. Entras con una carpeta desordenada
y sales con (1) un inventario donde cada imagen tiene un destino claro y (2)
una **ficha de estilo** escrita que describe, con precisión de director de
arte, cómo debe verse la tienda. Todo lo que construyas después obedece a esa
ficha.

Tiempo bien invertido: 20-30 minutos mirando imágenes ahorran horas de
"no es lo que yo quería".

## 1. Inventario automático (primer barrido)

```
node <ruta-skill>/scripts/inventario-material.mjs \
  --carpeta "<ruta que dio el usuario>" [--carpeta "<otra ruta>"] \
  --json <proyecto>/material/inventario.json
```

El script lista cada imagen con dimensiones, orientación, transparencia y
una **categoría sugerida** por nombre/carpeta/forma:

| Categoría | Qué es | Destino |
|---|---|---|
| `captura-tienda` | Capturas de webs/tiendas que le gustan | **Referencia de estilo para TI.** Nunca en la tienda, nunca a la IA |
| `mockup-plano` | Prenda sola sobre fondo liso, frontal/trasera | Uso directo: galería de producto, tarjetas, bloque "vista frontal/trasera" |
| `mockup-natural` | Prenda sola en escena (mesa, percha, doblada) | Uso directo: galería, bloque de detalle/tejido, editorial |
| `detalle` | Primer plano de estampado/costura/tejido | Uso directo: bloque de tejido/calidad, hotspots, galería |
| `modelo` | Persona llevando la prenda (lifestyle/campaña) | Uso directo: héroe, lookbook, bandas editoriales, tarjetas hover. **Y ancla de estilo para la IA** |
| `diseno` | Estampado/diseño/logo, normalmente PNG transparente | **Referencia para la IA** (fidelidad del estampado). El frontal puede ser el LOGO |
| `referencia-concepto` | Fotos que explican el universo (personas, épocas, ambientes) | Referencia para TI y para el tono de los prompts. Nunca caras reales a la IA |
| `sin-clasificar` | No se pudo deducir | La miras y decides |

**La sugerencia no es la decisión.** Sigue con el paso 2.

## 2. Mirar CADA imagen (obligatorio, sin excepciones)

Abre (lee) todas las imágenes, una a una, incluidas las que el script
clasificó con seguridad. Mientras las miras, apunta en `ESTADO.md` para cada
una: categoría DEFINITIVA, qué se ve en una frase, y uso previsto. Ejemplos
de lo que se decide mirando y no por el nombre:

- "Mockup Modelo 3.png" es en realidad una foto de dos modelos en un sofá
  (uno de espaldas con la trasera, otro de frente): sirve para un bloque de
  "dos vistas" o para el héroe, no para una tarjeta cuadrada.
- "Mockup Frontal.png" es un mockup limpio con fondo gris muy claro
  (#F2F2F2 aprox.): vale para tarjeta de producto SI la tarjeta tiene ese
  fondo o uno más claro; sobre fondo negro se vería un cuadrado gris.
- "Diseño Frontal.png" es tinta negra + azul sobre transparente: como logo
  funciona sobre claro; sobre oscuro necesita versión invertida (puedes
  pedirla a la IA en la fase 6 o usar CSS `filter: invert()` solo si es
  monocromo).
- Una "captura de tienda" puede ser un mockup de Dribbble con varios
  dispositivos: la información útil es la web dentro de las pantallas, no el
  marco del móvil.
- Una foto de modelo puede llevar la prenda de espaldas: es la que enseña el
  diseño trasero grande → candidata a héroe si el diseño trasero es el
  protagonista (como suele pasar en streetwear).

Al mirar las fotos de modelo, extrae además su **estética fotográfica**
(luz, hora del día, grano, saturación, escenarios, encuadres, qué objetos
aparecen): es lo que la IA deberá imitar en la fase 6 y lo que la ficha de
estilo debe respetar (una web crema y serif con fotos nocturnas de gasolinera
puede funcionar, pero hay que decidirlo conscientemente).

## 3. Copiar y optimizar lo que se usará

Nunca trabajes sobre la carpeta del usuario. Copia al proyecto con nombres
limpios y tamaño web:

```
powershell -ExecutionPolicy Bypass -File <ruta-skill>/scripts/optimizar-imagen.ps1 `
  -Carpeta "<carpeta del usuario>" -SalidaCarpeta <proyecto>/material/todo -AnchoMax 2000
bash <ruta-skill>/scripts/optimizar-imagen.sh --carpeta "<carpeta>" <proyecto>/material/todo 2000
```

Luego reparte en `material/referencias`, `material/prenda-<handle>`,
`material/modelos`, `material/disenos`, `material/concepto` según la
categoría decidida. Los PNG con transparencia se conservan como PNG; el
resto sale en JPEG ~85. Las capturas de tiendas no necesitan optimizarse
(no van a ningún sitio), pero copiarlas a `referencias/` te permite volver a
mirarlas en sesiones futuras.

Nombres en `assets/` (cuando llegue la fase 5): describen el SLOT, no el
contenido: `hs-hero-escritorio.jpg`, `hs-hero-movil.jpg`, `hs-look-1.jpg`,
`hs-producto-frontal.jpg`, `hs-detalle-estampado.jpg`.

## 4. Leer las capturas de tiendas → ficha de estilo

Aquí está el oficio. Lee cada captura DOS veces:

**Pasada 1 — estructura.** De arriba abajo, lista los bloques que ves con
una etiqueta corta: "barra de anuncio → header con logo izquierda → héroe
tipográfico con foto a la derecha y bloque de color → marquesina → grid de
productos numerado 01/02/03 → banda editorial → footer con logo gigante".
Anota el ORDEN y el peso relativo (qué ocupa media pantalla, qué es una
tira).

**Pasada 2 — detalle.** Por cada bloque, lo que lo hace reconocible:

- **Lienzo**: color de fondo dominante (aproxima el hex: crema #F3F0E8,
  hueso #EFECE4, blanco puro, gris cálido, negro #0E0E0E...) y si cambia por
  bloques (claro/oscuro alternado).
- **Paleta**: tinta (texto), acento(s) y CÓMO se usa el acento (un bloque
  entero de color, solo botones, una palabra del titular, una etiqueta).
  Cuenta los colores: las tiendas buenas usan 2 + 1 acento.
- **Tipografía**: familia de la display (condensada grotesca en mayúsculas
  tipo Anton/Bebas; serif editorial tipo Playfair/Fraunces; sans geométrica
  tipo Inter/Manrope; monoespaciada para etiquetas), peso, mayúsculas o no,
  tamaño relativo del titular del héroe (¿ocupa un tercio de la pantalla?),
  si hay una palabra en cursiva serif como contrapunto ("IT.", "OUTSIDE.").
  Cuerpo: tamaño pequeño y aireado o normal. Etiquetas: mayúsculas pequeñas
  con espaciado, mono, con números "01 / 06", con "→".
- **Densidad y retícula**: mucho aire o compacto; líneas divisorias finas
  (sí/no, color); bordes de tarjetas (rectos, redondeados 8-16px, píldora,
  arco/ventana, blob); márgenes laterales (estrechos = editorial; anchos =
  lujo).
- **Tratamiento de fotos**: a sangre o en tarjeta; proporción dominante de
  las fotos de producto (4:5, 3:4, 1:1); tono (oscuro y contrastado, cálido
  film, neutro de estudio); si hay texto sobre foto y con qué recurso de
  legibilidad (degradado, caja de color, foto oscurecida).
- **Tarjeta de producto**: qué muestra (foto, nombre, precio, tallas,
  swatches de color, etiqueta NEW/DROP, corazón, "+" de compra rápida),
  dónde va el texto (debajo, superpuesto), qué pasa al pasar el ratón
  (segunda foto, zoom, aparecen tallas).
- **Navegación**: logo (izquierda/centro, tamaño), menú (pocas entradas en
  mayúsculas / píldoras / oculto), iconos (búsqueda, cuenta, bolsa con
  contador "BAG 00"), barra de anuncio (marquesina, texto fijo), header
  transparente sobre el héroe o con fondo.
- **Elementos característicos** (la "firma" de esa referencia): marquesina
  de texto, numerales gigantes, etiquetas de temporada "AUTUMN / WINTER 26",
  flechas, texto vertical, sellos/badges, logo gigante en el footer, bloques
  de color puro, máscaras de arco, botones píldora, iconos de línea...
- **Tono del copy**: frases cortas en mayúsculas ("DRESS LIKE YOU MEAN
  IT."), manifiesto, inglés/español, humor, lujo silencioso.
- **Footer**: columnas, newsletter, logo enorme, frase de cierre.

Escribe la lectura de cada referencia en 6-10 líneas en `ESTADO.md` con
esta cabecera: `### Referencia N — <nombre/lo que es>: aporta <qué>`.

## 5. Cómo MEZCLAR varias referencias (el criterio)

El usuario rara vez quiere UNA referencia clonada. Quiere la sensación
común a todas. Método:

1. **Busca lo común.** Lo que se repite en 3 de 5 capturas es el ADN
   innegociable (p. ej. "fotos de modelo a sangre + titular gigante +
   paleta de 2 colores + etiquetas pequeñas en mayúsculas").
2. **Asigna un papel a cada referencia.** "Estructura de portada de A;
   paleta y tipografía de B; tarjetas de producto de C; footer de D". Una
   referencia puede aportar solo un detalle (la marquesina, el arco).
3. **Resuelve los conflictos con el concepto.** Si A es oscura y B es crema,
   el concepto decide: "old money / refinado" tira a crema y serif; "trap /
   noche / lujo joven" tira a oscuro; "streetwear editorial" tira a hueso +
   negro + un acento ácido. Si sigue empatado, deja que decidan las fotos del
   usuario (una tienda debe favorecer a SUS fotos: fotos nocturnas y cálidas
   brillan sobre fondos oscuros u hueso, no sobre blanco clínico).
4. **Descarta lo que choque con la marca.** Un "70% OFF" gigante de una
   referencia no entra en una marca refinada aunque esté en la captura.
   Anótalo en "lo que NO copiamos".
5. **Comprueba contra las fotos del usuario.** La ficha debe hacer que SUS
   fotos parezcan de campaña. Si sus mockups planos tienen fondo gris claro,
   el fondo de tarjeta será ese gris o más claro; si sus fotos de modelo
   son verticales 3:4, las tarjetas y el lookbook usan 3:4 o 4:5, no 16:9.

## 6. Diccionario concepto → decisiones (cuando faltan referencias o para desempatar)

| Palabras del concepto | Lienzo | Tipografía | Fotos | Elementos |
|---|---|---|---|---|
| streetwear, drop, urbano, skate | hueso #EFECE4 o blanco + negro, 1 acento ácido (lima, lavanda, naranja) | display condensada mayúsculas + mono para etiquetas | a sangre, contrastadas, calle/noche | marquesina, numerales, "DROP 02", etiquetas de temporada, flechas |
| old money, refinado, quiet luxury, clásico | crema #F5F2EA / arena, negro tinta, sin acento fuerte (o marrón/oro apagado) | serif editorial grande + sans fina | cálidas, interiores nobles, madera, película | líneas finas, mucho aire, iconos de línea, mayúsculas con espaciado |
| trap, dinero joven, hustle, noche | negro #0E0E0E / gris carbón, blanco, acento frío (azul eléctrico) o oro | grotesca pesada + serif cursiva de contrapunto | nocturnas, coches, garajes, neón, contraluz | botones píldora blancos, máscaras de arco, fotos con degradado oscuro |
| minimal, esencial, básicos premium | blanco cálido, gris piedra | sans geométrica media, sin mayúsculas | estudio, luz suave, prenda sola | retícula limpia, swatches, tallas visibles |
| emprendedores, founders, club, XXI | cualquiera de arriba + guiño "club": sellos, "EST.", numerales romanos, blanco y negro documental | display + serif | mezcla de lifestyle con laptop/café y archivo en b/n | tarjetas de miembro, "members only", fotos b/n con marco |
| vintage, retro, archivo | papel envejecido, sepia, negro | serif de máquina, condensadas retro | grano, b/n | sellos, texturas de papel, polaroids giradas |
| deporte, técnico, funcional | blanco/negro, un acento saturado | sans ancha mayúsculas | movimiento, exterior | specs, iconos técnicos, barras |

Úsalo como vocabulario, no como plantilla: la combinación exacta sale de las
capturas del usuario.

## 6b. Sin capturas de referencia: elige y OFRECE 3 direcciones

Cuando no hay tiendas de referencia (o son una sola), no inventes en
silencio ni copies la última tienda. Construye la ficha a partir del
concepto + la estética de sus fotos + el diccionario del §6, y en el
mensaje 2 ofrece **tres direcciones con nombre llano**, una aplicada:

| Dirección (nombre para el usuario) | Lienzo y letra | Fotos | Firmas |
|---|---|---|---|
| "Editorial de revista" | hueso o blanco cálido, display condensada enorme + cursiva serif, mono en etiquetas | a sangre, contraste alto | numerales, marquesina, líneas finas |
| "Lujo silencioso" | crema/arena, serif grande y sans fina, casi sin acento | cálidas, mucho aire, en tarjeta | divisorias, iconos de línea, caps espaciadas |
| "Noche y neón" | negro carbón, grotesca pesada, acento frío | nocturnas, a sangre con degradado | píldoras, arcos, sellos |
| "Archivo / retro" | papel, sepia, negro | b/n con grano, polaroids | sellos, texturas, rotaciones |
| "Deportivo técnico" | blanco/negro + acento saturado | movimiento, exterior | specs, barras, mono |
| "Esencial premium" | blanco cálido / piedra, sans geométrica | estudio, prenda sola | retícula limpia, swatches |

Elige la que mejor case con el concepto y las fotos, escribe la ficha con
esa dirección, y en el mensaje 2: "Te dejo puesta *Editorial de revista*
porque tus fotos son nocturnas y contrastadas; si prefieres *Lujo
silencioso* o *Noche y neón*, dímelo y lo cambio antes de construir". El
usuario contesta con una palabra. Cada dirección lleva su propia pareja
tipográfica (fase 5 §8) y su propio conjunto de arquetipos (fase 4 §3b):
así dos tiendas sin referencias no salen iguales.

## 7. Plantilla de la FICHA DE ESTILO (cópiala en ESTADO.md y rellénala)

```markdown
## Ficha de estilo — <Marca>

**Frase resumen (10-20 palabras):** p. ej. "Editorial de streetwear refinado:
hueso + tinta negra + azul eléctrico, titulares condensados enormes con una
palabra en cursiva serif, fotos nocturnas a sangre."

**Referencias leídas y su papel**
- Ref 1 (<qué es>): aporta <estructura / paleta / tarjetas / footer / detalle X>
- Ref 2 ...
- Lo que NO copiamos: <elementos descartados y por qué>

**Lienzo:** fondo base #______ · bloques oscuros #______ (dónde) · alternancia (patrón)
**Paleta:** tinta #______ · acento #______ (uso: ______) · secundario #______ (uso)
**Tipografía:** display <familia o tipo> <peso>, <MAYÚSCULAS/no>, tamaño héroe ~__vw ·
  contrapunto <serif cursiva / ninguno> · cuerpo <familia> __px · etiquetas <mono/caps espaciadas> __px
  (Google Fonts elegidas: ______ / ______; equivalentes en la librería de Shopify para la ropa global: ______)
**Densidad:** aire <mucho/medio/compacto> · gutter __px · divisorias <sí #___ / no> ·
  bordes <rectos / __px / píldora / arco> · sombras <no / suaves>
**Fotos:** a sangre / tarjeta · proporción producto __:__ · proporción lookbook __:__ ·
  tono <descripción> · legibilidad de texto sobre foto: <degradado inferior / caja de color / oscurecer 30%>
**Tarjeta de producto:** <foto ratio, hover a 2ª foto sí/no, nombre/precio dónde, tallas al hover sí/no,
  etiqueta NEW/DROP sí/no, botón "+" sí/no>
**Header:** <logo posición y tamaño, menú, iconos, barra de anuncio, transparente sobre héroe sí/no>
**Footer:** <logo gigante sí/no, columnas, newsletter sí/no, frase de cierre>
**Firmas visuales (3-6):** <marquesina, numerales, etiquetas de temporada, flechas →, texto vertical...>
**Tono del copy:** <mayúsculas cortas / manifiesto / idioma / mezcla EN-ES>
**Estética fotográfica del usuario (para la IA):** <luz, hora, grano, escenarios, objetos, encuadres>
**Mapa de uso del material:** héroe ← <archivo>; lookbook ← <archivos>; galería producto ← <archivos>;
  detalle/tejido ← <archivo>; logo ← <archivo>; referencia IA ← <diseños + modelos elegidos>
```

Cada campo con valor concreto. "Minimalista" no es un valor; "hueso #EFECE4,
tinta #111, acento lima #D4FF2B solo en un bloque del héroe y en la
marquesina" sí.

## 8. Test de la ficha antes de pasar a la fase 4

- [ ] Alguien que solo lea la ficha podría dibujar la portada y acertaría el
      80% de lo que vas a construir.
- [ ] Cada referencia tiene un papel explícito o está descartada con motivo.
- [ ] Las fotos del usuario "ganan" con esa ficha (fondo, proporciones, tono).
- [ ] Hay un mapa de uso para TODAS las imágenes de uso directo (ninguna se
      queda sin destino sin motivo; ninguna se usa dos veces sin motivo).
- [ ] Sabes qué archivos serán referencia de IA (diseños + 2-4 modelos) y
      cuáles NO deben llegar a la IA (capturas, caras reales).

## Cierre de la fase

1. `ESTADO.md`: inventario definitivo (tabla), lectura de cada referencia,
   ficha de estilo completa, mapa de uso.
2. Mensaje corto de hito (sin la propuesta aún): "✅ He mirado tus N imágenes
   y tus M tiendas de referencia. Preparo la propuesta."
3. Pasa a `references/04-brief-y-propuesta.md`.
