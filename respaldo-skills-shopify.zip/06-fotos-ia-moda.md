# Fase 6 — Fotos de campaña con IA para ropa (opcional, con clave de OpenAI)

En una tienda de ropa las fotos SON la tienda. El usuario suele llegar con
buen material (mockups limpios + fotos de modelo hechas con IA o reales) y
lo que falta son **formatos** (un banner panorámico, una vertical para
móvil), **escenas nuevas** dentro de su universo (variar el lookbook), y
**piezas de apoyo** (logo en claro, bodegón, detalle macro, mockup con el
fondo de la tienda). Esta fase genera exactamente eso con la API de imágenes
de OpenAI (**gpt-image-2**), sin que el usuario toque ninguna herramienta.

**Lo que cambia respecto a una tienda de "un producto":** aquí la prenda
lleva un ESTAMPADO con letras y fotos concretas. Si la IA no recibe el
diseño real como referencia, se inventa el texto ("HUSTLERS", "FOUNDER
CLUB") o cambia las fotos del estampado. Por eso el **paquete de
referencias** de cada llamada es obligatorio.

**Los cinco pilares (no te saltes ninguno):**

1. **El paquete de referencias**: diseño real + mockup plano + fotos de
   modelo del usuario, en TODAS las llamadas donde salga la prenda.
2. **El guion fotográfico**: una foto = una llamada = un prompt escrito
   para ese hueco, con "qué la hace distinta".
3. **El universo de escenas**: las nuevas escenas salen del concepto y de
   las fotos reales del usuario (mismo mundo), no del azar.
4. **El contrato del banner**: ratio EXACTO del hueco + zona segura +
   vertical propia para móvil + verificación en 16:9 y móvil.
5. **Nada de caras reales**: personas genéricas; las fotos de personajes del
   usuario son referencia de concepto para TI, no van a la IA.

## Cuándo ofrecerlo y cómo pedir la clave

Ya lo ofreciste en el mensaje 1. Si el usuario quiere y no tiene clave:

> 1. Entra en **platform.openai.com** y crea una cuenta (vale la de Google).
> 2. Ve a **Settings → Billing** y pulsa "Add to credit balance" para
>    añadir **10 $** (es el tope; gastaremos 2-4 $).
> 3. Ve a **API keys** → "Create new secret key" → ponle un nombre → crear.
> 4. Copia la clave (empieza por `sk-`) y pégamela aquí.

Guarda la clave en `<proyecto>/clave-openai.txt` (fuera de las carpetas del
tema; nunca en `ESTADO.md`, nunca en `assets/`, nunca la imprimas).

## El modelo y la API (resumen operativo)

- Modelo `gpt-image-2`. Con referencias: `POST /v1/images/edits`
  (multipart, `image[]` hasta **16 imágenes**). Sin referencias:
  `/v1/images/generations`. Casi siempre usarás el primero.
- **`size` decide el ratio** (no el prompt): lados múltiplos de 16, lado
  mayor ≤ 3840, ratio ≤ 3:1, píxeles entre 655.360 y 8.294.400. Tamaños de
  cabecera:
  - `2048x1152` banner 16:9 (borrador `1280x720`) · `2688x1152` 21:9
    (borrador `1680x720`) · `1152x2048` héroe móvil 9:16 (borrador `720x1280`)
  - `1024x1280` tarjeta/producto 4:5 · `1024x1365` 3:4 lookbook ·
    `1024x1024` cuadrado · `1536x1024` 3:2 editorial
- `quality` low/medium/high; `n` 1-10 variaciones del MISMO prompt;
  `output_format` jpeg; `moderation` auto/low. **No hay fondo transparente**
  (pide el color exacto del fondo). **No envíes `input_fidelity`.**
- Coste orientativo por imagen 1024²: low ≈ 0,006 $, medium ≈ 0,05 $,
  high ≈ 0,21 $; un banner 2048x1152 ≈ 2,25×. Política: borradores en
  `low` con `--n 2/3`, definitivas en `medium`, `high` solo para el héroe.
  Lleva la cuenta y dísela al usuario de vez en cuando.
- Errores: 401 clave mal; 429 ritmo (espera 30-60 s) o `insufficient_quota`
  (recargar); 400 por `size` (revisa reglas) o política de contenido
  (reformula). Falsos positivos de moderación con personas: reformula →
  `--moderacion low` → escena sin persona.
- **Personajes públicos**: si el prompt pide o insinúa la cara de una persona
  real, la API lo bloquea y además no lo queremos. Nunca "un chico como
  Zuckerberg"; sí "un joven fundador de 25 años con auriculares, portátil
  y una lata, foto documental en blanco y negro". La foto del usuario de
  ese personaje NO se adjunta.

## El script: `scripts/generar-foto.mjs`

```
node <ruta-skill>/scripts/generar-foto.mjs \
  --clave <proyecto>/clave-openai.txt \
  --prompt "<prompt individual>" \
  --salida <proyecto>/fotos-generadas/hero-16x9-v1.jpg \
  --ref <proyecto>/material/disenos/diseno-trasera.png \
  --ref <proyecto>/material/prenda-hstlrs-tee/mockup-trasera.jpg \
  --ref <proyecto>/material/modelos/mockup-modelo-1.jpg \
  --ref <proyecto>/material/modelos/mockup-modelo-4.jpg \
  --calidad medium --tamano 2048x1152 [--n 3] [--mascara zona.png] [--moderacion low]
```

Imprime `OK <ruta>` o `ERROR <detalle>`. Borradores y anclas en
`fotos-generadas/`; a `assets/` solo las definitivas (optimizadas si pesan).

---

## Lo aprendido en producción (resumen; detalle en `13` §11)

- **Mínimo 655 360 píxeles por imagen**: `1024x512` falla. Tamaños
  seguros: `1536x768`, `768x1024`, `1024x1280`, `1024x1360`, `2048x1152`,
  `1152x2048`. Lados múltiplos de 16.
- **Logo en claro: NO se lo pidas a la IA** (moderación lo bloquea y no
  hace falta): `scripts/recolorear-logo.ps1` recolorea la tinta y conserva
  el acento. Si el usuario tiene su versión blanca, manda la suya.
- **Guarda los borradores** que descartes: el usuario puede preferir otro
  ("pon el 1"). Entonces regeneras ESE en alta con el contrato del banner
  (modelo entero, aire) y su vertical.
- **Si el usuario reescala** una foto (Upscayl 4096 px), optimízala a
  ≤ 2880 px JPEG 88 y ajusta `width/height`.
- **Detalle del logo del pecho** con arrugas suaves: refs = diseño frontal
  + mockup frontal + tu foto de detalle (para copiar el tipo de plano).
- Gasto real de una tienda completa (banner high + móvil + 2 escenas + 1
  detalle + borradores): ≈ 3 $.

## PILAR 1 — El paquete de referencias (obligatorio en cada llamada con prenda)

Orden de las `--ref` (el orden importa poco para el modelo, pero te obliga a
no olvidar ninguna):

1. **El diseño** que se ve en la foto (`diseno-trasera.png` si el modelo está
   de espaldas; `diseno-frontal.png` si de frente; los dos si se ven los dos
   en una foto de dos personas). Es el archivo transparente del usuario. Si
   pesa >4-5 MB, usa la versión optimizada (PNG, 1200-1600px).
2. **1 mockup plano** de la misma vista (frontal/trasera): enseña el color
   exacto de la prenda, el corte (oversized, cuello), la posición y el
   tamaño del estampado en la prenda.
3. **2-4 fotos de modelo del usuario** elegidas por parecido con la escena
   que pides (misma hora del día, misma clase de lugar): fijan el "grading",
   el grano, la luz y la actitud. Rota cuáles usas según la escena; no las
   16 siempre.
4. **La foto anterior de una serie** (si es una serie encadenada) o **un
   banner ya aprobado** (si generas su versión móvil).
5. Opcional: 1-2 fotos generadas ya aprobadas que claven el ambiente.

Y en el prompt, SIEMPRE este párrafo de fidelidad (adáptalo al idioma que
uses en el prompt):

> "La prenda es exactamente la de las imágenes de referencia: camiseta
> [color] oversized de algodón grueso. El estampado de la [espalda/pecho]
> debe reproducirse EXACTAMENTE igual que en el archivo de diseño de
> referencia: mismas letras y palabras («HSTLRS», «FOUNDERS CLUB», «XXI
> CENTURY»), misma tipografía, mismos colores (negro texturizado y azul
> eléctrico), mismas fotografías en blanco y negro en las mismas posiciones.
> No añadas, cambies ni inventes texto ni imágenes en la prenda."

Escribe los textos del estampado entre comillas y tal cual (mayúsculas
incluidas): gpt-image-2 respeta muy bien el texto cuando se le da explícito
y tiene la referencia.

**Lo que NUNCA va como referencia:** capturas de tiendas (pintaría
interfaces), fotos de personajes reales (caras), imágenes con marcas de
agua o textos de proveedor.

## PILAR 2 — El guion fotográfico

Se escribe DESPUÉS de la composición (fase 4) y ANTES de la primera llamada,
en `ESTADO.md`:

| Campo | Contenido |
|---|---|
| Archivo | `hs-hero-escritorio.jpg`, `hs-look-ia-2.jpg`... |
| Bloque de destino | arquetipo y sección (p. ej. "héroe nº2", "lookbook nº27 celda 4") |
| Formato | `size` exacto del hueco |
| Vista de la prenda | frontal / trasera / ambas / prenda sola |
| Referencias | lista exacta de archivos `--ref` |
| Escena | lugar, hora, luz, cámara, acción, qué hace el modelo, objetos |
| **Qué la hace distinta** | la frase que la diferencia de TODAS las demás del guion y de las fotos reales del usuario |
| Prompt | el prompt completo (con el párrafo de fidelidad) |

Reglas: si no sabes escribir "qué la hace distinta", la foto sobra. Un
bloque con 4 fotos = 4 llamadas con 4 escenas. `--n` es para variaciones de
UNA escena, no para escenas distintas. Variedad de planos (general, medio,
detalle, cenital de bodegón) y de contextos, pero misma sesión (el
vocabulario de luz/grano/paleta de la ficha va pegado en todos los prompts).

## PILAR 3 — El universo de escenas

Antes de escribir prompts, define en `ESTADO.md` el **universo** en 5-8
escenas posibles, derivadas de (a) el concepto del usuario, (b) las escenas
que YA aparecen en sus fotos (para no repetirlas y para mantener el mundo),
(c) el diccionario concepto→estética de la fase 3.6. Ejemplo de método (no
de resultado): si sus fotos son "gasolinera de noche con Porsche, garaje con
G-Wagon, café de París con portátil, hotel con teléfono y billetes, loft
con sofá de cuero", el universo es "dinero joven en marcha, noche y primera
hora, ciudad europea, objetos de trabajo y de lujo discreto" y las escenas
NUEVAS podrían ser: azotea al amanecer con portátil, asiento trasero de un
coche negro con el móvil, sala de juntas vacía a las 6:00, pista de tenis
de club privado, cocina de mármol con café y periódico financiero, taxi
nocturno con luces de neón. Cada una con su plano y su acción.

Lo que NO entra en el universo: todo lo que contradiga la ficha (playa
tropical en una marca nocturna urbana) y cualquier escenario que pida
logotipos de terceros reconocibles en primer plano (los evitamos: "un coche
deportivo negro", no "un Porsche 911" — si sale una marca, que sea
incidental y pequeña).

## PILAR 4 — El contrato del banner

Idéntico al de siempre, con las particularidades de moda:

1. **`size` = ratio del hueco**: `2048x1152` (16:9) o `2688x1152` (21:9).
   Borradores `1280x720`/`1680x720`.
2. **Zona segura**: modelo COMPLETO (o de cintura para arriba con la cabeza
   entera y aire encima) en la banda central del ~70% vertical; nada
   importante en los bordes. Modelo en un tercio, espacio negativo limpio en
   el resto para el titular enorme de la ficha. Frase que funciona:
   > "Composición panorámica de banner web. El modelo aparece entero, de
   > [espaldas/frente], ocupando como máximo dos tercios de la altura,
   > centrado verticalmente, con aire por encima de la cabeza y por debajo.
   > Modelo en el tercio [derecho], el resto es fondo continuo y limpio para
   > superponer texto."
3. **Recorte local** (`recortar-banner.*`) para fotos del usuario usadas de
   banner y para reencuadres: `-CentroY 0.25-0.35` en fotos de modelo (la
   cabeza está arriba).
4. **Móvil tiene SU imagen**: `1152x2048`, misma escena y luz, pasando el
   banner aprobado como referencia; modelo entero en la banda central; aire
   para el texto arriba o abajo. La sección del héroe lleva dos selectores
   (fase 5, 6b).
5. **Verificación en 16:9 y móvil** (fase 8) antes de dar el héroe por bueno.

## PILAR 5 — Series encadenadas y coherencia

- **Series** (mañana/tarde/noche, tres looks, pasos de "cómo se lleva"): la
  foto N usa la N-1 como referencia adicional + "exactamente el mismo
  modelo, misma cámara, misma luz; ahora [cambio]".
- **Mismo modelo en varias fotos**: pasa la primera foto aprobada de ese
  modelo generado como referencia en las siguientes ("la misma persona que
  en la referencia").
- **Coherencia con las fotos reales del usuario**: sus fotos de modelo son
  las anclas de estilo. Si tras 2 intentos una escena no "casa" con las
  reales (otro grading, otra época), cambia de escena antes que insistir.

## Piezas de apoyo típicas en moda (cuándo y cómo)

| Pieza | Cuándo | Cómo |
|---|---|---|
| **Logo en claro** (para header/footer oscuros) | La ficha tiene bloques oscuros y el diseño es tinta negra | `--ref diseno-frontal.png`, `1024x512` o al ratio del logo, prompt: "el mismo logotipo exactamente, mismas letras y proporciones, ahora en blanco (y el azul se mantiene) sobre fondo negro puro #0E0E0E uniforme". Revisa letra a letra. Alternativa sin IA si es monocromo: `filter: invert(1)` |
| **Mockup con el fondo de la tienda** | Los mockups del usuario tienen fondo gris y la tarjeta es hueso/negro | `--ref mockup-frontal + diseno-frontal`, `1024x1280`, "misma prenda exactamente, fotografía de producto sobre fondo uniforme #EFECE4 sin sombra dura, luz de estudio suave" |
| **Detalle macro del estampado** | No hay foto de detalle o se quiere otra zona | `--ref diseno + mockup`, `1024x1024`, "primer plano macro de la textura del algodón y del estampado, se ve el grano de la tinta, ligera profundidad de campo" |
| **Bodegón "qué recibes"** | Bloque de unboxing/packaging | `--ref mockup natural + modelo`, `1536x1024`, "cenital: la camiseta doblada, etiqueta, bolsa/papel de seda, tarjeta de agradecimiento con «GRACIAS» (o el texto que quieras), sobre [superficie de la ficha]" |
| **Banner de colección/drop** | Cabecera de la plantilla de colección | contrato del banner, prenda(s) + claim libre de texto (el texto lo pone la sección) |
| **Escenas nuevas de lookbook** | Ampliar variedad | Universo de escenas + paquete de referencias, `1024x1365` |
| **Dos vistas en una** (frontal + trasera) | Bloque "delante y detrás" | Dos personas o el mismo modelo con espejo; ambos diseños como referencia |

## Retoques con máscara

El endpoint de edición acepta una máscara PNG con alfa (mismas dimensiones
que la PRIMERA `--ref`): las zonas transparentes se repintan. Úsala cuando la
foto está bien salvo el estampado (letras ligeramente mal): máscara sobre
la zona del estampado + prompt describiendo el diseño exacto + el archivo
del diseño como referencia. Si no converge en 2 intentos, regenera entera.

## Cómo escribir los prompts (calidad)

1. **Describe la prenda a partir de lo que VES** en los mockups: color exacto,
   corte, cuello, cómo cae, tamaño del estampado respecto a la espalda.
2. **Párrafo de fidelidad** (arriba), siempre.
3. **Escena concreta**: lugar, hora, luz, cámara (35 mm, f/2, ligero grano de
   película), acción, actitud, objetos. Copia el vocabulario de la ficha:
   "luz de tungsteno cálida y sombras profundas, ligero grano, colores
   apagados con los negros densos".
4. **Fondo con intención**: si la foto irá sobre un fondo de la tienda,
   pide ese color exacto; si es banner, "fondo continuo extensible".
5. **Sin texto** en la imagen salvo el del estampado (los titulares los pone
   la web). "Sin marcas de agua, sin logotipos de otras marcas visibles".
6. **Personas**: genéricas, edad y estilo según el público; diversidad
   coherente con las fotos reales del usuario.
7. Escribe en el idioma que prefieras; precisión > idioma.

## Subir las fotos definitivas donde toque

- Fotos de escena para héroe/lookbook/editorial → `assets/` (nombre de slot).
- Fotos de PRODUCTO (mockup con fondo de la tienda, detalle macro, dos
  vistas) → galería del producto por Admin API (`10`, apartado 5) para que
  aparezcan en tarjetas y página de producto.
- Logo en claro → `assets/hs-logo-claro.png`.

## Flujo completo recomendado

1. Clave → `clave-openai.txt`.
2. Universo de escenas + guion fotográfico completo en `ESTADO.md`.
3. Primero las piezas que desbloquean bloques: banner 16:9 del héroe (low
   `--n 3` → elegir → medium/high), su vertical móvil, logo en claro.
4. Después las escenas nuevas (low `--n 2` → elegir → medium), encadenando
   las que compartan modelo.
5. Revisa CADA foto con lupa contra el diseño real (letras, fotos del
   estampado, colores). Una letra cambiada = foto descartada.
6. Integra (assets o producto), sube, verifica en 16:9 + móvil.
7. `ESTADO.md`: fotos generadas, prompts resumidos, referencias usadas,
   gasto acumulado.
