# Fase 5 — Construir secciones personalizadas 100% editables (con los patrones de moda)

Corazón técnico de la skill. Cada sección cumple un contrato: **el usuario
puede cambiar después cualquier texto, imagen, tamaño, alineación, color,
espaciado y QUÉ COLECCIÓN/PRODUCTOS muestra, desde el editor visual de
Shopify, sin tocar código.** Y todo se construye obedeciendo la ficha de
estilo de la fase 3.

## Índice

1. Arquitectura de archivos
2. Anatomía de una sección (plantilla canónica)
3. El contrato de editabilidad (checklist por sección)
4. Patrón de estilos por sección (`{% style %}` + schema)
5. LA REGLA DE ORO DEL ESPACIADO Y DEL FONDO
6. Imágenes: image_picker con respaldo en assets · 6b. Héroes: escritorio + móvil
7. Montar la portada: `templates/index.json` + CHECKLIST DE COSTURAS
8. CSS global: tokens de diseño desde la ficha de estilo · 8b. Ropa global · 8c. El listón visual
9. JavaScript: patrones seguros
10. TRAMPAS CONOCIDAS
11. **PATRONES ESPECÍFICOS DE MODA** (colección destacada, tarjeta de producto,
    tallas, guía de tallas, lookbook, marquesina, logo gigante)

---

## 1. Arquitectura de archivos

- Prefijo corto derivado de la marca (2-4 letras). Los ejemplos usan `mt-`;
  en un proyecto real será `hs-`, `lnr-`, etc. Aplica a archivos, clases e IDs.
- `sections/mt-hero.liquid`, `sections/mt-coleccion.liquid`,
  `sections/mt-lookbook.liquid`... — una sección por bloque.
- `snippets/mt-tarjeta-producto.liquid` — la tarjeta de producto se
  comparte entre colección destacada, plantilla de colección y relacionados.
- `assets/mt-styles.css` — TODO el CSS propio. `assets/mt-scripts.js` — TODO el JS.
- No edites los originales de Dawn (excepto `sections/header.liquid` y
  `sections/footer.liquid`, fase 7). `layout/theme.liquid` solo para cargar
  fuentes de Google y el favicon.

## 2. Anatomía de una sección (plantilla canónica)

El padding **y el fondo** viven los dos en el envoltorio `#shopify-section-...`.

```liquid
{{ 'mt-styles.css' | asset_url | stylesheet_tag }}

{% style %}
  #shopify-section-{{ section.id }} {
    padding-top: {{ section.settings.padding_top }}px;
    padding-bottom: {{ section.settings.padding_bottom }}px;
    background-color: {{ section.settings.color_fondo }};
    color: {{ section.settings.color_texto }};
  }
  #shopify-section-{{ section.id }} .mt-h2 {
    font-size: {{ section.settings.heading_size }}px;
    text-align: {{ section.settings.text_align }};
  }
  #shopify-section-{{ section.id }} .mt-body {
    font-size: {{ section.settings.body_size }}px;
    text-align: {{ section.settings.text_align }};
  }
{% endstyle %}

<section class="mt-bloque mt-section">
  <div class="mt-container">
    <p class="mt-etiqueta">{{ section.settings.etiqueta }}</p>
    <h2 class="mt-h2">{{ section.settings.headline }}</h2>
    <p class="mt-body">{{ section.settings.body | newline_to_br }}</p>
  </div>
</section>

{% schema %}
{
  "name": "MT – Bloque",
  "tag": "section",
  "settings": [
    { "type": "text", "id": "etiqueta", "label": "Etiqueta pequeña (opcional)", "default": "DROP 01" },
    { "type": "text", "id": "headline", "label": "Título", "default": "..." },
    { "type": "textarea", "id": "body", "label": "Texto", "default": "..." },
    { "type": "header", "content": "Tipografía" },
    { "type": "select", "id": "text_align", "label": "Alineación",
      "options": [
        {"value": "left", "label": "Izquierda"},
        {"value": "center", "label": "Centro"},
        {"value": "right", "label": "Derecha"}
      ], "default": "left" },
    { "type": "range", "id": "heading_size", "label": "Tamaño del título (px)",
      "min": 24, "max": 160, "step": 4, "unit": "px", "default": 72 },
    { "type": "range", "id": "body_size", "label": "Tamaño del texto (px)",
      "min": 13, "max": 26, "step": 1, "unit": "px", "default": 17 },
    { "type": "header", "content": "Color y espaciado" },
    { "type": "color", "id": "color_fondo", "label": "Color de fondo del bloque", "default": "#EFECE4" },
    { "type": "color", "id": "color_texto", "label": "Color del texto", "default": "#111111" },
    { "type": "range", "id": "padding_top", "label": "Espacio superior (px)",
      "min": 0, "max": 160, "step": 8, "unit": "px", "default": 80 },
    { "type": "range", "id": "padding_bottom", "label": "Espacio inferior (px)",
      "min": 0, "max": 160, "step": 8, "unit": "px", "default": 80 }
  ],
  "presets": [ { "name": "MT – Bloque" } ]
}
{% endschema %}
```

No negociable:
- `presets` con `name` (sin esto la sección no aparece en el editor).
- Etiquetas en el idioma del usuario, claras para no técnicos.
- `newline_to_br` en TODOS los textarea.
- Agrupa ajustes con `{ "type": "header" }`.
- Los `default` de colores se fijan AL CONSTRUIR con los valores de la ficha
  de estilo (no dejes `#FFFFFF` si la ficha dice hueso).
- El tamaño máximo del titular llega a 160px (o `clamp` con vw): las
  referencias de moda usan titulares enormes.

## 3. El contrato de editabilidad (checklist por sección)

- [ ] Todos los textos visibles (text/textarea/richtext)
- [ ] Todas las imágenes (image_picker) y vídeos
- [ ] **Colección o productos que muestra** (`collection` / `product` /
      `product_list` en el schema) — nunca productos "a fuego"
- [ ] Tamaño de letra de título y cuerpo (range)
- [ ] Alineación del texto (select)
- [ ] Color de fondo (envoltorio) y color de texto
- [ ] Espacio superior e inferior (range 0-160, default ≠ 0 salvo costura)
- [ ] Enlaces de botones (url) y su texto
- [ ] Parámetros visuales decisivos (velocidad de marquesina, columnas del
      grid en escritorio y móvil, proporción de las fotos de tarjeta,
      mostrar precio/tallas/etiqueta...) — si dudas, exponlo
- [ ] Otros colores SOLO si la sección lo pide, con los de la ficha por defecto

## 4. Patrón de estilos por sección

Lo que depende de un ajuste vive en `{% style %}` con selector
`#shopify-section-{{ section.id }} ...`. Lo estructural (layout, animaciones,
hover) en `mt-styles.css` con clases `mt-*`.

## 5. LA REGLA DE ORO DEL ESPACIADO Y DEL FONDO

### 5.1 Padding y fondo, JUNTOS en el envoltorio

**Todo el relleno vertical vive EXCLUSIVAMENTE en `#shopify-section-...`
(padding_top / padding_bottom), Y el fondo del bloque se pinta en ESE MISMO
envoltorio.** El interno (`<section class="mt-...">`) tiene padding vertical
CERO y fondo transparente.

- Padding en el interno → el usuario pone "Espacio superior: 0" y sigue
  viendo hueco.
- Fondo en el interno → el padding del envoltorio se pinta del color de la
  PÁGINA: bloques asfixiados, franjas entre bloques, y "añado espacio y crece
  de otro color".

Refuerzo en `mt-styles.css`:

```css
.mt-section { padding-top: 0 !important; padding-bottom: 0 !important; background: transparent; }
```

### 5.2 Defaults de espaciado (ritmo vertical)

| Tipo de bloque | default arriba/abajo |
|---|---|
| Bloque normal | 80 / 80 |
| Bloque denso (grid de productos, FAQ, guía de tallas) | 64 / 64 |
| Bloque protagonista (manifiesto, historia del diseño, CTA final) | 96-120 |
| Héroe full-bleed con imagen | 0 / 0 |
| Costura deliberada (marquesina pegada al héroe) | 0 en el lado pegado |
| Grid editorial con líneas divisorias (estilo revista) | 0 / 0 con las líneas como borde del envoltorio |

"Costura deliberada" = TÚ decides que dos bloques van pegados y comparten
color en esa línea (o el de abajo continúa la imagen del de arriba).

### 5.3 Bloques con imagen de fondo full-bleed

- Imagen cubriendo el 100%: interno `position: relative`, imagen `position:
  absolute; inset: 0; width: 100%; height: 100%; object-fit: cover`.
- El envoltorio lleva ADEMÁS `background-color` del color dominante de la
  foto (default elegido mirando la foto).
- Posición focal expuesta (select arriba/centro/abajo → `object-position`).
  En fotos de modelo, casi siempre "arriba" (la cabeza no se corta).
- Legibilidad del texto según la ficha: degradado inferior
  (`linear-gradient(to top, rgba(0,0,0,.55), transparent 60%)`), caja de
  color de acento, o velo del 20-35% — ajuste `oscurecer_foto` (range 0-70).

## 6. Imágenes: image_picker con respaldo en assets

```liquid
{%- if section.settings.imagen != blank -%}
  <img src="{{ section.settings.imagen | image_url: width: 2000 }}"
       alt="{{ section.settings.imagen.alt | escape }}" loading="lazy">
{%- else -%}
  <img src="{{ 'mt-look-1.jpg' | asset_url }}" alt="" loading="lazy">
{%- endif -%}
```

`image_picker` NO admite `default`. Primera imagen de la página:
`loading="eager"` + `fetchpriority="high"`; el resto `lazy`.

### 6b. Héroes full-bleed: imagen de escritorio + imagen de móvil

Dos selectores (`imagen` escritorio, `imagen_movil` vertical) con `<picture>`:

```liquid
<picture class="mt-hero-media">
  {%- assign movil = section.settings.imagen_movil -%}
  {%- if movil != blank -%}
    <source media="(max-width: 749px)" srcset="{{ movil | image_url: width: 1100 }}">
  {%- elsif section.settings.imagen == blank -%}
    <source media="(max-width: 749px)" srcset="{{ 'mt-hero-movil.jpg' | asset_url }}">
  {%- endif -%}
  {%- if section.settings.imagen != blank -%}
    <img src="{{ section.settings.imagen | image_url: width: 2400 }}"
         alt="{{ section.settings.imagen.alt | escape }}" loading="eager" fetchpriority="high">
  {%- else -%}
    <img src="{{ 'mt-hero-escritorio.jpg' | asset_url }}" alt="" loading="eager" fetchpriority="high">
  {%- endif -%}
</picture>
```

En moda es MUY frecuente que la foto de modelo del usuario sea vertical
(3:4): sirve tal cual para móvil y para héroes partidos (foto a un lado,
texto al otro); para un héroe panorámico a sangre hace falta el banner del
contrato (fase 6) o un recorte consciente con `recortar-banner.*` y
`-CentroY` bajo (0.2-0.35) para no cortar la cabeza. El texto en móvil se
coloca donde la foto tenga aire (arriba si el modelo está abajo, etc.).

## 7. Montar la portada: `templates/index.json` + CHECKLIST DE COSTURAS

```json
{
  "sections": {
    "mt-hero": { "type": "mt-hero", "settings": { "headline": "..." } },
    "mt-marquesina": { "type": "mt-marquesina", "settings": { } },
    "mt-coleccion": { "type": "mt-coleccion", "settings": { "collection": "todo" } }
  },
  "order": ["mt-hero", "mt-marquesina", "mt-coleccion"]
}
```

- `type` = nombre del archivo sin `.liquid`. Los `settings` del JSON
  sobreescriben los defaults del schema. Todo id en `order` existe en
  `sections`. Los ajustes `collection` llevan el HANDLE de la colección.
- JSON válido (sin comas finales, sin comentarios).

### Checklist de costuras (SIEMPRE tras montar/retocar)

Por cada par de bloques consecutivos (header→1º y último→footer incluidos):

1. ¿De qué color termina el de arriba y empieza el de abajo?
2. La costura solo puede ser: **continua** (mismo color, pegados),
   **contraste con aire** (colores distintos → ambos con padding ≥ 48px en
   ese lado, cada uno de SU color), o **transición diseñada** (marquesina,
   línea divisoria fina del color de la ficha, degradado, solape).
3. **Prohibido** el hueco del color de la página entre dos bloques que no lo
   usan. Si lo ves: fondo en el interno (5.1) o margin perdido.
4. Héroe con imagen → siguiente: la imagen termina EXACTAMENTE donde
   empieza el siguiente. Solapes (tarjeta que "muerde" el héroe) con
   margin-top negativo documentado.

Anota en `ESTADO.md` la lista de costuras y su tipo.

## 8. CSS global: tokens de diseño desde la ficha de estilo

`mt-styles.css` arranca con las variables de la FICHA (no inventes):

```css
:root {
  --mt-fondo: #EFECE4;          /* lienzo (ficha) */
  --mt-fondo-oscuro: #0E0E0E;   /* bloques oscuros (ficha) */
  --mt-tinta: #111111;
  --mt-acento: #2E6BFF;         /* uso: ficha → "solo etiquetas y botón principal" */
  --mt-display: 'Anton', Impact, 'Arial Narrow', sans-serif;   /* display (ficha) */
  --mt-contrapunto: 'Instrument Serif', Georgia, serif;         /* cursiva serif de contrapunto, si la ficha la tiene */
  --mt-cuerpo: 'Inter', -apple-system, sans-serif;
  --mt-mono: 'JetBrains Mono', ui-monospace, monospace;         /* etiquetas 01/06, DROP, temporada */
  --mt-radio: 0px;              /* bordes: 0 (editorial), 12px (suave), 999px (píldora) */
  --mt-linea: 1px solid rgba(17,17,17,.15); /* divisorias finas si la ficha las tiene */
  --mt-gutter: 24px;
  --mt-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --mt-ratio-producto: 4 / 5;   /* proporción de las fotos de producto (ficha) */
  --mt-ratio-look: 3 / 4;       /* proporción del lookbook (ficha) */
}
.mt-section { font-family: var(--mt-cuerpo); color: var(--mt-tinta); }
.mt-container { max-width: 1400px; margin: 0 auto; padding: 0 var(--mt-gutter); }
.mt-container--full { max-width: none; padding: 0; }   /* editorial a sangre */
.mt-display { font-family: var(--mt-display); text-transform: uppercase; line-height: .92; letter-spacing: -.01em; }
.mt-contrapunto { font-family: var(--mt-contrapunto); font-style: italic; text-transform: none; font-weight: 400; }
.mt-etiqueta { font-family: var(--mt-mono); font-size: 12px; letter-spacing: .12em; text-transform: uppercase; opacity: .8; }
```

Fuentes: carga las de Google Fonts elegidas en la ficha desde
`layout/theme.liquid` con `preconnect` (uno de los pocos motivos válidos
para tocar ese archivo). Familias que suelen encajar por estilo:

| Estilo de la ficha | Display | Contrapunto | Cuerpo/etiquetas |
|---|---|---|---|
| Streetwear editorial | Anton, Bebas Neue, Archivo Black, Oswald 700 | Instrument Serif italic, Playfair Display italic | Inter, Archivo; mono: JetBrains Mono, Space Mono |
| Old money / refinado | Playfair Display, Fraunces, Cormorant Garamond | (la propia serif en cursiva) | Inter, Manrope, DM Sans; etiquetas: la sans en caps espaciadas |
| Trap / noche / lujo joven | Archivo Black, Syne 800, Unbounded | Instrument Serif italic | Manrope, Inter |
| Minimal premium | Manrope 600, DM Sans, Space Grotesk | ninguno | igual que display |
| Retro / archivo | Rubik Mono One, Bowlby One, Abril Fatface | Libre Baskerville italic | Courier Prime (mono) |

Responsive: escritorio primero, breakpoints 990px y 749px (Dawn usa 749/990).
Titulares con `clamp(40px, 9vw, 160px)`; grids de 4 → 2 columnas en móvil.

### 8b. La "ropa" global del tema

Edita `config/settings_data.json` (`current`): `color_schemes` con los
colores de la ficha (scheme-1 lienzo, scheme-2 oscuro...), `type_header_font`
y `type_body_font` con la fuente de la librería de Shopify más parecida
(formato `nombre_n4`/`nombre_n7`; si dudas, busca en la documentación de
Shopify Fonts, no inventes), radios de botones/inputs/tarjetas según la
ficha (0 editorial, píldora si la ficha lo pide), y el ancho de página. Así
carrito, búsqueda, cuenta y páginas de política no parecen "de otra web".
Si el usuario retocó ajustes desde el editor, `pull` de `config/` antes.

### 8c. El listón visual

Todo lo que se admira en una web moderna se consigue con CSS moderno + JS
vanilla. Reglas para todos los arquetipos: anima solo `transform` y
`opacity`; un IntersectionObserver compartido; `prefers-reduced-motion`
desactiva animaciones; degradación elegante en móvil; cada efecto expone sus
diales en el schema; reveals al hacer scroll como MÍNIMO en cada bloque.

## 9. JavaScript: patrones seguros

- Un solo `mt-scripts.js` con `defer` desde las secciones que lo necesiten.
- **Guard de ejecución única** en la primera línea del IIFE
  (`if (window.__mtInit) return; window.__mtInit = true;`): N secciones =
  N etiquetas script ejecutadas.
- Una función `init` por componente, idempotente por elemento
  (`if (el.dataset.mtInit) return; el.dataset.mtInit = "1";`), todas desde
  `DOMContentLoaded` Y desde `document.addEventListener('shopify:section:load', ...)`
  (el editor re-renderiza sin recargar).
- Reveals: IntersectionObserver añade `.mt-visible` a `.mt-reveal`. Sin JS,
  todo visible.
- Nada de librerías externas: carruseles con `scroll-snap` nativo o
  animación CSS de `transform` con contenido duplicado.

## 10. TRAMPAS CONOCIDAS (léelas antes de la primera sección)

1. **`"type": "url"` NO admite `"default"`** → la subida falla. Usa
   `| default: '#'` al renderizar o valores en `templates/*.json`.
2. **`box-shadow`/zoom cortados en carruseles**: usa `overflow-x: clip;
   overflow-y: visible;` y revisa todos los ancestros.
3. **`clip-path`/`transform`/`filter`/`opacity` crean contextos de
   apilamiento**: un z-index "que no funciona" casi siempre es esto.
4. **Franja blanca bajo el header** de Dawn: `.section-header { margin-bottom: 0 !important; }`.
5. Padding en el interno → 5.1. 6. Franja entre bloques → 5.1/5.3 + costuras.
7. "Añado espacio y crece de otro color" → 5.1.
8. **`range`**: (max−min)/step ≤ 101 y el default cae en un paso exacto.
8b. **Sin filtros dentro de `{% for %}`**: `assign` en una línea previa.
8c. **Dawn pinta `h1`-`h6`, `blockquote`, `a` con su color**: `color: inherit`
   en tus clases; en bloques oscuros revisa enlaces y precios.
8d. **Mismo `<script src>` N veces = N ejecuciones** → guard (sección 9).
8e. **NBSP invisibles** en literales: `grep -nP '\xC2\xA0'`.
8f. **El editor re-renderiza sin recargar** → `shopify:section:load` + inits idempotentes.
9. **`newline_to_br` olvidado.** 10. **JSON del schema inválido.**
11. **Decorativos absolutos que se salen** → `overflow-x: clip` en la sección
   (scroll horizontal en móvil).
12. **Sombras que asoman por el borde** en contenedores con `perspective`/altura fija → colchón.
13. **`collection` vacío en el schema** (el usuario aún no eligió colección):
   renderiza con fallback `collections['all']` y un aviso solo visible en el
   editor (`{% if request.design_mode %}`), nunca una sección vacía.
14. **Fotos de producto con fondos distintos en la misma tarjeta** (mockup
   gris del proveedor junto a mockup blanco del usuario): homogeneiza subiendo
   las fotos del usuario a TODOS los productos (fase 7) y da a la tarjeta un
   fondo del color del mockup (ajuste `color_fondo_tarjeta`).
15. **Dawn ya carga sus estilos de `product-form`/`cart`**: reutiliza sus
   componentes (`{% render 'product-form' %}` NO existe como snippet
   estable; usa `{% form 'product' %}` propio, fase 7) y no dupliques la
   lógica del cajón del carrito: Dawn lo actualiza solo si el formulario
   hace la petición estándar a `/cart/add.js` (o dejas el submit normal).

---

### 10b. Trampas nuevas (detalle en `13-lecciones-y-recetas.md` §9)

16. **Especificidad de tus resets** (`.mt-section h1 { margin:0 }`) pisa
    tus clases: overrides como `.mt-section h1.mt-clase`.
17. **`margin: 0 auto` en hijo de flex-column** lo encoge y centra.
18. **`calc(var(--x) * n)` con clamp dentro** no resuelve: usa em.
19. **`[hidden]` no oculta si tu clase pone `display:flex`**: añade
    `[hidden] { display:none !important }`.
20. **`background-attachment: fixed`** del body de Dawn: quítalo.
21. **Límites del schema**: name ≤ 25, label ≤ 70, header ≤ 50, default de
    range en un paso exacto, default de select existente.
22. **Reveal por palabras recorta glifos** (S arriba, y/g abajo): colchón
    con padding/margin compensados (13 §3).
23. **Hover que altera un fundido** entre bloques: prohibido.
24. **Botones píldora en bloques oscuros** heredan el color del texto:
    color explícito.

## 11. PATRONES ESPECÍFICOS DE MODA

Estos patrones son los que hacen que una tienda de ropa "funcione" y no sea
una landing con fotos. Todos cumplen las secciones 2-9.

### 11.1 Colección destacada alimentada por productos REALES

Schema:

```json
{ "type": "collection", "id": "collection", "label": "Colección que se muestra" },
{ "type": "range", "id": "max_productos", "label": "Cuántas prendas mostrar", "min": 2, "max": 12, "step": 1, "default": 6 },
{ "type": "range", "id": "columnas", "label": "Columnas en ordenador", "min": 2, "max": 5, "step": 1, "default": 3 },
{ "type": "select", "id": "columnas_movil", "label": "Columnas en móvil", "options": [{"value":"1","label":"1"},{"value":"2","label":"2"}], "default": "2" },
{ "type": "checkbox", "id": "numerar", "label": "Numerar las prendas (01, 02...)", "default": true },
{ "type": "checkbox", "id": "mostrar_tallas", "label": "Mostrar tallas al pasar el ratón", "default": true },
{ "type": "checkbox", "id": "hover_segunda_foto", "label": "Cambiar a la segunda foto al pasar el ratón", "default": true },
{ "type": "text", "id": "texto_boton", "label": "Texto del botón 'ver todo'", "default": "VER TODA LA COLECCIÓN" }
```

Render:

```liquid
{%- assign col = section.settings.collection -%}
{%- if col == blank -%}{%- assign col = collections['all'] -%}{%- endif -%}
{%- if request.design_mode and section.settings.collection == blank -%}
  <p class="mt-aviso-editor">Elige una colección en el panel de la derecha (ahora se muestra "Todo").</p>
{%- endif -%}
<div class="mt-grid" style="--cols: {{ section.settings.columnas }}; --cols-m: {{ section.settings.columnas_movil }};">
  {%- for product in col.products limit: section.settings.max_productos -%}
    {%- render 'mt-tarjeta-producto', product: product, indice: forloop.index, numerar: section.settings.numerar,
        mostrar_tallas: section.settings.mostrar_tallas, hover: section.settings.hover_segunda_foto -%}
  {%- else -%}
    {%- if request.design_mode -%}<p class="mt-aviso-editor">Esta colección aún no tiene prendas.</p>{%- endif -%}
  {%- endfor -%}
</div>
{%- if section.settings.texto_boton != blank -%}
  <a class="mt-btn" href="{{ col.url | default: '/collections/all' }}">{{ section.settings.texto_boton }} →</a>
{%- endif -%}
```

Nunca `product_list` con productos fijos para "la colección": cuando el
usuario añada una prenda no aparecería. `product_list` solo para bloques de
"elegidos a mano" (best sellers, completa el look).

### 11.2 Snippet de tarjeta de producto (`snippets/mt-tarjeta-producto.liquid`)

Diseñada según la ficha (proporción, dónde va el texto, hover). Base:

```liquid
{%- assign img1 = product.featured_image -%}
{%- assign img2 = product.images[1] -%}
<article class="mt-card mt-reveal">
  <a class="mt-card__media" href="{{ product.url }}" aria-label="{{ product.title | escape }}">
    {%- if img1 -%}
      <img class="mt-card__img" src="{{ img1 | image_url: width: 900 }}" alt="{{ img1.alt | escape }}" loading="lazy"
           width="{{ img1.width }}" height="{{ img1.height }}">
    {%- endif -%}
    {%- if hover and img2 -%}
      <img class="mt-card__img mt-card__img--hover" src="{{ img2 | image_url: width: 900 }}" alt="" loading="lazy">
    {%- endif -%}
    {%- if numerar -%}<span class="mt-card__num">{{ indice | prepend: '0' | slice: -2, 2 }}</span>{%- endif -%}
    {%- for tag in product.tags -%}
      {%- if tag == 'new' or tag == 'nuevo' or tag == 'drop' -%}<span class="mt-card__badge">{{ tag | upcase }}</span>{%- break -%}{%- endif -%}
    {%- endfor -%}
    {%- if product.compare_at_price > product.price -%}<span class="mt-card__badge mt-card__badge--oferta">SALE</span>{%- endif -%}
    {%- unless product.available -%}<span class="mt-card__badge mt-card__badge--agotado">AGOTADO</span>{%- endunless -%}
    {%- if mostrar_tallas -%}
      {%- assign talla_opt = product.options_by_name['Talla'] | default: product.options_by_name['Size'] -%}
      {%- if talla_opt -%}
        <ul class="mt-card__tallas" aria-label="Tallas">
          {%- for v in talla_opt.values -%}<li>{{ v }}</li>{%- endfor -%}
        </ul>
      {%- endif -%}
    {%- endif -%}
  </a>
  <div class="mt-card__info">
    <h3 class="mt-card__title"><a href="{{ product.url }}">{{ product.title }}</a></h3>
    {%- if product.metafields.custom.material != blank -%}<p class="mt-card__meta">{{ product.metafields.custom.material }}</p>{%- endif -%}
    <p class="mt-card__price">
      {{ product.price | money }}
      {%- if product.compare_at_price > product.price -%}<s>{{ product.compare_at_price | money }}</s>{%- endif -%}
    </p>
  </div>
</article>
```

CSS clave:

```css
.mt-card__media { position: relative; display: block; aspect-ratio: var(--mt-ratio-producto); overflow: hidden; background: var(--mt-fondo-tarjeta, #F2F2F2); }
.mt-card__img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; transition: opacity .5s var(--mt-ease), transform .8s var(--mt-ease); }
.mt-card__img--hover { opacity: 0; }
@media (hover: hover) {
  .mt-card:hover .mt-card__img--hover { opacity: 1; }
  .mt-card:hover .mt-card__img:not(.mt-card__img--hover) { transform: scale(1.03); }
  .mt-card__tallas { position: absolute; left: 0; right: 0; bottom: 0; display: flex; gap: 6px; padding: 12px; opacity: 0; transform: translateY(8px); transition: .35s var(--mt-ease); }
  .mt-card:hover .mt-card__tallas { opacity: 1; transform: none; }
}
@media (hover: none) { .mt-card__tallas { display: none; } }
```

El `object-fit: cover` con fondo de tarjeta igual al del mockup evita el
"cuadrado gris". Si los mockups del usuario tienen fondo blanco y la ficha
pide tarjetas hueso, usa `object-fit: contain` + fondo hueso y avisa de que
lo ideal es un mockup con fondo del color de la tienda (fase 6 puede
generarlo).

### 11.3 Selector de talla (página de producto) — el fallo nº 1

Botones píldora/cuadrados por valor de la opción de talla, que actualizan
variante, precio, disponibilidad e `input[name=id]`. Receta completa y JS en
`references/07-catalogo-producto-y-paginas.md` (paso 1.3). Aquí la regla:
**la talla seleccionada cambia el id de variante ANTES de que el usuario
pueda pulsar "añadir"**, y las tallas agotadas se ven tachadas pero
seleccionables (para notificar) o deshabilitadas según la ficha.

### 11.4 Guía de tallas editable (drawer/modal)

Sección o bloque con una tabla que el usuario edita como texto:

```json
{ "type": "textarea", "id": "tabla_tallas", "label": "Guía de tallas (una fila por línea, columnas separadas por |)",
  "default": "Talla | Pecho (cm) | Largo (cm)\nS | 108 | 70\nM | 114 | 72\nL | 120 | 74\nXL | 126 | 76" },
{ "type": "textarea", "id": "nota_fit", "label": "Nota sobre el corte", "default": "Corte oversized. Si dudas entre dos tallas, elige la pequeña para un fit más ajustado." }
```

```liquid
{%- assign filas = section.settings.tabla_tallas | newline_to_br | split: '<br />' -%}
<table class="mt-tallas">
  {%- for fila in filas -%}
    {%- assign celdas = fila | strip | split: '|' -%}
    <tr>{%- for c in celdas -%}{%- if forloop.parentloop.first -%}<th>{{ c | strip }}</th>{%- else -%}<td>{{ c | strip }}</td>{%- endif -%}{%- endfor -%}</tr>
  {%- endfor -%}
</table>
```

Se abre desde un enlace "Guía de tallas" junto al selector (`<details>` o
un drawer con `dialog`), accesible con teclado.

### 11.5 Lookbook / editorial con las fotos de modelo del usuario

Blocks del schema (uno por foto) con `image_picker` + `text` (pie:
"Look 03 — Paris, 07:40") + `url` opcional (a un producto). Layouts según la
ficha: banda arrastrable con `scroll-snap`, grid bento asimétrico, collage
con ligeras rotaciones, o "two-up" a sangre. Proporción del lookbook desde
`--mt-ratio-look`. Cada foto entra con reveal escalonado. En móvil: carrusel
de una foto y media visible (invita a deslizar).

### 11.6 Marquesina (barra de anuncio o costura)

Contenido duplicado + animación de `transform`; velocidad, dirección, color
de fondo/texto y separador ("✦", "—", "•") en el schema; pausa al hover;
`prefers-reduced-motion` la deja estática. Textos como blocks (cada frase
editable). Va pegada al héroe (costura deliberada) o entre dos bloques de
color distinto (transición diseñada).

### 11.7 Logo gigante en el footer / firma

El diseño frontal del usuario (PNG transparente) o el nombre en la display,
a un ancho del 90-100% del contenedor, con `clamp` y `aspect-ratio` fijo
para que no salte al cargar. Si el footer es oscuro y el logo es tinta
negra, usa la versión clara generada (fase 6) o, si el logo es monocromo
puro, `filter: invert(1)` (solo si no tiene colores: el azul de "FOUNDERS
CLUB" se invertiría a naranja — en ese caso, versión clara sí o sí).

### 11.8 Bloque "historia del diseño"

Foto grande del detalle del estampado (del usuario) o del diseño trasero
sobre un fondo del color de la ficha + texto largo editable + 3-6 "fichas"
(blocks) con título y texto para cada elemento del diseño (p. ej. cada
fundador, cada símbolo). Con hotspots opcionales sobre la foto (posiciones en
% editables). Es el bloque que más convierte en marcas con concepto: cuídalo.

### 11.9 Transiciones y animaciones: usa el catálogo de `13`

Antes de escribir la primera sección lee `13-lecciones-y-recetas.md` §2-§7:
maqueta del héroe, titulares por palabras, catálogo de costuras
diseñadas, animaciones "sutiles pero top" (entrada de fotos, línea que se
dibuja, palabras que enfocan, máquina de escribir, paralaje de ventana,
foto incrustada en el titular), lookbook con flechas suaves y scroll suave
con Lenis. Elige 3-5 por tienda y combínalos de forma distinta cada vez.

## Flujo de trabajo de la fase

1. `mt-styles.css` (tokens DESDE la ficha + base + tarjeta + reveals) y
   `mt-scripts.js` (esqueleto con guard).
2. `snippets/mt-tarjeta-producto.liquid` (lo usan tres sitios).
3. Secciones de una en una según la composición de la fase 4, con su
   arquetipo anotado en `ESTADO.md`.
4. `templates/index.json` + checklist de costuras.
5. Sube y previsualiza (fase 8) ANTES de enseñar nada, en 16:9 y móvil.
6. Sigue con la fase 7 (colección, producto, header, footer, legales).
