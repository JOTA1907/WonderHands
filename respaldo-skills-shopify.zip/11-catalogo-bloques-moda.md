# Catálogo de bloques para tiendas de moda — 72 arquetipos

Complemento de la ficha de estilo: la ficha dice CÓMO se ve; el catálogo
dice QUÉ bloques hay y cómo se comportan. Los 🔥 llevan animación, scroll o
reacción al ratón. Todos cumplen las reglas de la fase 5 (editabilidad,
fondo-en-el-envoltorio, costuras, reduced-motion, solo transform/opacity).

## Cómo usar el catálogo

1. **Elige 7-10 arquetipos** en la fase 4: apertura → producto → historia →
   prueba → cierre, con al menos un bloque que muestre productos REALES
   (familia B) y uno de historia/concepto (familia D) si la marca tiene
   concepto.
2. **Mínimo 3 🔥**, alternados con bloques serenos. En moda, la sobriedad
   vende: mejor 8 bloques bien ritmados que 12.
3. **Nunca la misma combinación** que otra tienda; anota los números en
   `ESTADO.md`.
4. **La ficha manda**: el arquetipo es la composición y la interacción; la
   piel (colores, radios, tipografía, proporciones de foto) sale SIEMPRE de
   la ficha de estilo. El mismo nº 3 puede ser crema+serif o negro+grotesca.
5. **Cada foto, del mapa de uso o del guion**: un bloque sin foto asignada
   no entra.
6. **Cruza e inventa** a partir del catálogo; anota los inventos buenos.

---

## A. Aperturas / héroes de moda (1-12)

1. 🔥 **Héroe editorial tipográfico + foto lateral** — Titular enorme en
   mayúsculas (display de la ficha) ocupando la mitad izquierda, con una
   palabra en cursiva serif de contrapunto; a la derecha una foto de modelo
   vertical (3:4) a sangre hasta el borde; opcional un bloque de color de
   acento con "DROP 01 / nombre de la prenda / precio / SHOP →". Entrada:
   palabras del titular en reveal escalonado, foto con zoom-out. *Úsalo
   cuando:* la ficha es "streetwear editorial" y el usuario tiene fotos de
   modelo verticales (no hace falta banner). *Nota:* en móvil, titular
   arriba, foto debajo a 4:5.
2. 🔥 **Héroe panorámico a sangre con texto superpuesto** — Banner 16:9 bajo
   contrato (modelo en un tercio, aire para el texto), titular grande y CTA
   sobre la foto, degradado inferior de legibilidad, imagen vertical propia
   para móvil. Zoom-out lento al cargar. *Úsalo cuando:* hay banner (real o
   generado) potente. *Nota:* posición focal expuesta.
3. **Héroe de lujo silencioso** — Fondo crema, nombre de la marca en serif
   enorme centrado, una foto perfecta debajo o detrás con velo suave, una
   línea de texto pequeña con espaciado y un enlace subrayado. Fade lento.
   *Úsalo cuando:* ficha "old money / refinado". La contención es el lujo.
4. 🔥 **Nombre de marca gigante con el modelo delante** — El nombre en
   display a todo el ancho (~18vw) y la foto del modelo recortada (PNG) o a
   sangre solapando las letras; el modelo entra con un ligero parallax
   distinto al del texto. *Úsalo cuando:* el nombre de la marca es corto y
   fuerte. *Nota:* necesita un recorte del modelo (IA con fondo del color
   exacto de la sección, fase 6) o una foto con fondo liso.
5. 🔥 **Héroe partido con numeral de drop** — Mitad color de fondo con un
   numeral gigante semitransparente ("02") detrás del titular, mitad foto;
   la etiqueta de temporada en mono arriba ("AUTUMN / WINTER 26"). Hover:
   la foto escala 1.03. *Úsalo cuando:* la ficha tiene numerales y
   etiquetas de temporada.
6. 🔥 **Héroe de doble vista (delante / detrás)** — Dos fotos verticales
   lado a lado: la frontal y la trasera de la prenda (mockups naturales o
   modelo de frente y de espaldas); el hover expande la mitad activa
   (`flex-grow`). Titular corto arriba. *Úsalo cuando:* el diseño trasero es
   el protagonista y el frontal es discreto (streetwear clásico).
7. 🔥 **Héroe con marquesina pegada** — Cualquier héroe + banda infinita
   inferior con claims ("FREE SHIPPING — NEW DROP — LIMITED RUN")
   compartiendo fondo (costura deliberada). *Úsalo cuando:* la ficha tiene
   marquesina. Resuelve la costura héroe→siguiente de serie.
8. 🔥 **Héroe carrusel de looks** — 3-5 fotos de modelo con crossfade
   automático, cada slide con su etiqueta editable ("LOOK 01 · PARIS"),
   contador "01 / 05" en mono y flechas. *Úsalo cuando:* hay muchas fotos de
   modelo buenas y ninguna sobresale.
9. 🔥 **Héroe vídeo/loop de campaña** — Vídeo silencioso de fondo (si el
   usuario lo tiene) o "falso vídeo": 3-4 fotos con Ken Burns muy lento.
   *Nota:* póster para móvil; `muted playsinline loop`.
10. 🔥 **Héroe spotlight nocturno** — Fondo negro, la foto de modelo con
    viñeta y un foco radial que sigue suavemente al cursor; titular blanco.
    *Úsalo cuando:* ficha "trap / noche / lujo joven".
11. **Héroe manifiesto** — Sin foto: solo un manifiesto de 2-4 líneas en
    display grande, con una palabra en acento; debajo, la primera fila de
    productos ya visible. *Úsalo cuando:* la marca es más idea que imagen o
    las fotos son pocas y se reservan.
12. 🔥 **Héroe sticky-shrink** — Al hacer scroll el héroe se encoge y
    redondea hasta quedar como tarjeta. *Úsalo cuando:* landing narrativa
    premium con pocos bloques. Degrada a estático en móvil.

## B. Escaparate de producto / colección (13-26) — productos REALES

13. **Grid de colección numerado** — Tarjetas 4:5 con "01 / 02 / 03" grande
    en la esquina, nombre, material en mono, precio; líneas divisorias finas
    entre celdas (estilo revista); hover a segunda foto. Cabecera con
    titular + contador "01 / 06" + flechas. *Úsalo cuando:* ficha
    "editorial streetwear". *Nota:* patrón 11.1 + 11.2 de la fase 5.
14. **Grid de colección limpio** — Tarjetas sin bordes, mucho aire, nombre y
    precio en pequeño; hover a segunda foto y aparición de tallas. *Úsalo
    cuando:* ficha "minimal / refinado".
15. 🔥 **Tira de productos arrastrable** — Banda horizontal con scroll-snap,
    tarjetas altas, cursor "⟷ arrastra" en escritorio, inercia nativa en
    móvil. *Úsalo cuando:* 5+ prendas y la ficha es dinámica.
16. 🔥 **Bento de colección** — Grid asimétrico: una prenda en celda doble
    (la estrella), las demás pequeñas; cada celda con hover. *Úsalo cuando:*
    hay prenda estrella + secundarias.
17. **Una prenda, a lo grande** — Para catálogos de 1 prenda: foto grande a
    la izquierda (mockup natural), a la derecha nombre, precio, tallas
    (píldoras), 3 argumentos y botón que lleva al producto (o formulario de
    compra directo con el selector de talla, fase 7). *Úsalo cuando:* una
    sola prenda. *Nota:* alimentado por `product` del schema.
18. 🔥 **Comprar por categoría** — 3-4 tarjetas de colección (Tees / Hoodies
    / Accesorios) con la imagen de cada colección y el nombre; hover oscurece
    y muestra "VER →". *Úsalo cuando:* 6+ prendas en varias familias.
19. 🔥 **Novedades con etiqueta NEW** — Grid de la colección "nuevo" con
    badges por etiqueta y reveal escalonado. *Úsalo cuando:* hay drops
    periódicos.
20. **Best sellers elegidos a mano** — `product_list` de 3-4 productos con
    una frase por qué ("el que más repite la gente"). *Úsalo cuando:* el
    usuario tiene datos de ventas.
21. 🔥 **Tarjeta con compra rápida** — Tarjeta que al hover muestra las
    tallas como botones y añade al carrito directamente (petición a
    `/cart/add.js` con el id de variante de esa talla). *Úsalo cuando:*
    catálogo sencillo (una opción). *Nota:* fallback a la página de producto
    en móvil.
22. 🔥 **Colección con filtro por talla** — Chips de talla arriba que
    ocultan/muestran tarjetas según disponibilidad (JS sobre
    `data-tallas`). *Úsalo cuando:* 8+ prendas.
23. **Tabla de drop** — Lista tipográfica (no grid): número, nombre, material,
    precio y una miniatura pequeña que crece al hover. Estilo "lista de
    precios de sastrería". *Úsalo cuando:* ficha muy editorial/refinada.
24. 🔥 **Prenda + detalles satélite** — Foto grande de la prenda con 3-4
    puntos (hotspots) que abren mini-tarjetas: "algodón 240 g", "estampado
    serigrafiado", "cuello reforzado". *Úsalo cuando:* el argumento es la
    calidad física. *Nota:* posiciones en % editables.
25. 🔥 **Selector de color/variante narrativo** — Swatches que cambian la foto
    de la prenda (si hay varios colores). *Úsalo cuando:* variantes de color
    reales con foto propia.
26. **Banda "próximamente"** — Siluetas o fotos veladas de las próximas
    prendas con "SOON" y botón de aviso (newsletter opcional). *Úsalo
    cuando:* catálogo de 1-2 prendas que va a crecer (con permiso del
    usuario: no prometas drops que no existen).

## C. Editorial y lookbook (27-36)

27. 🔥 **Lookbook arrastrable** — Banda horizontal de fotos de modelo 3:4 con
    scroll-snap, pies en mono ("LOOK 03 — PARIS, 07:40"), cursor
    personalizado. *Úsalo cuando:* 6+ fotos de modelo (el caso normal).
28. 🔥 **Bento editorial** — Grid asimétrico de 5-7 fotos de modelo con
    reveals escalonados; una celda tipográfica con una frase. *Úsalo
    cuando:* fotos variadas en formato.
29. 🔥 **Two-up a sangre** — Dos fotos verticales a sangre lado a lado con un
    titular cruzando ambas; parallax suave distinto en cada una. *Úsalo
    cuando:* dos fotos que dialogan (día/noche, frontal/trasera).
30. 🔥 **Collage con rotaciones** — 3-5 fotos solapadas con rotaciones sutiles
    y parallax entre capas; hover endereza y eleva. *Úsalo cuando:* ficha
    "archivo / polaroid / retro".
31. **Editorial imagen + texto** — Foto vertical grande a un lado, columna de
    texto estrecha al otro (titular serif, párrafo, enlace subrayado).
    Reveals desde el lado. *Úsalo cuando:* ficha "refinado" con texto que
    contar. Máximo 2-3 en una página, alternando lados.
32. 🔥 **Panorámica de respiro con parallax** — Una foto apaisada a sangre
    (contrato del banner) entre dos bloques densos, con una frase o sin
    nada. *Úsalo cuando:* la página necesita aire.
33. 🔥 **Capítulos horizontales** — El scroll vertical mueve 3-4 escenas
    horizontalmente (lookbook "capítulo 1/2/3"). *Úsalo cuando:* historia con
    capítulos y fotos fuertes. En móvil: carrusel.
34. 🔥 **Journal / historias** — 3 tarjetas de artículo estilo revista
    (imagen, número, titular, "READ STORY →") apuntando a páginas o al blog
    de Shopify. *Úsalo cuando:* la ficha tiene "journal" y el usuario
    escribirá contenido (si no, no lo pongas).
35. 🔥 **Mosaico vivo de campaña** — Grid cuyas celdas intercambian fotos
    cada pocos segundos (FLIP). *Úsalo cuando:* 10+ fotos y ganas de
    movimiento. Pausa al hover y con reduced-motion.
36. **Frase editorial entre fotos** — Un titular enorme de 2 líneas con una
    foto pequeña incrustada entre las palabras (estilo Lunara "SEE YOU
    OUTSIDE"). *Úsalo cuando:* ficha "editorial tipográfica".

## D. Historia de la marca, concepto y diseño (37-46)

37. 🔥 **La historia del diseño** — Foto grande del detalle del estampado
    (o el diseño sobre el fondo de la ficha) + texto largo + fichas por
    elemento (blocks) con reveal; hotspots opcionales. *Úsalo cuando:* el
    estampado tiene significado (fundadores, símbolos, fechas). Es el bloque
    que más convierte en marcas con concepto.
38. 🔥 **Manifiesto con subrayado vivo** — Párrafo grande centrado; las
    palabras clave se subrayan con un trazo que se dibuja al entrar. *Úsalo
    cuando:* la marca tiene un porqué.
39. 🔥 **Frase que se ilumina palabra a palabra** — Texto grande gris que
    pasa a color pleno con el scroll. *Úsalo cuando:* respiro editorial
    premium.
40. 🔥 **Muro de fundadores / iconos en blanco y negro** — Grid de retratos
    documentales en b/n (los del diseño o generados genéricos) con nombre
    del "capítulo" y una frase; hover a color o a la foto siguiente. *Úsalo
    cuando:* el concepto es "club", "founders", "legends". *Nota:* si son
    personas reales de las que el usuario tiene fotos, se usan como
    ilustración del diseño (ya están en la prenda); no generes sus caras.
41. **Cita del fundador** — Retrato pequeño (del usuario, si quiere) o sin
    foto, cita en serif grande, firma. *Úsalo cuando:* marca personal.
42. 🔥 **Timeline de la marca / del drop** — Línea que se dibuja con hitos
    ("Idea · Diseño · Primera tirada · Drop 01"). *Úsalo cuando:* hay
    historia real.
43. 🔥 **De la idea a la prenda** — 3-4 pasos con fotos en serie (boceto →
    diseño → impresión → prenda) generadas encadenadas o reales. *Úsalo
    cuando:* producción propia o POD con orgullo del proceso.
44. **Tarjeta de miembro** — Una "tarjeta de socio" tipográfica (nombre de
    la marca, "MEMBER SINCE 2026", numeración) con ligera inclinación 3D al
    cursor. *Úsalo cuando:* concepto "club". *Nota:* solo decorativo; no
    prometas membresías que no existen.
45. **Problema → actitud** — Dos paneles (gris/apagado vs. acento): "lo que
    llevan todos" vs. "lo que llevas tú". *Úsalo cuando:* tono desafiante.
46. 🔥 **Texto vertical + foto** — Foto de modelo con el claim escrito en
    vertical a un lado (estilo "BUILT TO MOVE"), líneas de cota decorativas.
    *Úsalo cuando:* ficha con texto vertical y marcas de regla.

## E. Producto en detalle: tejido, corte, tallas, cuidados (47-54)

47. 🔥 **Zoom macro del estampado** — Foto de detalle que se acerca ligada al
    scroll hasta ver el grano de la tinta. *Úsalo cuando:* hay foto de
    detalle (real o generada).
48. **Ficha de tejido y corte** — Grid de 4-6 datos con iconos de línea
    (gramaje, algodón, corte, cuello, fabricación, cuidados). *Úsalo cuando:*
    comprador que mira calidad.
49. 🔥 **Guía de tallas interactiva** — Tabla editable + selector de altura
    /peso que sugiere talla (fórmula simple editable). *Úsalo cuando:* la
    talla es la duda principal (oversized).
50. **Delante y detrás** — Mockups frontal y trasero lado a lado con
    etiquetas "FRONT / BACK" y una línea de texto por vista. *Úsalo cuando:*
    hay ambos mockups (casi siempre).
51. 🔥 **Acordeón con foto viva** — Acordeón (tejido / corte / estampado /
    cuidados) que cambia la foto del otro lado con crossfade. *Úsalo cuando:*
    4 fotos de prenda distintas (natural, detalle, frontal, trasera).
52. 🔥 **Qué recibes (unboxing)** — Bodegón cenital (generado o real) con
    etiquetas conectadas por líneas que se dibujan. *Úsalo cuando:* el
    packaging suma.
53. **Cuidados en iconos** — Fila de iconos de lavado con texto corto. Útil
    también en la página de producto.
54. 🔥 **Comparador de corte** — Deslizador "regular / oversized" o "S / XL"
    con dos fotos del mismo encuadre (serie encadenada). *Úsalo cuando:* el
    corte es argumento.

## F. Comunidad y prueba social (55-62)

55. 🔥 **Galería de comunidad** — Grid tipo Instagram con fotos de clientes o
    lifestyle; hover revela @nombre y frase. *Úsalo cuando:* hay comunidad
    real o fotos claramente ilustrativas (sin inventar identidades).
56. 🔥 **Marquesina de reseñas** — Frases cortas + estrellas en banda infinita;
    también sirve de costura. *Nota:* solo reseñas reales.
57. **Carrusel de reseñas** — Tarjetas con nombre, ciudad, talla comprada,
    texto. *Úsalo cuando:* hay reseñas reales. Evita si ya hay otro carrusel.
58. 🔥 **Cifras del drop** — "120 unidades · 4 ciudades · 1 diseño" con
    count-up. *Nota:* cifras reales del usuario.
59. 🔥 **UGC en vídeo** — Vídeo vertical en marco de móvil + cita. *Úsalo
    cuando:* el usuario tiene vídeos.
60. **Visto en / llevado por** — Logos o nombres en gris. *Solo si son reales.*
61. 🔥 **Chat simulado** — Mensajes tipo WhatsApp apareciendo ("¿te ha
    llegado?" "brutal la calidad"). *Úsalo cuando:* tono cercano; textos
    reales.
62. **Etiqueta con instrucciones para etiquetar** — "Sube tu foto con
    #HSTLRS" + grid vacío que el usuario rellena desde el editor. *Úsalo
    cuando:* quiere construir comunidad desde cero.

## G. Cierres y conversión (63-68)

63. 🔥 **CTA con logo gigante** — El logo/nombre a todo el ancho con el
    botón debajo y un degradado o foto con parallax detrás. *Úsalo cuando:*
    cierre con identidad.
64. 🔥 **Cuenta atrás del drop** — Fecha real editable, contador y botón
    "notificarme". *Solo con drop real.*
65. **Tarjeta de compra resumen** — Foto + precio + tallas + 3 bullets +
    botón. Cierre por claridad para 1 prenda.
66. **Newsletter "únete al club"** — Email + promesa concreta; `{% form
    'customer' %}` real. *Solo si el usuario lo pide.*
67. 🔥 **CTA rodeado de marquesina** — Botón grande con banda infinita
    ("SHOP DROP 01 ✦ FREE SHIPPING ✦"). *Úsalo cuando:* marcas jóvenes.
68. **Garantía + cambio de talla** — "Cambio de talla gratis 30 días" como
    protagonista + botón. *Úsalo cuando:* la talla es el miedo principal.

## H. Bandas, marquesinas y costuras (69-72)

69. 🔥 **Marquesina separadora** — Banda infinita entre dos bloques de color
    distinto; dirección/velocidad/separador editables.
70. **Línea editorial** — Divisoria de 1px del color de la ficha con dos
    etiquetas mono a los extremos ("AUTUMN / WINTER 26" — "26 / 26"). *Úsalo
    cuando:* ficha con líneas finas.
71. 🔥 **Banda de logos/sellos deslizante** — Sellos de la marca ("EST. 2026",
    "XXI CENTURY", "FOUNDERS CLUB") en banda monocroma. *Úsalo cuando:* el
    diseño tiene sellos propios (los tuyos, no de terceros).
72. **Franja de anuncio editable** — Texto corto + enlace, fondo de acento.
    Editable/ocultable desde el editor.

---

## I. Arquetipos añadidos tras producción (73-78)

73. 🔥 **Two-up con máquina de escribir** — Dos fotos a sangre con
    entrada desde los lados, línea central que se dibuja, titular en dos
    líneas fijas: la primera estática y la segunda (cursiva) se escribe,
    borra y reescribe con cursor (palabras editables). Fundidos arriba y
    abajo a los colores vecinos. *Úsalo cuando:* dos fotos que dialogan y
    un claim con variaciones ("Work is the uniform / goal / reward").
74. 🔥 **Lookbook de ventanas con paralaje** — Arcos (o marcos rectos)
    donde la foto interior es un 50 % más alta y se desplaza a otro ritmo
    al hacer scroll; pies centrados con fórmula propia; flechas con
    deslizamiento suave. *Úsalo cuando:* 6+ fotos verticales.
75. **Sección partida clara/oscura** — El titular de dos líneas cruza la
    frontera: línea 1 en la banda clara, línea 2 en la oscura; debajo, el
    contenido narrativo. Costura diseñada dentro de la sección. *Úsalo
    cuando:* hay un "antes / después" en el mensaje.
76. **Prenda que muerde el bloque anterior** — El bloque de producto
    arranca con una franja del color del bloque anterior y la foto la
    invade. *Úsalo cuando:* tira/marquesina oscura seguida de producto en
    claro.
77. **Cierre de dos líneas con foto de apertura de línea** — Titular
    enorme en dos líneas; una foto pequeña inclinada abre la segunda
    línea; debajo, franja de foto con paralaje que funde al footer. *Úsalo
    cuando:* cierre editorial con identidad.
78. **Banda de sellos fina** — Marquesina de 40-60 px con los sellos de la
    marca separados por un símbolo de acento, pegada al héroe o entre dos
    bloques. Variante compacta de la 69/71.

> Combinación usada en el ejemplo `12`: 2·71·17·40·29·27·51·36 (+73/74/75/76/77
> como variantes). **No la repitas**: cada tienda estrena su combinación.

## Recordatorios finales

- **Ritmo**: alterna densidad, color (claro → oscuro con costura resuelta) y
  movimiento. Una portada de moda suele ser: héroe → marquesina → colección
  → historia → lookbook → detalle → prueba → cierre → footer con logo.
- **Las fotos del usuario primero**: los bloques se eligen para lucir SUS
  fotos; la IA rellena huecos de formato y variedad.
- **Los banners (2, 7, 32, 63) cumplen el contrato** (fase 6), también con
  fotos reales.
- **Nada inventado**: reseñas, cifras, logos, drops y membresías solo si
  existen. En moda, la credibilidad es parte del estilo.
