# Fase 4 — Del concepto y la ficha de estilo a la propuesta (mensaje 2)

Objetivo: convertir la ficha de estilo (fase 3) + el concepto del usuario +
lo leído en la tienda (fase 1) en una propuesta concreta y en la lista de
bloques a construir. Termina con el **mensaje 2**, el único momento en que
vuelves a necesitar al usuario antes de enseñarle la tienda.

## 1. Extraer el brief del concepto

Del texto libre del usuario saca y anota en `ESTADO.md`:

- **Marca**: nombre, eslogan/claim si lo hay, "quién es" en una frase.
- **Prendas**: cuántas, cuáles (camiseta, sudadera...), cuál es la estrella.
- **Público**: edad, mundo (emprendedores, skaters, gimnasio...), qué
  quiere sentir al llevarla.
- **Sensación**: 3-5 adjetivos del usuario, traducidos con el diccionario de
  la fase 3.6 a decisiones (si contradicen la ficha, gana lo que dijo el
  usuario y ajusta la ficha).
- **Idioma de la tienda** y si los claims van en inglés.
- **Precio/tallas** si los dijo (para el catálogo, fase 7).
- **Historia del diseño**: qué significa el estampado (p. ej. "cinco
  fundadores en blanco y negro con HSTLRS / FOUNDERS CLUB / XXI CENTURY").
  Es oro para un bloque narrativo: las marcas de camisetas con concepto
  venden la historia, no el algodón.

Si el concepto es de dos líneas, no preguntes más: deduce del material (la
estética de las fotos de modelo y las referencias dicen mucho) y propón.

## 2. Estructura de tienda según nº de prendas

| Situación | Portada | Colección | Producto |
|---|---|---|---|
| 1 prenda | Héroe con la prenda estrella → historia del diseño → detalle → colección "Todo" (1 tarjeta grande + huecos "próximamente" opcionales) → lookbook → CTA | Plantilla propia, lista para crecer | Página completa con tallas |
| 2-5 prendas (cápsula/drop) | Héroe del drop → grid de la colección (todas) → historia → lookbook mezclando prendas → detalle/tejido → CTA | Una colección "Drop 01"/"Todo" | Página completa + "completa el look" |
| 6+ prendas | Héroe → bloque "comprar por categoría" (camisetas / sudaderas / accesorios) → novedades → editorial → best sellers → CTA | Varias colecciones + "Todo" | Página completa + relacionados por colección |

En todos los casos la portada muestra productos REALES de la tienda vía
colección (fase 5, patrón de colección destacada), nunca imágenes sueltas
simulando productos.

## 3. Elegir los bloques del catálogo de moda

Abre `references/11-catalogo-bloques-moda.md` y elige **7-10 arquetipos**
que cuenten la historia: apertura → producto → historia/concepto → prueba →
cierre. Reglas:

1. **La ficha manda sobre el catálogo**: elige arquetipos que ENCAJEN con las
   firmas visuales de la ficha (si la firma es "numerales y marquesina",
   entran el grid numerado y la marquesina; si es "arcos y píldoras", el
   carrusel de arcos).
2. **Mínimo 3 arquetipos 🔥**, alternados con bloques serenos.
3. **Nunca repitas la combinación de otra tienda** (anota los números en
   `ESTADO.md`).
4. **Cada bloque con foto tiene su foto asignada** del mapa de uso (fase 3)
   o una entrada en el plan de fotos IA (fase 6). Un bloque sin foto
   asignada no entra.
5. **Un bloque de historia del diseño** casi siempre entra en marcas de
   camisetas con concepto (familia D del catálogo).
6. **Costuras planificadas ya** (familia H): dónde cambia el color de fondo
   y cómo se resuelve.

Escribe en `ESTADO.md` la composición: `nº · nombre · qué foto/producto
usa · fondo claro/oscuro · costura con el siguiente`.

### 3b. Variedad garantizada: composición por familia de estilo

Para que dos tiendas no salgan iguales, elige los arquetipos partiendo de
la **familia** de la ficha y de una de estas "recetas semilla" (cámbiala,
no la calques; anota en `ESTADO.md` y en la memoria del proyecto la
combinación final para no repetirla):

| Familia | Receta semilla (nº del catálogo 11) | Costuras sugeridas (13 §4) |
|---|---|---|
| Editorial de revista | 1 o 2 · 69/71 · 13 · 37 o 40 · 29 o 36 · 27 · 48 o 51 · 63 o 36 | fundido + solape + línea editorial |
| Lujo silencioso | 3 · 70 · 14 · 31 · 32 · 23 o 20 · 48 · 65 | contraste con aire + línea editorial + panorámica |
| Noche y neón | 10 o 2 · 71 · 16 · 40 · 33 o 29 · 8 o 27 · 47 · 67 | fundidos a negro + sección partida |
| Archivo / retro | 5 · 69 · 13 · 30 · 42 · 44 · 50 · 63 | solape + collage + sellos |
| Deportivo técnico | 6 o 9 · 71 · 22 o 15 · 24 · 54 · 58 · 68 | bandas + contraste |
| Esencial premium | 3 o 11 · 70 · 14 · 17 · 51 · 53 · 65 | continua + líneas |

Reglas: (a) nunca la misma combinación de números que una tienda anterior
(mira la memoria del proyecto), (b) 3-5 efectos "firma" por tienda (13 §5),
no todos, (c) cada tienda estrena al menos un arquetipo que no hayas usado
antes. El ejemplo de `12` usó 2·71·17·40·29·27·51·36: **no lo repitas**.

### 3c. Copys con identidad

Escribe los textos PARA esa marca antes de construir (en `ESTADO.md`):
claim del héroe (2 líneas, la segunda en cursiva), subtítulo de una
línea, 4-6 sellos de la banda, etiqueta de drop, 5-9 pies de foto del
lookbook con una fórmula propia (p. ej. "For late shifters, 01:40 AM";
inventa otra fórmula en cada tienda), líneas del bloque de historia,
frase de cierre, frase del footer. Ofrece siempre 2-3 alternativas de las
frases clave en el mensaje 2 o cuando el usuario diga "no me convence".

## 4. Plan de fotos

Con los bloques elegidos, decide por cada hueco de imagen:

- **Tal cual** (foto del usuario, optimizada; si es banner, recortada al
  ratio exacto con `recortar-banner.*` y verificada).
- **Generar** (solo si dio clave): entra en el guion fotográfico de la fase
  6 con su bloque, su ratio y su intención. Prioriza generar lo que el
  usuario NO tiene: banner panorámico 16:9 y vertical 9:16 del héroe (sus
  fotos suelen ser verticales 3:4), escenas nuevas del universo del concepto
  para variar el lookbook, bodegón "qué incluye", detalle macro si no lo
  hay, versión clara del logo si el fondo será oscuro.
- **Hueco editable** (sin clave y sin foto adecuada): image_picker con un
  fallback neutro del color de la ficha, y lo apuntas en pendientes.

Si el usuario tiene 10+ fotos de modelo buenas (caso frecuente), la IA es
un complemento para banners y escenas concretas, no el grueso. No generes
por generar: cada foto IA cuesta dinero y tiempo de revisión.

## 5. El mensaje 2 (uno solo, con todo)

Estructura, en el idioma del usuario y sin jerga:

1. **Lo que encontré en tu carpeta** (3-5 líneas): "N capturas de tiendas de
   referencia, M fotos de modelo, X mockups de la prenda, el diseño frontal y
   trasero, y K fotos de personajes que entiendo que son la inspiración del
   concepto". Si algo no supiste clasificar: "hay 2 imágenes que no sé si
   quieres en la tienda o solo como inspiración: <nombres>".
2. **Lo que entendí de tus referencias** (4-6 líneas de diseño llano): la
   frase resumen de la ficha + qué coges de cada referencia ("de la primera
   la estructura y los titulares enormes; de la de fondo crema la elegancia
   y las letras serif; de la oscura los botones redondeados"). Esto genera
   confianza y permite corregir antes de construir.
3. **Cómo será tu tienda** (bloque a bloque, en palabras, 6-10 líneas
   numeradas): "1) Apertura con tu foto de la gasolinera a pantalla completa
   y el claim en letras enormes; 2) tira con tus prendas y precios; 3) la
   historia de los cinco fundadores del diseño; 4) ...". Sin números de
   arquetipo.
4. **Fotos**: qué usarás tal cual y, si dio clave, qué 4-8 fotos generarías
   y para qué ("un banner apaisado para la apertura, porque tus fotos son
   verticales; una versión clara del logo para el pie oscuro..."). Si no dio
   clave: "monto todo con tus fotos; donde falte algo dejo un hueco que
   puedes rellenar desde el editor".
5. **Dudas que bloquean (máx. 3)**: idioma de los textos, prenda estrella si
   hay varias, precio/tallas si no hay producto. Ofrece tu opción por
   defecto en cada una ("si no me dices nada, lo hago en español con los
   claims en inglés").
6. Cierre: "Si te encaja, dime 'adelante' (o lo que quieras cambiar) y me
   pongo a construir. Te aviso cuando tenga algo que enseñarte."

Longitud: 20-30 líneas en total. Sin tablas de más de 10 filas. Nada de
nombres de arquetipos ni de archivos. Si el usuario ya dio el OK en su
primer mensaje ("con eso ya puedes empezar"), envía igualmente el mensaje
2 (es donde corrige antes de que construyas), pero más corto (12-18
líneas) y deja claro que arrancas en cuanto diga "adelante".

Una ronda de feedback basta. Si pide cambios, intégralos en la ficha y en la
composición (anótalo) y construye. No abras un tercer mensaje salvo bloqueo
real.

## 6. Preparar las imágenes de uso directo para el tema

- Copia a `assets/` SOLO las que entren en el diseño, ya optimizadas, con
  nombre de slot (`hs-hero-escritorio.jpg`, `hs-look-3.jpg`).
- Banners: recorte al ratio exacto (`recortar-banner.*`, con `-CentroY`
  para conservar la cabeza del modelo) y comprobación visual.
- Fotos de producto que deban estar en la galería del catálogo: no van a
  `assets/`, se suben al producto por Admin API (fase 7).
- Logo: si el diseño frontal transparente hace de logo, guarda una versión
  PNG optimizada (`hs-logo.png`, ~800px de ancho) y, si el header/footer es
  oscuro, prepara la versión clara (IA en fase 6, o CSS `filter` si es
  monocromo puro).

## Cierre de la fase

1. `ESTADO.md`: brief, composición con números de arquetipo, plan de fotos
   (tal cual / generar / hueco), decisiones del usuario tras el mensaje 2.
2. Si hay clave y fotos por generar → `references/06-fotos-ia-moda.md`.
3. Si no → `references/05-secciones-personalizadas.md` directamente.
