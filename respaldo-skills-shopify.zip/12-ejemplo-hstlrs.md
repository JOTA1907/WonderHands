# Ejemplo resuelto — HSTLRS Founders Club (para calibrar, NO para copiar)

Este documento muestra cómo se aplican las fases 3 y 4 a un caso real: una
marca de una camiseta con concepto, 23 imágenes propias y 5 capturas de
tiendas de referencia. Sirve para que veas el NIVEL DE DETALLE esperado en
el inventario, la lectura de referencias, la ficha de estilo, la
composición y el guion fotográfico. **Cada proyecto nuevo se lee desde cero
con sus propias referencias**: no reutilices esta ficha ni esta composición
en otra marca.

## 1. Lo que dio el usuario

- **Concepto (resumen de sus palabras):** "emprendedores hustle del siglo
  XXI; streetwear pero refinado; old money; trap life; jóvenes; dinero
  joven". El diseño lleva a cinco fundadores (Zuckerberg, Musk, Bezos,
  Gates, Jobs & Wozniak) en fotos de archivo en blanco y negro; la más
  representativa para él es la de Zuckerberg con auriculares (actitud
  "trap"). Una prenda (camiseta blanca oversized), más adelante quizá más.
- **Carpeta `HSTLRS Club/`**: 16 PNG de la prenda + subcarpeta `Recursos/`
  con 2 diseños transparentes y 5 fotos de los fundadores.
- **Carpeta `Tiendas de referencia/`**: 5 capturas WEBP.

## 2. Inventario (salida del script + decisión tras mirar cada imagen)

| Archivo | Sugerido | Decisión tras mirarla | Uso previsto |
|---|---|---|---|
| Mockup Frontal.png (1313×1198) | mockup-plano | Camiseta blanca sobre fondo gris muy claro, logo pequeño en el pecho izquierdo | Galería producto (2ª); bloque "delante y detrás" |
| Mockup Trasera.png (1201×1310) | mockup-plano | Espalda con el diseño completo: 5 fotos b/n + HSTLRS + FOUNDERS CLUB azul + XXI CENTURY | Galería producto (1ª = tarjeta); "delante y detrás" |
| Mockup Frontal Natural.png (1070×1470) | mockup-natural | Prenda sobre superficie gris, luz lateral, arrugas naturales | Galería (3ª); bloque de tejido |
| Mockup Trasera Natural.png | mockup-natural | Idem, trasera | Galería (4ª); hover de tarjeta |
| Mockup Detalle Trasera.png | detalle | Macro del estampado: se ve el grano de la tinta y las 4 fotos superiores | Bloque "historia del diseño" (foto principal) y zoom macro |
| Mockup Modelo 1 | modelo | De espaldas, gasolinera de noche, coche deportivo clásico gris, luz fría de fluorescente | **Héroe** (móvil tal cual; escritorio → banner IA o recorte) |
| Modelo 2 | modelo | De espaldas en garaje, todoterreno gris, fluorescentes | Lookbook |
| Modelo 3 | modelo | Chica de espaldas en cocina de mármol de noche, vaso, dedo levantado (guiño a la foto de Zuckerberg) | Lookbook (la única con mujer: imprescindible para no parecer marca solo masculina) |
| Modelo 4 | modelo | Chica de frente, gafas, portátil, terraza de café en París, logo pequeño visible | Lookbook / editorial "trabajo" |
| Modelo 5 | modelo | Chico con gorra, portátil y cámara, puerto mediterráneo (gorra con marca ajena "Nude Project" → evitar en primer plano) | Lookbook (usar recortado por debajo de la gorra o descartar) |
| Modelo 6 | modelo | Chico de frente en despacho oscuro de noche, ventanal de ciudad, cuaderno | Editorial "late night" |
| Modelo 7 | modelo | Chico con gafas, portátil en las piernas, zapatillas en primer plano, luz dorada de interior | Lookbook |
| Modelo 8 | modelo | Chico al teléfono de disco, bandeja dorada, billetes, cortinas: la foto "old money / trap" | Editorial "historia" o CTA final |
| Modelo 9 | modelo | Dos chicos: uno de espaldas (trasera) en taburete, otro de frente (frontal) en sofá Chester; loft con carteles japoneses | **Bloque "delante y detrás" con personas** o two-up |
| Modelo 10 | modelo | Chico con gafas y portátil, terraza de café parisino, coche negro detrás, luz dorada | Lookbook |
| Modelo 11 | modelo | Chica de espaldas junto a un coche clásico, mar al fondo, luz de día | Lookbook (única diurna exterior: aporta variedad) |
| Recursos/Diseño Frontal.png (2601×1259, alfa) | diseno | Logo HSTLRS + FOUNDERS CLUB azul + XXI CENTURY, tinta negra texturizada | **Logo** de header/footer (sobre claro) + referencia IA |
| Recursos/Diseño Trasera.png (2601×2780, alfa) | diseno | Diseño trasero completo | Referencia IA (fidelidad) + fondo del bloque "historia" sobre hueso |
| Recursos/Mark Zuckerberg.png y los otros 4 | referencia-concepto | Fotos de archivo b/n de los fundadores jóvenes | Referencia de concepto para TI; ilustran las 5 "fichas" del bloque historia (ya están en la prenda); NUNCA a la IA |
| Tiendas de referencia/*.webp (5) | captura-tienda | Ver lectura abajo | Ficha de estilo |

Todas las fotos de modelo son verticales 3:4 (1086×1448 aprox.): la ficha
debe favorecer verticales (tarjetas 4:5, lookbook 3:4) y el héroe
panorámico necesita un banner generado o un recorte consciente.

## 3. Lectura de las 5 referencias

### Ref 1 — "LUNARA / Drop 02" (streetwear editorial, claro): aporta ESTRUCTURA y TIPOGRAFÍA
Lienzo hueso (#EFECE4 aprox.). Header: logo condensado gigante a la
izquierda, menú en mayúsculas pequeñas, "BAG 00". Barra negra de marquesina
con texto lima ("FREE SHIPPING — NEW DROP 02 — LIMITED RUN"). Héroe partido:
titular enorme condensado en mayúsculas "DRESS LIKE YOU MEAN" + "IT." en
cursiva serif; numeral gigante "02" en lavanda detrás del modelo; a la
derecha un bloque lima con "DROP 02 / 06 · 18 / nombre / 420 GSM / swatches
/ $89 / SHOP PIECE →"; texto vertical "BUILT TO MOVE"; etiquetas mono
"AUTUMN / WINTER 26". Grid de productos numerado 01-06 con líneas
divisorias finas, badge "NEW", corazón, "SHOP NOW →" y "+". Sección
"JOURNAL" con "READ" en display + "JOURNAL." en cursiva serif y tarjetas de
artículo numeradas. Frase editorial "SEE YOU OUTSIDE." con foto pequeña
lateral. Footer negro con logo gigante blanco, 4 columnas, newsletter,
"WE MAKE ATTITUDE.". Paleta: hueso + negro + lima + lavanda (2 acentos).
Firmas: numerales, marquesina, mono, flechas, texto vertical, líneas de cota.

### Ref 2 — "FashionFable" (old money, crema): aporta ELEGANCIA y RITMO CLÁSICO
Crema (#F5F2EA), barra de anuncio fina ("FREE SHIPPING ON ORDERS $70+"),
header negro con menú y buscador. Héroe: foto a sangre de modelos en traje
en un salón de madera, nombre de la marca en serif blanca ENORME sobre la
foto, subtítulo "Men's fall Winter 2024" y botón blanco pequeño. "Explore
Our Collection" en serif con grid de 3 fotos lifestyle. Fila de 3 iconos de
línea (Made to Order / Free Delivery / Free Re-Sizing) con divisorias.
Tarjetas de producto sin bordes: foto, nombre serif, precio. Paleta: crema +
negro, sin acento. Firmas: serif editorial, iconos de línea, divisorias
finas, mucho aire.

### Ref 3 — "COMFITEE" (hoodies, bloques negro/crema): aporta poco — DESCARTADA casi entera
Nombre gigante con el modelo delante solapando letras (idea aprovechable:
arquetipo 4), píldoras de navegación, bandas alternas negro/crema con
títulos condensados, tarjetas redondeadas con precio y swatches, tarjetas
de categoría con forma de etiqueta, máscara blob, "UP TO 70% OFF". Lo que
NO copiamos: descuentos gritones, tarjetas muy redondeadas, saturación de
colores del producto (no encaja con "refinado"). Lo que sí: el ritmo de
bandas claro/oscuro alternas y la idea del nombre solapado por el modelo.

### Ref 4 — "CHICX" (oscura, lujo joven): aporta el MODO NOCHE y los BOTONES
Fondo negro (#0E0E0E-#141414), botones píldora blancos, badge píldora "New
collection ✦", titular sans grande en dos líneas, carrusel de fotos con
máscara de ARCO (ventanas), tarjetas de producto sobre foto con etiqueta
flotante y flecha ↗, menú de categorías como lista tipográfica. Paleta:
negro + blanco + fotos cálidas (rojo/ámbar). Firmas: arcos, píldoras, ↗.

### Ref 5 — "ICNDY / STÜSSY 2014" (streetwear clásico oscuro): aporta el HÉROE A SANGRE
Header transparente sobre foto de modelo oscura a sangre, logo en caja
blanca, menú tracked. Titular "STÜSSY2014" en mayúsculas muy espaciadas +
"SHOP NOW" en rojo. Debajo, mosaico de tiles (una grande, dos pequeñas) con
"SHOP CARHARTT". Paleta: foto oscura + blanco + un rojo. Firmas: caps
espaciadas, mosaico, sobriedad.

### Lo común (ADN)
Fotos de modelo a sangre protagonistas (5/5); titular enorme (4/5);
paleta de 2 colores + 1 acento como mucho (5/5); etiquetas pequeñas en
mayúsculas (4/5); grid de producto sobrio (4/5); alternancia claro/oscuro
(3/5); footer con logo grande (2/5, pero encaja con el concepto).

## 4. Ficha de estilo — HSTLRS Founders Club

**Frase resumen:** Editorial de streetwear refinado en hueso y tinta con
azul eléctrico del diseño como único acento; titulares condensados enormes
con una palabra en cursiva serif; fotos nocturnas y doradas a sangre;
bloques negros para la noche.

**Referencias y papel:** Ref 1 → estructura de portada, grid numerado,
marquesina, tipografía display+cursiva, footer con logo gigante. Ref 2 →
aire, divisorias finas, fila de iconos de línea, contención (sin
descuentos). Ref 4 → bloques negros, botones píldora blancos en los bloques
oscuros, arcos SOLO en el carrusel de lookbook (una firma prestada, no
todas). Ref 5 → héroe a sangre con header transparente como alternativa si
se genera banner. Ref 3 → solo el ritmo claro/oscuro. **No copiamos:**
lima/lavanda (el acento es el azul del diseño), "70% OFF", blobs, tarjetas
redondeadas, journal (el usuario no escribirá artículos ahora).

**Lienzo:** hueso #EFECE4 · bloques oscuros #0F0F0F (historia del diseño, CTA
final, footer) · patrón: claro → claro → oscuro → claro → oscuro.
**Paleta:** tinta #111111 · acento azul eléctrico #2E6BFF (el "FOUNDERS
CLUB" del diseño; uso: etiquetas mono, subrayados, botón principal en
bloques claros, una palabra del titular) · secundario gris cálido #8A8780
(textos de apoyo, divisorias al 15%).
**Tipografía:** display Anton (o Bebas Neue) 400 en MAYÚSCULAS, héroe ~11vw,
line-height .9 · contrapunto Instrument Serif itálica (una palabra por
titular: "IT.", "CLUB.", "HUSTLE.") · cuerpo Inter 400 17px · etiquetas
JetBrains Mono 12px espaciado .12em ("DROP 01 · XXI CENTURY", "01 / 06").
Ropa global de Shopify: header `oswald_n7`, body `inter_n4` (verificar
identificadores en la librería).
**Densidad:** aire medio-alto; gutter 24px (escritorio 40px); divisorias
finas rgba(17,17,17,.15) en grids; bordes 0 (píldora 999px solo en botones
de bloques oscuros); sin sombras.
**Fotos:** a sangre en héroe/editorial, en tarjeta en producto; producto 4:5;
lookbook 3:4; tono nocturno cálido con negros densos y ligero grano;
legibilidad sobre foto: degradado inferior negro 55% → transparente 60%.
**Tarjeta de producto:** 4:5, fondo #F2F2F2 (el del mockup), numeral "01",
nombre en display 20px, material en mono ("240 GSM · COTTON"), precio,
hover a trasera natural, tallas al hover, badge "NEW" por etiqueta.
**Header:** logo (Diseño Frontal.png) 140px izquierda, menú caps 12px
(SHOP · LOOKBOOK · THE CLUB · CONTACT), iconos búsqueda/cuenta/"BAG 00";
marquesina negra con texto azul debajo del header en portada.
**Footer:** negro, logo gigante en claro (versión generada), 3 columnas,
frase "BUILT BY HUSTLERS. WORN BY FOUNDERS." editable, sin newsletter.
**Firmas visuales:** numerales 01/06, marquesina, etiquetas mono de drop y
siglo ("XXI CENTURY"), flechas →, líneas de cota finas, sellos "EST. 2026 /
FOUNDERS CLUB", arco solo en el carrusel de lookbook.
**Copy:** claims cortos en inglés en mayúsculas ("DRESS LIKE A FOUNDER."),
cuerpo en español (propuesta por defecto; se confirma en el mensaje 2).
**Estética fotográfica del usuario (IA):** noche y primera hora, luz de
tungsteno/fluorescente y dorada de atardecer, negros densos, ligero grano
35 mm, ciudad europea (París, garajes, gasolineras, cafés), objetos de
trabajo (portátil, cámara, cuaderno, teléfono de disco, billetes, bandeja
dorada), coches oscuros clásicos incidentales, actitud calmada.
**Mapa de uso:** héroe ← Modelo 1 (móvil tal cual; escritorio: banner IA
misma escena); "delante y detrás" ← Modelo 9; lookbook ← Modelos 2, 3, 4,
6, 7, 10, 11 (5 recortado o fuera); editorial/CTA ← Modelo 8; historia del
diseño ← Detalle Trasera + Diseño Trasera sobre hueso; galería producto ←
Trasera, Frontal, Trasera Natural, Frontal Natural, Detalle; logo ← Diseño
Frontal (+ versión clara IA); referencia IA ← Diseño Trasera, Diseño
Frontal, Mockup Trasera/Frontal, Modelos 1, 2, 6, 8 (rotando).

## 5. Composición de la portada (arquetipos del catálogo `11`)

1. **nº 1** Héroe editorial tipográfico + foto lateral (Modelo 1 a la
   derecha, titular "DRESS LIKE A" + "FOUNDER." en cursiva, etiqueta "DROP
   01 · XXI CENTURY", bloque azul con nombre/precio/SHOP →). Fondo hueso.
2. **nº 69** Marquesina negra/azul pegada al héroe ("FREE SHIPPING ✦ DROP
   01 ✦ FOUNDERS CLUB ✦ LIMITED RUN") — costura deliberada.
3. **nº 13** Grid de colección numerado (colección "todo"; con 1 prenda,
   variante nº 17 "una prenda a lo grande" hasta que haya 3+). Hueso.
4. **nº 37** 🔥 La historia del diseño, fondo negro: Detalle Trasera grande
   con hotspots sobre las 5 fotos, 5 fichas (una por fundador: "Palo Alto,
   2004 — el dormitorio que se hizo red", etc.), texto sobre "XXI CENTURY".
   Costura negro→hueso con aire 96/96.
5. **nº 27** 🔥 Lookbook arrastrable (7 fotos de modelo, pies mono "LOOK 02 —
   PARKING, 02:10"), con máscara de arco (firma prestada de Ref 4). Hueso.
6. **nº 50** Delante y detrás (Modelo 9 como foto de personas + mockups
   frontal/trasera pequeños con "FRONT / BACK"). Hueso con línea editorial
   nº 70 encima.
7. **nº 48** Ficha de tejido y corte (iconos de línea, estilo Ref 2). Hueso.
8. **nº 63** 🔥 CTA con logo gigante en claro sobre negro con Modelo 8
   velado detrás y parallax; botón píldora blanco "SHOP DROP 01".
9. Footer propio negro con logo gigante (fase 7).

🔥: 4, 5, 8 (y el héroe con reveal). Costuras: 1→2 continua (marquesina
comparte el negro con la barra), 2→3 contraste con aire, 3→4 contraste
con aire, 4→5 contraste con aire, 5→6 línea editorial, 6→7 continua,
7→8 contraste con aire, 8→footer continua (negro).

## 6. Plan de fotos (con clave)

Tal cual: todo el mapa de uso. Generar (guion resumido):

| Archivo | Bloque | size | Vista | Refs | Escena | Qué la hace distinta |
|---|---|---|---|---|---|---|
| hs-hero-escritorio.jpg | héroe nº1 (variante a sangre nº2 si el usuario prefiere) | 2048x1152 | trasera | Diseño Trasera, Mockup Trasera, Modelo 1, Modelo 2 | Misma gasolinera nocturna de Modelo 1, modelo de espaldas en el tercio derecho, aire a la izquierda para el titular | La única panorámica; extiende la escena real del usuario |
| hs-hero-movil.jpg | héroe móvil | 1152x2048 | trasera | + hs-hero-escritorio | Misma escena vertical, modelo entero en la banda central, aire arriba | Versión vertical coherente |
| hs-logo-claro.png | header/footer oscuros | 1024x512 | — | Diseño Frontal | Mismo logo en blanco + azul sobre #0F0F0F | Única pieza de logo |
| hs-look-ia-1.jpg | lookbook | 1024x1365 | frontal | Diseño Frontal, Mockup Frontal, Modelo 6, Modelo 10 | Azotea al amanecer, portátil cerrado, café, ciudad al fondo, luz dorada rasante | Única al amanecer en exterior alto |
| hs-look-ia-2.jpg | lookbook | 1024x1365 | trasera | Diseño Trasera, Mockup Trasera, Modelo 2, Modelo 8 | Asiento trasero de coche negro de noche, modelo de espaldas al girarse hacia la ventanilla con neón | Única interior de coche |
| hs-unboxing.jpg | "qué recibes" (si entra) | 1536x1024 | prenda sola | Mockup Trasera Natural, Modelo 8 | Cenital: camiseta doblada con la trasera visible, papel de seda, tarjeta "WELCOME TO THE CLUB", bandeja dorada | Único bodegón |

Gasto estimado: 6 definitivas en medium/high + borradores ≈ 1,5-2,5 $.

## 7. Cómo se contó en el mensaje 2 (extracto)

> "En tu carpeta he encontrado 5 capturas de tiendas, 11 fotos con modelo,
> 5 mockups de la camiseta (frontal, trasera, dos naturales y un detalle),
> los dos diseños en fondo transparente y 5 fotos de los fundadores, que
> entiendo que son la inspiración del concepto y no van en la web tal cual.
>
> De tus referencias me quedo con: la estructura y los titulares enormes de
> la primera (la de fondo hueso con la sudadera negra), la elegancia y el
> aire de la de fondo crema, y los bloques negros con botones redondeados de
> la oscura. Descarto lo que chirría con 'refinado': descuentos gigantes y
> colores chillones. El único color de acento será el azul de tu diseño.
>
> Tu tienda: 1) apertura con tu foto de la gasolinera y un titular enorme
> 'DRESS LIKE A FOUNDER.'; 2) una tira negra en movimiento con tus mensajes;
> 3) tu camiseta a lo grande con tallas y precio; 4) un bloque negro con la
> historia del diseño, foto a foto de los cinco fundadores; 5) un lookbook
> deslizable con tus fotos de modelo; 6) delante y detrás; 7) tejido y
> corte; 8) cierre con tu logo gigante. Pie negro con el logo.
>
> Fotos: uso todas las tuyas. Con tu clave generaría 5-6 más: un banner
> apaisado de la gasolinera para la apertura en ordenador, su versión
> vertical, tu logo en blanco para los bloques negros, dos escenas nuevas
> para variar el lookbook y un bodegón del paquete. Unos 2 €.
>
> Dudas: ¿textos en español con claims en inglés (mi propuesta) o todo en
> inglés? ¿Precio de la camiseta? Si me dices 'adelante' con eso, empiezo."


## Cómo evolucionó con el feedback del usuario (para calibrar el gusto, no para copiar)

Combinación final: 2 · 71 · 17 · 40 · 29 · 27 · 51 · 36 con las variantes
73-77 del catálogo. Lo que el usuario pidió cambiar tras la entrega, en
orden, y lo que enseña:

1. Pies del lookbook: de "Kitchen, 23:30" a frases de marca ("For late
   shifters, 01:40 AM"), centrados y sin "Look 04" → los copys descriptivos
   fríos no gustan; propón fórmulas con identidad.
2. Aire entre tallas y botón; plazos "7–14 business days"; descripción
   estructurada → detalles de producto que se notan.
3. Logo blanco propio del usuario en vez del recoloreado → si tiene
   versiones, manda la suya.
4. Frase del muro ("They started last century") era inexacta → verifica
   los datos del concepto; ofrece 5 alternativas, aplica una.
5. Botón píldora con texto claro sobre blanco → especificidad.
6. Precio a 39.95 → `productVariantsBulkUpdate`.
7. Paralaje "de ventana" en el lookbook + Lenis; flechas suaves; sin foco.
8. Two-up: nada de hover que rompa el fundido → máquina de escribir; ancho
   completo y más bajo (60 vh); dos líneas fijas.
9. Héroe: banner del borrador que él prefería (regenerado en alta con el
   modelo entero) + reescalado por él + grano sutil; titular al 13 vw en
   dos líneas, pack centrado en vertical y justificado a la izquierda,
   subtítulo corto de una línea debajo de la cursiva, "S" sin recorte.
10. Repaso móvil: unión del two-up apilado en negro; aire bajo la cursiva.
11. "publica" → tema en vivo; memoria y estado al día.

Cada punto tiene su receta en `13-lecciones-y-recetas.md`.
