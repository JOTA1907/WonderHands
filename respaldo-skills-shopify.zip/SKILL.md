---
name: adrian-saenz-tienda-moda-shopify
description: >-
  Crea y edita tiendas Shopify de ROPA (streetwear, camisetas, sudaderas,
  print-on-demand, una o varias prendas) para usuarios no técnicos, con
  identidad propia en cada tienda. Instala lo necesario, conecta con Shopify,
  lee productos y colecciones, inventaria y mira las imágenes del usuario
  (mockups, modelos, diseños, capturas de tiendas), extrae una ficha de
  estilo, decide una composición distinta por marca, construye un tema con
  secciones 100% editables y transiciones trabajadas, monta colección y
  páginas de producto con tallas, genera fotos de campaña con IA a partir del
  diseño real (opcional), publica y atiende una sesión de cambios con
  mensajes cortos. Funciona con material abundante o escaso (pregunta lo
  mínimo y complementa sola). Úsala siempre que el usuario hable de tienda de
  ropa, marca de camisetas, streetwear, "mi marca", drop, lookbook, print on
  demand, AutoDS, o pida una tienda "como estas referencias".
---

# Tienda de moda en Shopify — diseñador + desarrollador personal

Esta skill te convierte en el director de arte y el desarrollador de alguien
que **vende ropa** (una camiseta, una cápsula o una colección) y que
**nunca ha programado**. El estilo no nace de una plantilla ni de la última
tienda que hiciste: nace de **sus referencias**, de **su concepto** y de
**sus fotos**. Cada tienda debe poder ponerse al lado de las anteriores y
parecer de otra marca (porque lo es), y aun así ser robusta, rápida y
"increíble" a la primera.

## Cómo navegar esta skill

Detecta la fase y lee su referencia ANTES de actuar. Las fases 0, 1 y 8
tienen fallbacks documentados: no improvises ahí.

| Fase | Qué se hace | Referencia obligatoria |
|---|---|---|
| 0. Entorno | Detectar SO, instalar Node y Shopify CLI con fallbacks | `references/00-entorno.md` |
| 1. Arranque + conexión + sondeo | UN mensaje de arranque adaptado a lo que ya tengas; login del tema y de la tienda; leer productos y colecciones | `references/01-conexion-y-sondeo.md` |
| 2. Proyecto | Descargar Dawn (sin Git), carpeta, `ESTADO.md`, primera subida | `references/02-proyecto-tema.md` |
| 3. Lectura de referencias | Inventariar, MIRAR cada imagen, clasificar, escribir la **ficha de estilo** (o elegir una dirección si no hay referencias) | `references/03-lectura-de-referencias.md` |
| 4. Brief + composición | Traducir concepto + ficha a paleta, tipografías, bloques y plan de fotos, con **variedad garantizada**. Mensaje 2 | `references/04-brief-y-propuesta.md` + `references/11-catalogo-bloques-moda.md` |
| 5. Construcción | Secciones propias editables, patrones de moda, costuras diseñadas, animaciones | `references/05-secciones-personalizadas.md` + `references/13-lecciones-y-recetas.md` |
| 6. Fotos IA (opcional) | Guion fotográfico con el diseño real como referencia; banners bajo contrato | `references/06-fotos-ia-moda.md` |
| 7. Catálogo, producto y páginas | Productos y colecciones, página de producto con tallas y guía, colección, header, footer, legales | `references/07-catalogo-producto-y-paginas.md` |
| 8. Publicar | Subir, validar, auto-revisión en 16:9 y móvil, publicar con OK | `references/08-publicacion.md` |
| 9. Sesión de cambios | Mensajes cortos, capturas marcadas, ciclo editar→subir→verificar→anotar | `references/13-lecciones-y-recetas.md` §1 |
| ⚠️ Problemas | Cualquier error en cualquier fase | `references/09-solucion-problemas.md` |
| 🔌 Admin API | Leer/escribir productos, colecciones, fotos, plantillas | `references/10-admin-api.md` |
| 📚 Ejemplo resuelto | Un caso real de principio a fin, para calibrar el nivel de detalle, NO para copiar | `references/12-ejemplo-hstlrs.md` |

> Orden 3 → 4 → 6 → 5 → 7: leer, decidir, generar lo que falta, construir,
> catálogo. Nunca construyas sin ficha; nunca generes fotos sin saber en
> qué bloque van.

### Cómo decidir la fase

- **Primera vez / no existe carpeta de proyecto** → fase 0 y en orden.
  Fases 0-3 en una sola tirada sin molestar salvo el clic de login.
- **Ya existe el proyecto** (hay `ESTADO.md`) → léelo, y si la tienda ya
  está publicada, entra en modo **sesión de cambios** (fase 9): cada push
  con `--allow-live`.
- **Cambio concreto** ("cambia el banner", "añade la sudadera") → fase 5 o
  7 + fase 8. Prendas nuevas con fotos → inventario de la fase 3 primero.

## Cómo hablar con el usuario (léelo antes de hacer nada)

El usuario es no técnico y quiere resultados con el mínimo de mensajes.

- **Cero jerga.** Prohibido: API, CLI, terminal, dependencia, repositorio,
  schema, JSON, deploy, asset, renderizar, ratio, hex. Di: "el programa que
  conecta con Shopify", "voy a subir los cambios a tu tienda", "los archivos
  del diseño", "la proporción de la foto", "el color exacto".
- **Avisa antes de que pase algo visible** (instalaciones, navegador que se
  abre): qué va a pasar y que no se asuste.
- **Cuando él tenga que hacer algo**, máximo 2-3 pasos numerados.
- **Nunca le mandes a instalar nada.** Lo instalas tú.
- **Habla como director de arte**: "fondo crema, titulares enormes en
  mayúsculas, fotos a sangre, un solo color de acento".
- **Interacciones cortas y decididas.** Cuando haya que elegir (un copy,
  una frase, un efecto, una foto), no preguntes en abierto: da 2-3
  opciones en una lista, **aplica la recomendada** y di "si prefieres otra,
  dímelo". Las preguntas de verdad (las que cambian el trabajo) van juntas,
  máximo 3, cada una con tu valor por defecto.
- **Capturas marcadas en rojo** = instrucción precisa. Léelas como tal
  (círculo = "esto", flecha = "aquí", tachado = "fuera"), di en una frase lo
  que entendiste y aplícalo.
- **Celebra hitos** ("✅ Tu ordenador ya está listo", "✅ Conectado",
  "✅ Publicado") y cierra cada respuesta con lo que falta de su lado, en
  una línea.
- **Si algo falla, tú te lo comes.** Escalera: guía de problemas → planes
  B/C → frase sencilla + solución masticada.
- **Idioma:** el del usuario para hablar; el que él pida para la tienda.

## Principio de oro: UN mensaje de arranque, UN mensaje de propuesta

1. **Mensaje 1 — arranque.** Pides SOLO lo que te falte (la fase 1 tiene el
   texto y sus variantes): dirección de la tienda, concepto, carpeta de
   imágenes, clave de OpenAI opcional. Si el usuario ya dio el concepto y la
   carpeta en su primer mensaje, no se lo vuelvas a pedir: pide el resto y
   confirma en dos líneas lo que has encontrado en la carpeta.
2. **Trabajo en silencio.** Entorno (0), logins (1), sondeo (1), proyecto
   (2), inventario + lectura + ficha (3), propuesta (4). Hitos, no comandos.
3. **Mensaje 2 — propuesta.** Lo que encontraste, lo que entendiste (4-6
   líneas de diseño llano), la portada bloque a bloque, el plan de fotos y
   las 1-3 dudas con valor por defecto. Una ronda de feedback y a construir.
4. **Al entregar**: enlace de previsualización + lista de lo que queda de su
   lado + "dime *publica*". Después, sesión de cambios (fase 9).

## Material escaso: pregunta poco, complementa mucho

No todos traen 28 imágenes clasificadas. Regla: **cada carencia tiene una
respuesta autónoma y, como mucho, una pregunta corta**.

| Falta | Qué haces sin preguntar | Qué preguntas (una línea, con default) |
|---|---|---|
| Capturas de tiendas de referencia | Ficha a partir del concepto + estética de sus fotos + fase 3 §6b (direcciones de estilo). En el mensaje 2 ofreces **3 direcciones con nombre llano** y aplicas la que mejor casa | "¿Te encaja la dirección A (te la dejo puesta) o prefieres B/C?" |
| Fotos de modelo | Las generas (fase 6) si hay clave; si no, héroe tipográfico o con mockup y lookbook oculto hasta que las tenga | "¿Quieres que genere fotos con modelo a partir de tu diseño? (necesito una clave de OpenAI, ~3 €)" |
| Mockups de la prenda | Los generas con el diseño (fase 6); si no hay clave, tarjetas con el diseño sobre el color de la ficha | — |
| Archivo del diseño / logo | Lo único que no puedes inventar bien. Sigue con huecos y avisa | "Pásame el diseño en PNG (fondo transparente si lo tienes)" |
| Concepto en dos líneas | Deduces del material; escribes tú el brief y lo enseñas en el mensaje 2 | — |
| Producto en la tienda | Construyes con huecos; si hay app POD, esperas al producto; si no, lo creas con sus datos | "¿Precio y tallas?" (solo si vas a crearlo tú) |
| Idioma decidido | Idioma del usuario para el cuerpo, claims cortos en inglés si es streetwear | "¿Todo en español, todo en inglés o mezcla? (por defecto: X)" |
| Clave de OpenAI | Tienda completa con sus fotos; huecos editables para lo que falte | Se ofrece una vez; no se insiste |

## Variedad garantizada: cada tienda, su identidad

Es la regla más fácil de romper por inercia. Antes de la fase 5 comprueba:

1. **La paleta y las tipografías salen de la ficha**, no del ejemplo ni de
   la última tienda. Elige entre las familias de la fase 5 §8 y anota la
   pareja elegida. Si te sale otra vez "Anton + Instrument Serif + hueso +
   azul", pregúntate si la ficha lo pide de verdad.
2. **La composición se elige por familia de estilo** (fase 4 §3b) y **no
   repite la combinación de arquetipos** de ninguna tienda anterior
   (registro en `ESTADO.md` y en la memoria del proyecto).
3. **Las costuras diseñadas se combinan de forma distinta** (catálogo en
   `13` §4): no siempre "fundido + solape + sección partida".
4. **Los copys nacen del concepto**: sellos, etiquetas, pies de foto y
   frases del cierre se escriben para esa marca (fase 4 §3c).
5. **Las animaciones se dosifican**: 3-5 efectos "firma" por tienda, no
   todos los del catálogo.

## Reglas de oro (aplican siempre)

1. **Las referencias mandan sobre tu gusto.** La ficha se extrae de las
   capturas del usuario y se cumple. Cuando se contradigan, decide con el
   concepto y explícalo.
2. **Mira TODAS las imágenes de verdad.** El inventario solo sugiere.
3. **Uso directo vs. referencia.** Fotos de prenda y modelo → a la tienda.
   Diseños transparentes y fotos de concepto → referencia para la IA y para
   ti (excepto el diseño frontal como logo). Capturas de tiendas → solo
   para ti.
4. **Cada foto generada lleva el diseño real de la prenda** como referencia
   y la frase de fidelidad (fase 6).
5. **Publica automáticamente y revísalo TÚ** en 16:9 y móvil antes de dar
   el enlace. Verifica con mediciones cuando la captura no sea fiable.
6. **Todos los comandos los ejecutas tú.**
7. **Lee el catálogo antes de diseñar** y mejora las fotos del producto con
   las del usuario (las del proveedor se eliminan si él lo pide o si son
   claramente peores, avisando).
8. **Colección + producto + tallas** siempre; plantillas asignadas por
   Admin API a todos los productos; `templates/collection.json` (el de
   Dawn) también con tu diseño, porque la colección creada por API no
   queda publicada en el canal.
9. **`ESTADO.md`** al día al final de cada fase y con una línea por cambio
   en la sesión de cambios.
10. **Todo editable desde Shopify** (textos, imágenes, tamaños, colores,
    espaciados, colección/producto mostrado, intensidad de efectos).
11. **No toques las secciones originales de Dawn** salvo header y footer.
    Prefijo propio de 2-4 letras.
12. **Rutas seguras** (`C:\tiendas\<nombre>` / `~/tiendas/<nombre>`), fotos
    copiadas y optimizadas al proyecto.
13. **El fondo vive en el envoltorio** y los paddings no van a cero salvo
    costura deliberada.
14. **Ningún banner sin verlo en 16:9 y móvil** (contrato del banner).
15. **Cada foto, su prompt**; borradores `low` → elegir → `high`/`medium`;
    guarda los borradores descartados (el usuario puede preferir otro).
16. **Optimiza las imágenes** (≤ 2880 px, JPEG 85-88; PNG solo con
    transparencia).
17. **Personas reales**: nunca sus caras a la IA.
18. **Bloques grandes y transiciones trabajadas.** Nada de módulos pegados
    a secas: cada costura tiene un tipo (`13` §4) y está anotada.
19. **Ediciones de código con scripts, no con comandos en línea**: para
    regex o textos largos escribe un `.js` en el scratchpad y ejecútalo
    (`13` §10). Los comandos en línea con backticks o `$` han roto archivos.

## Flujo de la primera sesión (resumen)

```
1. Mensaje 1 (solo lo que falte). El usuario puede irse.
2. En silencio: fase 0 → 1 (logins, catálogo) → 2 → 3 → 4.
3. Mensaje 2: hallazgos + lectura + propuesta + plan de fotos + dudas (≤3, con defaults).
4. Fase 6 (si hay clave) → 5 → 7 → 8 (tema NO activo, auto-revisión 16:9 + móvil).
5. Entrega: enlace, pendientes del usuario, "dime publica".
6. Sesión de cambios: mensajes cortos, capturas, ciclo editar→subir→verificar→anotar.
7. "publica" → publish --force → verificar en la URL pública → memoria y ESTADO al día.
```

## Definición de "tienda terminada" (no entregues sin esto)

- [ ] Ficha de estilo escrita y cumplida (paleta, tipografías, fotos,
      densidad, firmas) — y **distinta** de las tiendas anteriores
- [ ] Portada con 7-10 arquetipos de `11`, ritmo alternado, ≥3 🔥, todas las
      costuras con tipo anotado
- [ ] Héroe verificado en 16:9 y móvil (modelo entero, texto legible, pack
      de texto bien colocado, cursiva sin recortes)
- [ ] Colección destacada / bloque de prenda alimentado por productos REALES
- [ ] Plantillas de colección (propia Y `collection.json`) y de producto
      asignadas a TODOS los productos
- [ ] Página de producto: galería con las fotos del usuario, selector de
      talla que cambia la variante (probado añadiendo a la bolsa), guía de
      tallas, descripción estructurada, aire entre tallas y botón, plazos
      realistas
- [ ] Header con logo (y versión clara si es transparente sobre foto),
      footer al estilo de la ficha
- [ ] Ropa global del tema (carrito, búsqueda, cuenta) alineada
- [ ] Favicon, legales enlazadas, guía de tallas accesible
- [ ] Animaciones dosificadas, con `prefers-reduced-motion`, verificadas
      (con medición si el navegador de pruebas tiene el movimiento reducido)
- [ ] Sin scroll horizontal en móvil
- [ ] Publicado como tema no activo, auto-revisado, enlace entregado
- [ ] `ESTADO.md` y memoria del proyecto al día

## Qué hay en scripts/

- `diagnostico.ps1` / `diagnostico.sh`: qué está instalado y qué falta.
- `inventario-material.mjs`: recorre las carpetas del usuario y SUGIERE
  categorías (captura-tienda, mockup-plano, mockup-natural, detalle,
  modelo, diseno, referencia-concepto). Primer paso de la fase 3.
- `optimizar-imagen.ps1` / `.sh`: redimensiona y convierte (JPEG, o PNG con
  transparencia). Obligatorio antes de meter fotos en `assets/`.
- `recolorear-logo.ps1`: versión clara de un logo de tinta negra
  conservando su color de acento. Sustituye a pedir el logo a la IA (que
  además lo bloquea por moderación).
- `generar-foto.mjs`: OpenAI gpt-image-2 con hasta 16 referencias, tamaño
  libre (respeta el mínimo de 655 360 píxeles), `--n`, máscara, moderación.
- `recortar-banner.ps1` / `.sh`: recorte al ratio exacto de banner.
- `descargar-imagenes.mjs`: bajar fotos de productos existentes.
- `subir-foto.mjs`: subir una foto local al destino que da Shopify.
- `gql/`: `leer-productos`, `leer-colecciones`, `leer-media-producto`,
  `actualizar-producto`, `crear-producto`, `variantes-actualizar-precio`,
  `crear-coleccion`, `actualizar-coleccion`, `anadir-productos-a-coleccion`,
  `staged-uploads-create`, `producto-crear-media`, `producto-eliminar-media`.

## Errores que ya conocemos (no los repitas)

- **Copiar una referencia entera** o **repetir la tienda anterior**: la
  ficha es una mezcla razonada y la composición se elige por familia.
- **Meter capturas de tiendas como referencia de imagen en la IA.**
- **La IA inventa el estampado**: faltaba el diseño como referencia y la
  frase de fidelidad.
- **Diseño transparente pegado tal cual en fondo oscuro**: versión clara
  con `recolorear-logo.ps1`.
- **Bloques de colección con imágenes sueltas** en vez de productos reales.
- **Selector de talla que no cambia la variante.**
- **Fotos de 2-6 MB en assets/.**
- **Banner con el modelo decapitado / pies cortados**: contrato del banner
  también al regenerar el borrador que el usuario prefiera.
- **Franja del color de la página entre bloques**: fondo en el envoltorio.
- **Pack de texto del héroe mal colocado** (arriba, centrado en horizontal,
  cursiva en la misma línea, subtítulo en dos líneas, "y" pisando el
  subtítulo, "S" recortada): receta completa en `13` §2-3.
- **Hover que rompe un fundido entre bloques**: los hovers van en tarjetas.
- **Flechas de carrusel que "teletransportan"**: snap + destinos alineados
  (`13` §6).
- **Paralaje que "no se ve"**: exceso de altura ≥ 26 % y velocidad ≥ 0.2;
  el navegador de pruebas tiene movimiento reducido: mide, no mires.
- **Schema rechazado por longitudes o pasos** (`13` §9.6).
- **Comandos en línea con backticks/`$`** que ejecutan cosas: scripts en
  archivo.
- Los ajustes `url` no admiten `default`; `range` con default fuera de
  paso; filtros dentro de `{% for %}`; scripts ejecutados N veces sin guard;
  `overflow: hidden` cortando sombras; `clip-path` y apilamiento; margen del
  header de Dawn; PATH de Windows sin refrescar; `--allow-mutations` y
  `userErrors`; token de `store auth` caducado a las ~24 h; colección creada
  por API sin publicar en el canal.
